package ye.alkamel.cardsender

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.util.Log

/** Submits a card SMS and reports the device/network send result asynchronously. */
data class CardSendResult(val success: Boolean, val error: String = "")

object CardSmsSender {
    fun send(
        context: Context,
        phone: String,
        card: String,
        amount: Int,
        subscriptionId: Int,
        queueId: String,
        messageSuffix: String = ""
    ): CardSendResult = try {
        val prefs = context.getSharedPreferences("message_settings", Context.MODE_PRIVATE)
        val defaultTemplate = "شبكة الكامل - كرت {السعر} ريال - رقم الكرت👇\n"
        val slot = try { android.telephony.SubscriptionManager.getSlotIndex(subscriptionId) } catch (_: Exception) { -1 }
        val simKey = if (slot == 1) "template_sim2" else "template_sim1"
        val savedTemplate = prefs.getString(simKey, null) ?: prefs.getString("template", defaultTemplate).orEmpty()
        val template = savedTemplate
            .replace("\\r\\n", "\n")
            .replace("\\n", "\n")
            .replace("{السعر}", amount.toString())
        // Preserve the card itself and cap the message to one short SMS.
        val message = template.take((54 - card.length).coerceAtLeast(0)) + card + messageSuffix
        sendTracked(context, phone, message, subscriptionId, queueId)
    } catch (e: Exception) {
        Log.e("AlKamelCardSender", "SMS submission failed", e)
        CardSendResult(false, e.message ?: "تعذر إرسال الرسالة")
    }

    fun sendNotice(context: Context, phone: String, message: String, subscriptionId: Int, queueId: String): CardSendResult =
        sendTracked(context, phone, message, subscriptionId, queueId)

    private fun sendTracked(context: Context, phone: String, message: String, subscriptionId: Int, queueId: String): CardSendResult = try {
        val smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
        val parts = smsManager.divideMessage(message)
        val sentIntents = ArrayList<PendingIntent>(parts.size)
        parts.indices.forEach { partIndex ->
            val callback = Intent(context, SmsSentReceiver::class.java).apply {
                action = "ye.alkamel.cardsender.SMS_SENT.$queueId.$partIndex"
                putExtra(SmsSentReceiver.EXTRA_QUEUE_ID, queueId)
                putExtra(SmsSentReceiver.EXTRA_PART_INDEX, partIndex)
                putExtra(SmsSentReceiver.EXTRA_PART_COUNT, parts.size)
            }
            sentIntents.add(PendingIntent.getBroadcast(
                context,
                (queueId + ":" + partIndex).hashCode(),
                callback,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ))
        }
        if (parts.size == 1) smsManager.sendTextMessage(phone, null, message, sentIntents[0], null)
        else smsManager.sendMultipartTextMessage(phone, null, ArrayList(parts), sentIntents, null)
        // This is submission only; queue completion waits for SmsSentReceiver.
        CardSendResult(true)
    } catch (e: Exception) {
        Log.e("AlKamelCardSender", "SMS submission failed", e)
        CardSendResult(false, e.message ?: "تعذر إرسال الرسالة")
    }
}
