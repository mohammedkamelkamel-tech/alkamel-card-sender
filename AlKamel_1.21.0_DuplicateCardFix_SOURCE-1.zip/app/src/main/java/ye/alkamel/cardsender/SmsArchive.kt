package ye.alkamel.cardsender

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.Telephony
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * A deliberately separate read-only archive. It never writes to the app's operational database,
 * card queue, inventory, or SMS sending components.
 */
data class ArchivedSms(
    val id: Long, val threadId: Long, val address: String, val body: String,
    val date: Long, val type: Int
)

class SmsArchiveDb(context: Context) : SQLiteOpenHelper(
    context.applicationContext, "alkamel_sms_archive_v121.db", null, 1
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE sms_archive(
            id INTEGER PRIMARY KEY, thread_id INTEGER NOT NULL, address TEXT NOT NULL,
            body TEXT NOT NULL, date INTEGER NOT NULL, type INTEGER NOT NULL)""")
        db.execSQL("CREATE INDEX idx_sms_archive_thread_date ON sms_archive(thread_id,date)")
        db.execSQL("CREATE INDEX idx_sms_archive_address ON sms_archive(address)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun upsertBatch(items: List<ArchivedSms>) {
        if (items.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            items.forEach { item ->
                val v = ContentValues().apply {
                    put("id", item.id); put("thread_id", item.threadId); put("address", item.address)
                    put("body", item.body); put("date", item.date); put("type", item.type)
                }
                db.insertWithOnConflict("sms_archive", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun maxArchivedId(): Long = readableDatabase.rawQuery(
        "SELECT COALESCE(MAX(id),0) FROM sms_archive", null
    ).use { c -> if (c.moveToFirst()) c.getLong(0) else 0L }

    fun conversations(): List<ArchivedSms> {
        val sql = """SELECT s.* FROM sms_archive s
            WHERE NOT EXISTS (SELECT 1 FROM sms_archive newer WHERE newer.thread_id=s.thread_id
              AND (newer.date>s.date OR (newer.date=s.date AND newer.id>s.id)))
            ORDER BY s.date DESC, s.id DESC"""
        val out = mutableListOf<ArchivedSms>()
        readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out.add(read(c)) }
        return out
    }

    fun messages(threadId: Long, query: String = ""): List<ArchivedSms> {
        val out = mutableListOf<ArchivedSms>()
        val q = query.trim()
        val sql = if (q.isEmpty()) "SELECT * FROM sms_archive WHERE thread_id=? ORDER BY date ASC,id ASC"
            else "SELECT * FROM sms_archive WHERE thread_id=? AND (body LIKE ? OR address LIKE ?) ORDER BY date ASC,id ASC"
        val args = if (q.isEmpty()) arrayOf(threadId.toString()) else arrayOf(threadId.toString(), "%$q%", "%$q%")
        readableDatabase.rawQuery(sql, args).use { c -> while (c.moveToNext()) out.add(read(c)) }
        return out
    }

    /** One best (newest matching) hit per conversation, so global search never floods
     * the result list with hundreds of messages from the same sender/thread. */
    fun search(query: String): List<ArchivedSms> {
        val out = mutableListOf<ArchivedSms>()
        val pattern = "%${query.trim()}%"
        val sql = """SELECT s.* FROM sms_archive s
            WHERE (s.body LIKE ? OR s.address LIKE ?)
              AND NOT EXISTS (
                SELECT 1 FROM sms_archive newer
                WHERE newer.thread_id=s.thread_id
                  AND (newer.body LIKE ? OR newer.address LIKE ?)
                  AND (newer.date>s.date OR (newer.date=s.date AND newer.id>s.id))
              )
            ORDER BY s.date DESC,s.id DESC LIMIT 500"""
        readableDatabase.rawQuery(sql, arrayOf(pattern, pattern, pattern, pattern)).use { c ->
            while (c.moveToNext()) out.add(read(c))
        }
        return out
    }

    private fun read(c: android.database.Cursor) = ArchivedSms(
        c.getLong(0),c.getLong(1),c.getString(2) ?: "",c.getString(3) ?: "",
        c.getLong(4),c.getInt(5)
    )
}

object SmsArchiveGate {
    /** Serializes archive writes and backup snapshots without touching core app storage. */
    val lock = Any()
}

object SmsArchiveSync {
    fun run(context: Context): Int = synchronized(SmsArchiveGate.lock) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.READ_SMS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED) return -1

        val prefs = context.getSharedPreferences("sms_archive_sync_v121", Context.MODE_PRIVATE)
        var lastId = prefs.getLong("last_provider_id", 0L)
        val db = SmsArchiveDb(context)
        var imported = 0
        val projection = arrayOf("_id", "thread_id", "address", "body", "date", "type")
        try {
            // The cursor is stored separately from the archive DB. Restoring an archive made
            // on another device therefore cannot skip this phone's SMS provider records.
            val cursor = context.contentResolver.query(
                Telephony.Sms.CONTENT_URI, projection, "_id > ?", arrayOf(lastId.toString()), "_id ASC"
            ) ?: error("تعذر الوصول إلى سجل رسائل SMS")
            cursor.use { c ->
                val id = c.getColumnIndexOrThrow("_id")
                val thread = c.getColumnIndexOrThrow("thread_id")
                val address = c.getColumnIndexOrThrow("address")
                val body = c.getColumnIndexOrThrow("body")
                val date = c.getColumnIndexOrThrow("date")
                val type = c.getColumnIndexOrThrow("type")
                val batch = ArrayList<ArchivedSms>(100)
                var scanned = 0
                while (c.moveToNext()) {
                    val providerId = c.getLong(id)
                    val kind = c.getInt(type)
                    if (kind == Telephony.Sms.MESSAGE_TYPE_INBOX ||
                        kind == Telephony.Sms.MESSAGE_TYPE_SENT ||
                        kind == Telephony.Sms.MESSAGE_TYPE_OUTBOX) {
                        batch.add(ArchivedSms(providerId, c.getLong(thread),
                            c.getString(address) ?: "", c.getString(body) ?: "", c.getLong(date), kind))
                    }
                    scanned++
                    if (scanned >= 100) {
                        db.upsertBatch(batch)
                        imported += batch.size
                        batch.clear()
                        lastId = providerId
                        prefs.edit().putLong("last_provider_id", lastId).commit()
                        scanned = 0
                    }
                }
                if (batch.isNotEmpty()) {
                    db.upsertBatch(batch)
                    imported += batch.size
                }
                if (scanned > 0) {
                    // The final provider ID is safe to commit only after the pending batch.
                    lastId = c.let { if (it.moveToLast()) it.getLong(id) else lastId }
                    prefs.edit().putLong("last_provider_id", lastId).commit()
                }
            }
            return imported
        } finally { db.close() }
    }
}

class SmsArchiveSyncWorker(c: Context, p: WorkerParameters) : Worker(c,p) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("sms_archive_status_v121", Context.MODE_PRIVATE)
        return try {
            val result = SmsArchiveSync.run(applicationContext)
            if (result < 0) {
                prefs.edit().putString("sync_status", "permission_denied").apply()
            } else {
                prefs.edit().putString("sync_status", "ok")
                    .putLong("last_sync_time", System.currentTimeMillis()).apply()
            }
            Result.success()
        } catch (_: Exception) {
            prefs.edit().putString("sync_status", "error").apply()
            // Keep the periodic schedule alive; the next attempt is on the six-hour cadence.
            Result.success()
        }
    }
}

class SmsArchiveBackupWorker(c: Context, p: WorkerParameters) : Worker(c,p) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("sms_archive_status_v121", Context.MODE_PRIVATE)
        return try {
            SmsArchiveBackup.create(applicationContext)
            prefs.edit().putString("backup_status", "ok")
                .putLong("last_backup_time", System.currentTimeMillis()).apply()
            Result.success()
        } catch (_: Exception) {
            prefs.edit().putString("backup_status", "error").apply()
            // Keep the periodic schedule alive; the next attempt is on the daily cadence.
            Result.success()
        }
    }
}

object SmsArchiveBackup {
    fun create(context: Context): File = synchronized(SmsArchiveGate.lock) {
        val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "sms-archive-backups")
        if (!dir.exists() && !dir.mkdirs()) error("تعذر إنشاء مجلد النسخ الاحتياطية")
        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val target = File(dir, "alkamel-sms-$stamp.zip")
        val db = context.getDatabasePath("alkamel_sms_archive_v121.db")
        if (!db.exists()) error("لا توجد قاعدة بيانات للأرشيف حتى الآن")
        // Checkpoint WAL so the standalone database file contains the latest committed rows.
        val checkpoint = SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try { checkpoint.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { while (it.moveToNext()) { } } }
        finally { checkpoint.close() }
        val temp = File(dir, target.name + ".tmp")
        val verifyDb = File(dir, db.name + ".verify")
        val previous = File(dir, target.name + ".previous")
        try {
            if (temp.exists()) temp.delete()
            ZipOutputStream(temp.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry(db.name))
                db.inputStream().buffered().use { it.copyTo(zip) }
                zip.closeEntry()
            }
            // Verify both ZIP readability and the SQLite database before publishing the backup.
            java.util.zip.ZipFile(temp).use { z ->
                val entries = z.entries()
                require(entries.hasMoreElements()) { "ملف النسخة الاحتياطية فارغ" }
                val entry = entries.nextElement()
                require(entry.name == db.name && !entries.hasMoreElements()) { "محتويات النسخة الاحتياطية غير متوقعة" }
                z.getInputStream(entry).use { input ->
                    verifyDb.outputStream().buffered().use { output -> input.copyTo(output) }
                }
            }
            val verify = SQLiteDatabase.openDatabase(verifyDb.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            try {
                verify.rawQuery("PRAGMA quick_check", null).use { c ->
                    if (!c.moveToFirst() || c.getString(0) != "ok") error("قاعدة بيانات النسخة الاحتياطية غير سليمة")
                }
                verify.rawQuery("SELECT COUNT(*) FROM sms_archive", null).use { c ->
                    if (!c.moveToFirst()) error("تعذر قراءة محتويات النسخة الاحتياطية")
                }
            } finally { verify.close() }

            if (previous.exists() && !previous.delete()) error("تعذر تنظيف النسخة السابقة المؤقتة")
            if (target.exists() && !target.renameTo(previous)) error("تعذر تجهيز نسخة اليوم للاستبدال")
            if (!temp.renameTo(target)) {
                if (previous.exists()) previous.renameTo(target)
                error("تعذر اعتماد ملف النسخة الاحتياطية")
            }
            previous.delete()
            target
        } finally {
            temp.delete()
            verifyDb.delete()
        }
    }
}
