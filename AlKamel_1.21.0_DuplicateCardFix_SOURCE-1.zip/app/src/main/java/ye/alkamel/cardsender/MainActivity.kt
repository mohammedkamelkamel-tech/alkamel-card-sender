package ye.alkamel.cardsender
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.documentfile.provider.DocumentFile
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val requestCode = 700
    private val restoreRequestCode = 701
    private val backupFolderRequestCode = 702
    private lateinit var content: LinearLayout
    private var currentScreen = "dashboard"
    private var categoryManagementSimSlot = 1
    private var operationLogSimSlot = 1
    private var alternateNumbersSimSlot = 1

    private var dashboardStockText: TextView? = null
    private var dashboardSoldText: TextView? = null
    private val dashboardCategoryViews = mutableMapOf<Int, TextView>()
    private val navButtons = mutableMapOf<String, Pair<LinearLayout, Pair<TextView, TextView>>>()

    private fun updateBottomNav(activeKey: String) {
        listOf("dashboard", "add_cards", "stock", "sales", "more").forEach { key ->
            val entry = navButtons[key] ?: return@forEach
            val container = entry.first
            val iconView = entry.second.first
            val labelView = entry.second.second
            val isActive = (key == activeKey)
            if (isActive) {
                container.background = roundedBackground(Color.rgb(228, 241, 255), Color.rgb(175, 212, 246), 12.dp())
                iconView.setTextColor(Color.rgb(13, 91, 158))
                labelView.setTextColor(Color.rgb(13, 91, 158))
                labelView.typeface = Typeface.DEFAULT_BOLD
            } else {
                container.background = roundedBackground(Color.TRANSPARENT, Color.TRANSPARENT, 0)
                iconView.setTextColor(Color.rgb(115, 135, 156))
                labelView.setTextColor(Color.rgb(100, 116, 139))
                labelView.typeface = Typeface.DEFAULT
            }
        }
    }

    private fun styledSpinnerAdapter(items: List<String>): ArrayAdapter<String> {
        return object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                    layoutParams = android.view.ViewGroup.LayoutParams(-1, -1)
                }
                tv.text = getItem(position) ?: ""
                tv.textSize = 15f
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.setTextColor(Color.rgb(15, 41, 66))
                tv.gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                tv.setPadding(14.dp(), 8.dp(), 14.dp(), 8.dp())
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                    layoutParams = android.view.ViewGroup.LayoutParams(-1, -1)
                }
                tv.text = getItem(position) ?: ""
                tv.textSize = 15f
                tv.setTextColor(Color.rgb(15, 41, 66))
                tv.gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                tv.setPadding(16.dp(), 12.dp(), 16.dp(), 12.dp())
                tv.setBackgroundColor(if (position % 2 == 0) Color.WHITE else Color.rgb(246, 250, 255))
                return tv
            }
        }
    }

    private val refreshHandler = Handler(Looper.getMainLooper())
    private val stockRefreshRunnable = object : Runnable {
        override fun run() {
            if (currentScreen == "dashboard") refreshDashboardStock()
            refreshHandler.postDelayed(this, 1000)
        }
    }

    override fun onBackPressed() {
        if (currentScreen != "dashboard") showDashboard() else super.onBackPressed()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        handleCardFileImportResult(requestCode, resultCode, data)
        if (requestCode == backupFolderRequestCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putString("backup_tree_uri", uri.toString()).apply()
                Toast.makeText(this, "تم تحديد مسار النسخ الاحتياطية بنجاح", Toast.LENGTH_LONG).show()
                showBackup()
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر حفظ صلاحية المسار المحدد", Toast.LENGTH_LONG).show()
            }
            return
        }

        if (requestCode == restoreRequestCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            when (val result = BackupManager.restoreBackup(this, uri)) {
                is BackupManager.Result.Success -> {
                    getSharedPreferences("settings", MODE_PRIVATE).edit().putString("last_restore", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())).commit()
                    Toast.makeText(
                        this,
                        "تمت استعادة النسخة بنجاح. تم استرجاع " + result.categories + " فئة من الكروت.",
                        Toast.LENGTH_LONG
                    ).show()
                    CardStore.initializeFiles(this)
                    showDashboard()
                }
                is BackupManager.Result.Error ->
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!LicenseManager.isActivated(this)) {
            showActivationScreen()
            return
        }
        refreshHandler.removeCallbacks(stockRefreshRunnable)
        refreshHandler.post(stockRefreshRunnable)
        if (::content.isInitialized && currentScreen == "dashboard") showDashboard()
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(stockRefreshRunnable)
        super.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!LicenseManager.isActivated(this)) {
            showActivationScreen()
            return
        }
        startApp()
    }

    private fun startApp() {
        setupBackupSchedule()
        setupSmsArchiveSchedules()
        requestPermissions()
        CardStore.initializeFiles(this)
        buildUi()
        showDashboard()
        val noticePrefs = getSharedPreferences("background_notice", MODE_PRIVATE)
        if (!noticePrefs.getBoolean("shown", false)) {
            noticePrefs.edit().putBoolean("shown", true).commit()
            if (!BackgroundHelper.isIgnoringBatteryOptimizations(this)) android.app.AlertDialog.Builder(this)
                .setTitle("تنبيه مهم")
                .setMessage("يجب تفعيل العمل في الخلفية لضمان عمل التطبيق واستقبال الرسائل عند إغلاق الشاشة.")
                .setPositiveButton("فتح إعدادات الخلفية") { _, _ -> BackgroundHelper.openBatteryOptimizationSettings(this) }
                .setNegativeButton("لاحقًا", null).show()
        }
    }

    private fun showActivationScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(248,249,252))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "الكامل أونلاين"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(20,91,150))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "أدخل كود الشراء لتفعيل التطبيق"
            textSize = 18f
            setTextColor(Color.rgb(45,45,45))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }, LinearLayout.LayoutParams(-1, -2))

        val codeInput = EditText(this).apply {
            hint = "مثال: D1-XXXXXXXXXXXX-XXXXXXXXXXXX"
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setTextColor(Color.rgb(25,25,25))
            setHintTextColor(Color.rgb(110,110,110))
        }
        root.addView(codeInput, LinearLayout.LayoutParams(-1, -2))

        val activateButton = Button(this).apply {
            text = "تفعيل التطبيق"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35,95,150))
        }
        root.addView(activateButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 16, 0, 8) })

        root.addView(TextView(this).apply {
            text = "يوجد نوعان من الأكواد:\n• كود يوم واحد: يعمل 24 ساعة من أول تفعيل\n• كود مدى الحياة: لا تنتهي صلاحيته"
            textSize = 14f
            setTextColor(Color.rgb(70,70,70))
            setPadding(0, 12, 0, 0)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2))

        activateButton.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isBlank()) {
                Toast.makeText(this, "أدخل كود التفعيل أولاً", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            activateButton.isEnabled = false
            activateButton.text = "جاري التحقق من الكود..."
            LicenseManager.activate(this, code) { result ->
                runOnUiThread {
                    activateButton.isEnabled = true
                    activateButton.text = "تفعيل التطبيق"
                    when (result) {
                        is LicenseManager.Result.Success -> {
                            val message = if (result.type == "DAY")
                                "تم تفعيل التطبيق لمدة 24 ساعة على هذا الجهاز"
                            else
                                "تم تفعيل التطبيق مدى الحياة على هذا الجهاز"
                            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                            startApp()
                        }
                        is LicenseManager.Result.Error ->
                            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        setContentView(root)
    }

    private fun buildUi() {
        window.statusBarColor = Color.rgb(11, 74, 130)
        window.navigationBarColor = Color.rgb(246, 248, 252)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 249, 253))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        // Modern Premium Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18.dp(), 16.dp(), 18.dp(), 16.dp())
            background = gradientBackground(
                Color.rgb(11, 74, 130),
                Color.rgb(25, 114, 186),
                0
            )
            elevation = 4.dp().toFloat()
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val logo = ImageView(this).apply {
            setImageResource(ye.alkamel.cardsender.R.drawable.alkamel_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            background = roundedBackground(Color.WHITE, Color.rgb(215, 230, 245), 14.dp())
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            elevation = 2.dp().toFloat()
        }
        top.addView(logo, LinearLayout.LayoutParams(56.dp(), 56.dp()).apply {
            marginStart = 12.dp()
        })

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleBox.addView(TextView(this).apply {
            text = "الكامل أونلاين"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        titleBox.addView(TextView(this).apply {
            text = "إدارة الكروت والمبيعات والإرسال التلقائي"
            textSize = 12.5f
            setTextColor(Color.rgb(215, 235, 252))
            setPadding(0, 3.dp(), 0, 0)
        })
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        val menu = TextView(this).apply {
            text = "⋮"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            isClickable = true
            isFocusable = true
            background = roundedBackground(Color.argb(35, 255, 255, 255), 0, 10.dp())
            setOnClickListener { showMoreTools() }
        }
        top.addView(menu, LinearLayout.LayoutParams(40.dp(), 44.dp()))

        header.addView(top)

        val licenseBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
            background = roundedBackground(Color.argb(45, 255, 255, 255), 0, 12.dp())
        }
        licenseBox.addView(TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(Color.rgb(52, 211, 153))
            setPadding(0, 0, 8.dp(), 0)
        })
        licenseBox.addView(TextView(this).apply {
            text = LicenseManager.remainingText(this@MainActivity)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        header.addView(licenseBox, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = 12.dp()
        })

        // Modern Navigation Bar with active tab state
        val bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(6.dp(), 6.dp(), 6.dp(), 6.dp())
            setBackgroundColor(Color.WHITE)
            elevation = 8.dp().toFloat()
        }
        bottomNav.addView(bottomNavButton("dashboard", "⌂", "الرئيسية") { showDashboard() }, LinearLayout.LayoutParams(0, 54.dp(), 1f))
        bottomNav.addView(bottomNavButton("add_cards", "＋", "إضافة") { showAddCards() }, LinearLayout.LayoutParams(0, 54.dp(), 1f))
        bottomNav.addView(bottomNavButton("stock", "▦", "المخزون") { showStock() }, LinearLayout.LayoutParams(0, 54.dp(), 1f))
        bottomNav.addView(bottomNavButton("sales", "◷", "المبيعات") { showSales() }, LinearLayout.LayoutParams(0, 54.dp(), 1f))
        bottomNav.addView(bottomNavButton("more", "⋯", "المزيد") { showMoreTools() }, LinearLayout.LayoutParams(0, 54.dp(), 1f))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 14.dp(), 16.dp(), 24.dp())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(content)

        val footer = TextView(this).apply {
            text = "الكامل أونلاين  •  حقوق محمد كامل - 772072056"
            textSize = 11.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(8.dp(), 9.dp(), 8.dp(), 9.dp())
            setBackgroundColor(Color.rgb(250, 252, 255))
        }

        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(footer, LinearLayout.LayoutParams(-1, -2))
        root.addView(bottomNav, LinearLayout.LayoutParams(-1, 64.dp()))
        setContentView(root)
        updateBottomNav("dashboard")
    }

    private fun bottomNavButton(key: String, icon: String, label: String, action: () -> Unit): LinearLayout {
        val iconView = TextView(this).apply {
            text = icon
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(115, 135, 156))
        }
        val labelView = TextView(this).apply {
            text = label
            textSize = 11.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 116, 139))
            setSingleLine(true)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(2.dp(), 4.dp(), 2.dp(), 4.dp())
            addView(iconView, LinearLayout.LayoutParams(-1, 26.dp()))
            addView(labelView, LinearLayout.LayoutParams(-1, 18.dp()))
            setOnClickListener { action() }
            setOnTouchListener { view, event ->
                if (event.action == android.view.MotionEvent.ACTION_DOWN) view.alpha = 0.72f
                if (event.action == android.view.MotionEvent.ACTION_UP || event.action == android.view.MotionEvent.ACTION_CANCEL) view.alpha = 1f
                false
            }
        }
        navButtons[key] = Pair(container, Pair(iconView, labelView))
        return container
    }

    private fun showMoreTools() {
        val entries = listOf(
            Triple("🏷️", "فئات الكروت", { showCategories() }),
            Triple("🔗", "ربط الأرقام", { showAlternateNumbers() }),
            Triple("📋", "سجل العمليات", { showOperations() }),
            Triple("📨", "جميع رسائل SMS", { startActivity(Intent(this, SmsArchiveActivity::class.java)) }),
            Triple("⚠️", "رسائل تحتاج إلى مراجعة", { showSmsReviewMessages() }),
            Triple("🧩", "إضافة وتعديل صيغ الرسائل الواردة", { showCustomWalletSmsFormats() }),
            Triple("✉️", "رسالة الكرت", { showMessageSettings() }),
            Triple("🚀", "الخدمات والإرسال", { showServices() }),
            Triple("💾", "النسخ الاحتياطي والاستعادة", { showBackup() }),
            Triple("🔔", "تنبيه انخفاض المخزون", { showStockAlertSettings() }),
            Triple("📦", "المخزون حسب الشريحة", { showSimInventory() }),
            Triple("📊", "المبيعات حسب الشريحة", { showSimSales() }),
            Triple("💳", "سلفني والمتسلفون", { showLoans() }),
            Triple("🚫", "الكروت غير المتوفرة", { showUnavailableCards() }),
            Triple("🎁", "اجمع واربح", { showCollectAndWin() }),
            Triple("🔄", "نقل الكروت بين الشرائح", { showMoveCards() })
        )
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 8.dp(), 16.dp(), 8.dp())
            setBackgroundColor(Color.rgb(246, 250, 255))
        }
        val heading = TextView(this).apply {
            text = "كل أدواتك في مكان واحد"
            textSize = 13f
            setTextColor(Color.rgb(91, 115, 139))
            gravity = Gravity.RIGHT
            setPadding(4.dp(), 0, 4.dp(), 8.dp())
        }
        panel.addView(heading, LinearLayout.LayoutParams(-1, -2))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lateinit var toolsDialog: android.app.AlertDialog
        entries.forEach { entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setPadding(10.dp(), 8.dp(), 10.dp(), 8.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(221, 233, 246), 14.dp())
                addView(TextView(this@MainActivity).apply {
                    text = entry.first
                    textSize = 23f
                    gravity = Gravity.CENTER
                    background = roundedBackground(Color.rgb(230, 242, 255), Color.rgb(230, 242, 255), 12.dp())
                }, LinearLayout.LayoutParams(46.dp(), 46.dp()))
                addView(TextView(this@MainActivity).apply {
                    text = entry.second
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(35, 70, 105))
                    gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                    setPadding(12.dp(), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, -1, 1f))
                addView(TextView(this@MainActivity).apply {
                    text = "‹"
                    textSize = 25f
                    setTextColor(Color.rgb(100, 136, 169))
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(24.dp(), -1))
                setOnClickListener { toolsDialog.dismiss(); entry.third.invoke() }
                setOnTouchListener { view, event ->
                    if (event.action == android.view.MotionEvent.ACTION_DOWN) view.alpha = 0.78f
                    if (event.action == android.view.MotionEvent.ACTION_UP || event.action == android.view.MotionEvent.ACTION_CANCEL) view.alpha = 1f
                    false
                }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 8.dp()) })
        }
        val scroll = ScrollView(this).apply { addView(list) }
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        toolsDialog = android.app.AlertDialog.Builder(this)
            .setTitle("المزيد من الأدوات")
            .setView(panel)
            .setNegativeButton("إغلاق", null)
            .create()
        toolsDialog.show()
        toolsDialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.82f).toInt())
    }

    private fun showLoans() {
        currentScreen = "loans"
        updateBottomNav("more")
        content.removeAllViews()
        addBackButton()
        addTitle("خدمة سلفني")
        addText("السلفة كرت واحد بقيمة 100 ريال. يشترط شراء 10 كروت على الأقل، ولا تُمنح سلفة ثانية قبل سداد الأولى.")

        val serviceEnabled = LoanManager.isServiceEnabled(this)
        val serviceControl = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            background = roundedBackground(
                if (serviceEnabled) Color.rgb(235, 248, 241) else Color.rgb(250, 239, 239),
                if (serviceEnabled) Color.rgb(150, 215, 178) else Color.rgb(225, 175, 175),
                14.dp()
            )
        }
        val serviceStatus = TextView(this).apply {
            text = if (serviceEnabled) "خدمة سلفني مفعّلة" else "خدمة سلفني متوقفة"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (serviceEnabled) Color.rgb(20, 125, 75) else Color.rgb(175, 55, 55))
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        }
        serviceControl.addView(serviceStatus, LinearLayout.LayoutParams(0, -2, 1f))
        val serviceSwitch = Switch(this).apply {
            text = if (serviceEnabled) "تفعيل الخدمة" else "إيقاف الخدمة"
            isChecked = serviceEnabled
            textSize = 13f
            setOnCheckedChangeListener { _, checked ->
                LoanManager.setServiceEnabled(this@MainActivity, checked)
                Toast.makeText(
                    this@MainActivity,
                    if (checked) "تم تفعيل خدمة سلفني" else "تم إيقاف السلف الجديدة، وسيستمر تحصيل السلف السابقة",
                    Toast.LENGTH_LONG
                ).show()
                showLoans()
            }
        }
        serviceControl.addView(serviceSwitch, LinearLayout.LayoutParams(-2, -2).apply { marginStart = 8.dp() })
        content.addView(serviceControl, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8.dp(), 0, 12.dp()) })
        addText(if (serviceEnabled) "الخدمة تسمح بصرف سلفة جديدة للعملاء المؤهلين." else "لن يتم إرسال أي كرت سلفة جديد. السلف السابقة ستظل تُخصم عند مشتريات أصحابها.")

        val active = LoanManager.activeLoans(this)
        val pendingLoans = LoanManager.records(this).filter { it.status == "PENDING" }
        val customers = LoanManager.customerCounts(this)
        val totalCardBuyers = customers.size
        val eligible = customers.count { LoanManager.eligibility(this, it.first).eligible }
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun metric(label:String,value:String,color:Int):View = TextView(this).apply {
            text = "$label\n$value"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(color)
            background = roundedBackground(Color.WHITE,Color.rgb(218,230,243),14.dp())
            setPadding(8.dp(),14.dp(),8.dp(),14.dp())
        }
        summary.addView(metric("العملاء",totalCardBuyers.toString(),Color.rgb(20,85,145)),LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(3.dp(),4.dp(),3.dp(),8.dp()) })
        summary.addView(metric("المؤهلون",eligible.toString(),Color.rgb(22,128,83)),LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(3.dp(),4.dp(),3.dp(),8.dp()) })
        summary.addView(metric("المتسلفون",active.size.toString(),Color.rgb(190,105,20)),LinearLayout.LayoutParams(0,-2,1f).apply { setMargins(3.dp(),4.dp(),3.dp(),8.dp()) })
        content.addView(summary)

        addSectionTitle("المتسلفون حالياً")
        if(active.isEmpty()) addText("لا يوجد عملاء عليهم سلف حالياً.")
        active.forEach { loan ->
            val box=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(12.dp(),10.dp(),12.dp(),10.dp())
                background=roundedBackground(Color.WHITE,Color.rgb(232,204,160),12.dp())
            }
            box.addView(TextView(this).apply { text="${loan.phone}  •  100 ريال"; textSize=15f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(125,75,20)); gravity=Gravity.RIGHT })
            if (loan.status == "SETTLING") box.addView(TextView(this).apply { text="تسوية السلفة قيد تأكيد إرسال الرسالة"; textSize=12f; setTextColor(Color.rgb(170,105,30)); gravity=Gravity.RIGHT })
            box.addView(TextView(this).apply { text="تاريخ السلفة: ${loan.time}\nرقم الكرت: ${loan.card}"; textSize=12f; setTextColor(Color.rgb(80,95,110)); gravity=Gravity.RIGHT; setPadding(0,5.dp(),0,0) })
            content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,8.dp()) })
        }

        if (pendingLoans.isNotEmpty()) {
            addSectionTitle("طلبات سلفة قيد تأكيد الإرسال")
            pendingLoans.forEach { loan -> addText("${loan.phone}  •  ${loan.time}  •  طلب قيد المعالجة؛ لا تكرر الصرف") }
        }

        addSectionTitle("العملاء وعدد الكروت المشتراة")
        addText("يتم احتساب الكروت التي اكتمل إرسالها بنجاح فقط. الأهلية تتحدث تلقائياً من سجل المبيعات.")
        customers.take(250).forEach { (phone,_) ->
            val status=LoanManager.eligibility(this,phone)
            val count=status.count
            val row=LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL
                layoutDirection=View.LAYOUT_DIRECTION_RTL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(10.dp(),8.dp(),10.dp(),8.dp())
                background=roundedBackground(Color.WHITE,Color.rgb(225,235,245),10.dp())
            }
            row.addView(TextView(this).apply { text=phone; textSize=14f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(25,55,85)) },LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply { text="$count كرت"; textSize=13f; setTextColor(Color.rgb(80,100,120)); gravity=Gravity.CENTER })
            row.addView(TextView(this).apply { text=if(status.eligible) "مؤهل" else if(count>=10) "عليه سلفة/قيد المعالجة" else "${10-count} متبقية"; textSize=11f; typeface=Typeface.DEFAULT_BOLD; setTextColor(if(status.eligible)Color.rgb(20,130,80) else Color.rgb(170,105,30)); gravity=Gravity.CENTER; setPadding(8.dp(),0,0,0) })
            content.addView(row,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,5.dp()) })
        }
        addSectionTitle("سجل السلف")
        val history=LoanManager.records(this).filter { it.status!="ACTIVE" && it.status!="PENDING" }
        if(history.isEmpty()) addText("لا توجد عمليات سابقة.")
        val groupedLoanHistory = history.take(100).groupBy { it.phone }
        val loanHistoryChecks = linkedMapOf<String, CheckBox>()
        groupedLoanHistory.forEach { (phone, rows) ->
            val cb = CheckBox(this).apply {
                text = rows.joinToString("\n") { loan -> "${loan.phone}  •  ${loan.time}  •  ${when(loan.status){"PAID"->"تم السداد";"FAILED"->"لم يكتمل الإرسال";else->loan.status}}" }
                textSize = 13f; gravity = Gravity.RIGHT; layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            loanHistoryChecks[phone] = cb
            content.addView(cb, LinearLayout.LayoutParams(-1,-2))
        }
        if (groupedLoanHistory.isNotEmpty()) {
            addButton("تحديد الكل / إلغاء التحديد", false) {
                val allChecked = loanHistoryChecks.values.all { it.isChecked }
                loanHistoryChecks.values.forEach { it.isChecked = !allChecked }
            }
            addButton("🗑 حذف السجلات المحددة", true) {
                val selected = loanHistoryChecks.filterValues { it.isChecked }.keys.toSet()
                if (selected.isEmpty()) Toast.makeText(this, "حدد سجلًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
                else android.app.AlertDialog.Builder(this).setMessage("حذف سجل السلف التاريخي للأرقام المحددة؟ لن تتأثر السلف الحالية أو العدادات.")
                    .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ ->
                        val removed = LoanManager.deleteClosedHistoryPhones(this, selected)
                        Toast.makeText(this, "تم حذف $removed سجل تاريخي", Toast.LENGTH_SHORT).show(); showLoans()
                    }.show()
            }
        }
        addButton("تحديث البيانات",true) { showLoans() }
    }

    private fun showSmsReviewMessages() {
        currentScreen = "sms_review"
        content.removeAllViews()
        addBackButton()
        addTitle("رسائل تحتاج إلى مراجعة")
        val reviewSimSelector = Spinner(this).apply {
            tag = "review_sim_selector"
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("SIM 1", "SIM 2"))
            setSelection(if (operationLogSimSlot == 2) 1 else 0)
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        content.addView(reviewSimSelector, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 4.dp(), 0, 10.dp()) })
        reviewSimSelector.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val next = if (position == 1) 2 else 1
                if (operationLogSimSlot != next) { operationLogSimSlot = next; showSmsReviewMessages() }
            }
        }

        // This screen intentionally excludes successful operations.
        val unsuccessful = OperationLog.recent(this, 1000, operationLogSimSlot)
            .filter { it.status != "SUCCESS" }
        val failedCount = unsuccessful.count { it.status == "FAILED" }
        val reviewCount = unsuccessful.count { it.status == "REVIEW" }
        val pendingCount = unsuccessful.count { it.status == "PROCESSING" }

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(218, 232, 247), 16.dp())
        }
        summary.addView(TextView(this).apply {
            text = "العمليات غير الناجحة فقط"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(31, 76, 117))
        })
        summary.addView(TextView(this).apply {
            text = "فاشلة: $failedCount   •   تحتاج مراجعة: $reviewCount   •   غير مكتملة: $pendingCount"
            textSize = 13.5f
            setTextColor(Color.rgb(85, 101, 120))
            setPadding(0, 6.dp(), 0, 0)
        })
        content.addView(summary, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 8.dp(), 0, 12.dp())
        })

        if (unsuccessful.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(18.dp(), 26.dp(), 18.dp(), 26.dp())
                background = roundedBackground(Color.rgb(239, 250, 243), Color.rgb(192, 226, 203), 16.dp())
            }
            empty.addView(TextView(this).apply {
                text = "✅"
                textSize = 38f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, 52.dp()))
            empty.addView(TextView(this).apply {
                text = "لا توجد عمليات فاشلة أو غير مكتملة"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(35, 105, 66))
            }, LinearLayout.LayoutParams(-1, -2))
            content.addView(empty, LinearLayout.LayoutParams(-1, -2))
            addButton("🔄 تحديث القائمة") { showSmsReviewMessages() }
            return
        }

        addText("تظهر هنا العمليات التي فشلت أو لم تكتمل أو حُفظت للمراجعة فقط. العمليات الناجحة لا تظهر في هذه الصفحة.")
        unsuccessful.forEach { op ->
            val isReview = op.status == "REVIEW"
            val isFailed = op.status == "FAILED"
            val statusText = when (op.status) {
                "FAILED" -> "❌ فشلت عملية الإرسال"
                "REVIEW" -> "⚠️ الرسالة تحتاج إلى مراجعة"
                "PROCESSING" -> "⏳ العملية لم تكتمل"
                else -> "⚠️ نتيجة غير ناجحة: ${op.status}"
            }
            val reason = when {
                op.error.isNotBlank() -> op.error
                op.status == "PROCESSING" -> "لم تُسجّل نتيجة نهائية للإرسال بعد؛ تحقق من سجل الإرسال قبل إعادة المحاولة لتجنب التكرار."
                op.status == "FAILED" -> "لم يُسجّل سبب محدد للفشل."
                else -> "لم يُسجّل سبب محدد؛ راجع نص الرسالة والبيانات المستخرجة."
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                background = roundedBackground(
                    if (isFailed) Color.rgb(255, 241, 239) else if (isReview) Color.rgb(255, 248, 230) else Color.rgb(242, 247, 253),
                    if (isFailed) Color.rgb(238, 190, 185) else if (isReview) Color.rgb(230, 190, 100) else Color.rgb(205, 221, 239),
                    14.dp()
                )
            }
            box.addView(TextView(this@MainActivity).apply {
                text = statusText
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isFailed) Color.rgb(170, 45, 35) else if (isReview) Color.rgb(140, 90, 15) else Color.rgb(40, 80, 125))
            })
            box.addView(TextView(this@MainActivity).apply {
                text = "الوقت: ${op.time}\nالمبلغ: ${if (op.amount > 0) "${op.amount} ريال" else "غير محدد"}\nرقم المستفيد: ${op.phone.ifBlank { "غير محدد" }}"
                textSize = 13.5f
                setTextColor(Color.rgb(45, 57, 70))
                setPadding(0, 6.dp(), 0, 0)
            })
            if (op.card.isNotBlank()) {
                box.addView(TextView(this@MainActivity).apply {
                    text = "الكرت: ${op.card}"
                    textSize = 13.5f
                    setTextColor(Color.rgb(45, 57, 70))
                    setPadding(0, 4.dp(), 0, 0)
                })
            }
            box.addView(TextView(this@MainActivity).apply {
                text = "سبب الفشل / المراجعة:\n$reason"
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(145, 55, 35))
                setPadding(0, 8.dp(), 0, 0)
            })
            content.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 9.dp())
            })
        }
        addButton("🔄 تحديث القائمة") { showSmsReviewMessages() }
    }

    private fun showCustomWalletSmsFormats() {
        currentScreen = "custom_wallet_sms"
        content.removeAllViews()
        addBackButton()
        addTitle("إضافة وتعديل صيغ الرسائل الواردة")
        addText("المعالجة التلقائية للحوالات مقتصرة على جيب وجوالي فقط. يمكنك الاحتفاظ بصيغ الرسائل الأخرى وتعديلها هنا، لكنها لا تُفعّل إرسال الكروت تلقائيًا.")
        val prefs = getSharedPreferences("custom_wallet_sms", MODE_PRIVATE)
        fun loadWallets(): org.json.JSONArray = try {
            org.json.JSONArray(prefs.getString("wallets", "[]") ?: "[]")
        } catch (_: Exception) { org.json.JSONArray() }
        fun field(label: String, value: String, hint: String, multi: Boolean = false): EditText {
            addSectionTitle(label)
            return EditText(this).apply {
                setText(value)
                this.hint = hint
                textSize = 15f
                gravity = Gravity.TOP or Gravity.RIGHT
                if (multi) { minLines = 3; maxLines = 6 }
                inputType = if (multi) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE else android.text.InputType.TYPE_CLASS_TEXT
                setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                background = roundedBackground(Color.rgb(247,250,254), Color.rgb(203,222,242), 12.dp())
                content.addView(this, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4.dp(), 0, 8.dp()) })
            }
        }
        fun refreshList() {
            val list = loadWallets()
            addSectionTitle("المحافظ المضافة")
            if (list.length() == 0) addText("لم تضف محافظ إضافية حتى الآن.")
            for (i in 0 until list.length()) {
                val item = list.optJSONObject(i) ?: continue
                val name = item.optString("name")
                val sender = item.optString("sender")
                val sample = item.optString("sample")
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(218,232,247), 14.dp())
                }
                card.addView(TextView(this).apply {
                    text = "$name\nالمرسل: $sender\nالصيغة: $sample"
                    textSize = 14f; setTextColor(Color.rgb(31,76,117))
                }, LinearLayout.LayoutParams(-1, -2))
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(Button(this@MainActivity).apply {
                    text = "✏️ تعديل"
                    setOnClickListener { showCustomWalletSmsEditor(i) }
                }, LinearLayout.LayoutParams(0, 44.dp(), 1f))
                actions.addView(Button(this@MainActivity).apply {
                    text = "🗑️ حذف"
                    setOnClickListener {
                        val updated = loadWallets()
                        val rebuilt = org.json.JSONArray()
                        for (j in 0 until updated.length()) if (j != i) rebuilt.put(updated.getJSONObject(j))
                        prefs.edit().putString("wallets", rebuilt.toString()).apply()
                        showCustomWalletSmsFormats()
                    }
                }, LinearLayout.LayoutParams(0, 44.dp(), 1f))
                card.addView(actions)
                content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4.dp(), 0, 8.dp()) })
            }
        }
        addButton("➕ إضافة محفظة وصيغة جديدة", true) { showCustomWalletSmsEditor(-1) }
        refreshList()
    }

    private fun showCustomWalletSmsEditor(index: Int) {
        currentScreen = "custom_wallet_sms_editor"
        content.removeAllViews()
        addBackButton()
        addTitle(if (index < 0) "إضافة محفظة جديدة" else "تعديل صيغة المحفظة")
        val prefs = getSharedPreferences("custom_wallet_sms", MODE_PRIVATE)
        val list = try { org.json.JSONArray(prefs.getString("wallets", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        val old = if (index >= 0) list.optJSONObject(index) ?: org.json.JSONObject() else org.json.JSONObject()
        fun addInput(label: String, initial: String, hintText: String, multiline: Boolean = false): EditText {
            addSectionTitle(label)
            val input = EditText(this).apply {
                setText(initial); hint = hintText; textSize = 15f; gravity = Gravity.TOP or Gravity.RIGHT
                if (multiline) { minLines = 4; maxLines = 7 }
                inputType = if (multiline) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE else android.text.InputType.TYPE_CLASS_TEXT
                setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                background = roundedBackground(Color.rgb(247,250,254), Color.rgb(203,222,242), 12.dp())
            }
            content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4.dp(), 0, 10.dp()) })
            return input
        }
        val name = addInput("اسم المحفظة", old.optString("name"), "مثال: محفظة جديدة")
        val sender = addInput("اسم المرسل أو رقم/معرّف المرسل كما يظهر حرفيًا", old.optString("sender"), "اكتب معرّف المرسل بدقة")
        val sample = addInput("صيغة الرسالة الواردة أو مثال حقيقي", old.optString("sample"), "مثال: تم استلام {amount} من {recipient}، الرصيد {balance}", true)
        addText("تُستخدم هذه البيانات لتعريف المرسل وتوثيق صيغة الرسالة. لا تعتمد على الصيغة وحدها إذا كان مبلغ التحويل أو المستفيد غير واضح؛ الرسائل غير الواضحة يجب أن تبقى للمراجعة.")
        addButton("💾 حفظ الصيغة", true) {
            val n = name.text.toString().trim()
            val from = sender.text.toString().trim()
            val format = sample.text.toString().trim()
            if (n.isBlank() || from.isBlank() || format.isBlank()) {
                Toast.makeText(this, "أكمل اسم المحفظة ومعرّف المرسل وصيغة الرسالة", Toast.LENGTH_LONG).show()
                return@addButton
            }
            val existing = try { org.json.JSONArray(prefs.getString("wallets", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
            val rebuilt = org.json.JSONArray()
            for (j in 0 until existing.length()) {
                if (j != index) rebuilt.put(existing.getJSONObject(j))
            }
            rebuilt.put(org.json.JSONObject().put("name", n).put("sender", from).put("sample", format))
            prefs.edit().putString("wallets", rebuilt.toString()).apply()
            Toast.makeText(this, "تم حفظ صيغة المحفظة على هذا الجهاز", Toast.LENGTH_SHORT).show()
            showCustomWalletSmsFormats()
        }
    }

    private fun navButton(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setSingleLine(true)
        setTextColor(Color.rgb(31, 91, 139))
        background = roundedBackground(Color.rgb(247, 250, 253), Color.rgb(213, 225, 235), 1.dp())
        setPadding(17.dp(), 0, 17.dp(), 0)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, 46.dp()).apply {
            setMargins(4.dp(), 0, 4.dp(), 0)
        }
    }

    private fun showUnavailableCards() {
        currentScreen = "unavailable_cards"
        content.removeAllViews()
        addBackButton()
        addTitle("🚫 الكروت غير المتوفرة")
        addText("إذا وصلت حوالة ولم توجد فئة مطابقة أو لم يتوفر كرت في مخزون الشريحة، يرسل التطبيق رسالتك مرة واحدة فقط للرقم الذي استقبل الكرت بعد ربط الأرقام، بشرط أن يكون المبلغ أقل من 500 ريال.")

        val enabled = UnavailableCardManager.isEnabled(this)
        val status = TextView(this).apply {
            text = if (enabled) "🟢 الخدمة مفعّلة" else "🔴 الخدمة متوقفة"
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (enabled) Color.rgb(25, 130, 80) else Color.rgb(180, 55, 55))
            gravity = Gravity.CENTER; setPadding(8.dp(), 12.dp(), 8.dp(), 8.dp())
        }
        content.addView(status)
        val toggle = Switch(this).apply {
            text = if (enabled) "إيقاف الخدمة" else "تفعيل الخدمة"
            isChecked = enabled; textSize = 16f; gravity = Gravity.RIGHT
        }
        toggle.setOnCheckedChangeListener { _, checked ->
            UnavailableCardManager.setEnabled(this, checked)
            showUnavailableCards()
            Toast.makeText(this, if (checked) "تم تفعيل إشعارات الكروت غير المتوفرة" else "تم إيقاف إشعارات الكروت غير المتوفرة", Toast.LENGTH_SHORT).show()
        }
        content.addView(toggle, LinearLayout.LayoutParams(-1, -2))

        addSectionTitle("نص الرسالة النصية")
        val message = EditText(this).apply {
            setText(UnavailableCardManager.message(this@MainActivity))
            hint = "اكتب رسالة الاعتذار التي ستصل للمشترك"
            minLines = 3; maxLines = 6; textSize = 15f
            gravity = Gravity.RIGHT or Gravity.TOP
            setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(203, 222, 242), 12.dp())
        }
        content.addView(message, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10.dp() })
        addButton("💾 حفظ نص الرسالة", true) {
            val value = message.text.toString().trim()
            if (value.isBlank()) {
                Toast.makeText(this, "اكتب نص الرسالة أولاً", Toast.LENGTH_LONG).show()
            } else {
                UnavailableCardManager.setMessage(this, value)
                Toast.makeText(this, "تم حفظ نص الرسالة", Toast.LENGTH_SHORT).show()
            }
        }

        addSectionTitle("سجل الإشعارات المرسلة")
        addText("تم إرسال الرسالة إلى ${UnavailableCardManager.sentCount(this)} رقمًا. إشعارات قيد التأكيد: ${UnavailableCardManager.pendingCount(this)}. لا تُرسل الرسالة إذا كان المبلغ 500 ريال أو أكثر.")
        val history = UnavailableCardManager.history(this)
        if (history.isEmpty()) addText("لا توجد أرقام أُرسلت إليها الرسالة حتى الآن.")
        else history.take(100).forEach { row ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(12.dp(), 9.dp(), 12.dp(), 9.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(222, 234, 246), 12.dp())
            }
            card.addView(TextView(this).apply {
                text = "${row.phone} • ${row.amount} ريال • SIM${row.sim}\n${row.time}"
                textSize = 14f; setTextColor(Color.rgb(45, 65, 85)); gravity = Gravity.RIGHT
            })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6.dp() })
        }
    }

    private fun showCollectAndWin() {
        currentScreen = "collect_win"
        content.removeAllViews()
        addBackButton()
        addTitle("🎁 اجمع واربح")
        addText("يُحسب الشراء بعد تأكيد إرسال الكرت بنجاح فقط. لكل رقم جوال ولكل فئة عداد مستقل. عند اكتمال العدد يرسل التطبيق كرت الهدية من مخزون الشريحة التي تمت منها عملية الشراء.")

        val enabled = RewardManager.isEnabled(this)
        val status = TextView(this).apply {
            text = if (enabled) "🟢 نظام اجمع واربح مفعّل" else "🔴 نظام اجمع واربح متوقف"
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (enabled) Color.rgb(25, 130, 80) else Color.rgb(180, 55, 55))
            gravity = Gravity.CENTER; setPadding(8.dp(), 12.dp(), 8.dp(), 8.dp())
        }
        content.addView(status)
        val toggle = Switch(this).apply {
            text = if (enabled) "إيقاف النظام" else "تفعيل النظام"
            isChecked = enabled; textSize = 16f; gravity = Gravity.RIGHT
        }
        toggle.setOnCheckedChangeListener { _, checked ->
            RewardManager.setEnabled(this, checked)
            showCollectAndWin()
            Toast.makeText(this, if (checked) "تم تفعيل اجمع واربح" else "تم إيقاف اجمع واربح", Toast.LENGTH_SHORT).show()
        }
        content.addView(toggle, LinearLayout.LayoutParams(-1, -2))

        val categories = (CardStore.categories(this, 1) + CardStore.categories(this, 2)).distinct().sorted()
        if (categories.isEmpty()) {
            addText("أضف فئات الكروت أولاً حتى تتمكن من إعداد المكافآت.")
            return
        }
        addSectionTitle("إعداد مكافأة")
        addText("فئة المشتريات التي سيُحسب عدد مرات شرائها")
        val purchaseSpinner = Spinner(this).apply { adapter = styledSpinnerAdapter(categories.map { "$it ريال" }) }
        content.addView(purchaseSpinner, LinearLayout.LayoutParams(-1, 48.dp()))

        addSectionTitle("عدد مرات الشراء المطلوبة")
        val required = EditText(this).apply {
            hint = "مثال: 10"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 16f; gravity = Gravity.CENTER
            setPadding(10.dp(), 8.dp(), 10.dp(), 8.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(203, 222, 242), 10.dp())
        }
        content.addView(required, LinearLayout.LayoutParams(-1, 48.dp()))

        addSectionTitle("فئة كرت الهدية")
        val giftSpinner = Spinner(this).apply { adapter = styledSpinnerAdapter(categories.map { "$it ريال" }) }
        content.addView(giftSpinner, LinearLayout.LayoutParams(-1, 48.dp()))
        addText("يُخصم كرت الهدية من مخزون نفس الشريحة التي استقبلت عملية الشراء. تأكد من توفر فئة الهدية في الشريحتين إذا كان العملاء يشترون عبرهما.")
        addButton("💾 حفظ إعداد المكافأة", true) {
            val purchase = categories.getOrNull(purchaseSpinner.selectedItemPosition) ?: 0
            val gift = categories.getOrNull(giftSpinner.selectedItemPosition) ?: 0
            val count = required.text.toString().toIntOrNull() ?: 0
            if (count <= 0) {
                Toast.makeText(this, "أدخل عدد مرات شراء صحيحًا", Toast.LENGTH_LONG).show()
            } else if (RewardManager.saveRule(this, purchase, count, gift)) {
                Toast.makeText(this, "تم حفظ مكافأة فئة $purchase ريال", Toast.LENGTH_SHORT).show()
                showCollectAndWin()
            } else Toast.makeText(this, "تعذر حفظ إعداد المكافأة", Toast.LENGTH_LONG).show()
        }

        addSectionTitle("المكافآت المحددة")
        val rules = RewardManager.rules(this)
        if (rules.isEmpty()) addText("لم تضف أي مكافأة بعد.")
        rules.forEach { rule ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(222, 234, 246), 12.dp())
            }
            row.addView(TextView(this).apply {
                text = "كل ${rule.requiredCount} عملية شراء من فئة ${rule.purchaseAmount} ريال ← هدية ${rule.giftAmount} ريال"
                textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(25, 65, 100)); gravity = Gravity.RIGHT
            })
            val del = Button(this).apply {
                text = "حذف الإعداد"
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setMessage("هل تريد حذف إعداد هذه المكافأة؟ لن تُحذف سجلات الهدايا السابقة.")
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حذف") { _, _ -> RewardManager.deleteRule(this@MainActivity, rule.id); showCollectAndWin() }
                        .show()
                }
            }
            row.addView(del)
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7.dp() })
        }

        addSectionTitle("عدادات العملاء")
        val customers = SaleCounter.all(this).associate { it.first to it.second }
        if (customers.isEmpty() || rules.isEmpty()) addText("ستظهر أعداد المشتريات هنا بعد نجاح عمليات الإرسال.")
        customers.toSortedMap().forEach { (phone, totalSales) ->
            if (phone.length == 9) {
                val lines = rules.map { rule -> "فئة ${rule.purchaseAmount}: ${RewardManager.count(this, phone, rule.purchaseAmount)} / ${rule.requiredCount}" }
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 8.dp(), 10.dp(), 8.dp()); background = roundedBackground(Color.WHITE, Color.rgb(222,234,246), 10.dp()) }
                box.addView(TextView(this).apply { text = phone + "\n" + lines.joinToString("\n"); textSize = 14f; setTextColor(Color.rgb(50,65,80)); gravity = Gravity.RIGHT })
                content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5.dp() })
            }
        }

        addButton("🔄 فحص الهدايا المستحقة الآن", true) {
            val gifts = RewardManager.processEligible(this)
            if (gifts.isEmpty()) {
                Toast.makeText(this, "لا توجد هدايا مستحقة بمخزون متوفر حاليًا", Toast.LENGTH_LONG).show()
            } else {
                var sent = 0
                gifts.forEach { if (RewardGiftSender.send(this, it)) sent++ }
                Toast.makeText(this, "تم تجهيز $sent هدية للإرسال، انتظر تأكيد الرسائل", Toast.LENGTH_LONG).show()
                showCollectAndWin()
            }
        }

        addSectionTitle("هدايا قيد التأكيد")
        val pending = RewardManager.pending(this)
        if (pending.isEmpty()) addText("لا توجد هدايا معلقة.")
        pending.forEach { gift -> addText("${gift.phone} • هدية ${gift.giftAmount} ريال • SIM${gift.sim} • الكرت محجوز بانتظار مراجعة نتيجة الإرسال: ${gift.card}") }

        addSectionTitle("سجل الهدايا المرسلة")
        val history = RewardManager.history(this)
        if (history.isEmpty()) addText("لا توجد هدايا مرسلة حتى الآن.")
        val groupedGiftHistory = history.take(100).groupBy { it.phone }
        val giftHistoryChecks = linkedMapOf<String, CheckBox>()
        groupedGiftHistory.forEach { (phone, rows) ->
            val cb = CheckBox(this).apply {
                text = rows.joinToString("\n") { gift -> "${gift.phone} • اشترى ${gift.purchaseAmount} • هدية ${gift.giftAmount} • SIM${gift.sim}\nرقم الهدية: ${gift.card} • ${gift.time}" }
                textSize = 13f; gravity = Gravity.RIGHT; layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            giftHistoryChecks[phone] = cb
            content.addView(cb, LinearLayout.LayoutParams(-1,-2))
        }
        if (groupedGiftHistory.isNotEmpty()) {
            addButton("تحديد الكل / إلغاء التحديد", false) {
                val allChecked = giftHistoryChecks.values.all { it.isChecked }
                giftHistoryChecks.values.forEach { it.isChecked = !allChecked }
            }
            addButton("🗑 حذف سجلات الهدايا المحددة", true) {
                val selected = giftHistoryChecks.filterValues { it.isChecked }.keys.toSet()
                if (selected.isEmpty()) Toast.makeText(this, "حدد رقمًا واحدًا على الأقل", Toast.LENGTH_SHORT).show()
                else android.app.AlertDialog.Builder(this).setMessage("حذف سجلات الهدايا للأرقام المحددة فقط؟ لن تتأثر العدادات أو الهدايا المعلقة.")
                    .setNegativeButton("إلغاء", null).setPositiveButton("حذف") { _, _ ->
                        val removed = RewardManager.deleteHistoryPhones(this, selected)
                        Toast.makeText(this, "تم حذف $removed سجل هدية", Toast.LENGTH_SHORT).show(); showCollectAndWin()
                    }.show()
            }
        }

    }

    private fun showServices() {
        currentScreen = "services"
        content.removeAllViews()
        addBackButton()
        addTitle("⚙️ الخدمات والإرسال")
        addText("من هنا تستطيع إيقاف أو تشغيل استقبال الحوالات ومعالجة طابور الإرسال. عند الإيقاف لا تضيع الحوالات؛ تبقى محفوظة حتى تعيد التشغيل.")

        val enabled = ServiceControl.isEnabled(this)
        val status = TextView(this).apply {
            text = if (enabled) "🟢 الخدمات مفعّلة" else "🔴 الخدمات متوقفة (وضع الصيانة)"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (enabled) Color.rgb(28,120,75) else Color.rgb(180,55,55))
            gravity = Gravity.CENTER
            setPadding(8.dp(), 14.dp(), 8.dp(), 14.dp())
        }
        content.addView(status)

        val toggle = Switch(this).apply {
            text = if (enabled) "إيقاف الخدمات مؤقتًا" else "تشغيل الخدمات"
            textSize = 16f
            isChecked = enabled
            gravity = Gravity.RIGHT
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
        }
        toggle.setOnCheckedChangeListener { _, checked ->
            ServiceControl.setEnabled(this, checked)
            if (checked) CardQueueProcessor.process(this)
            showServices()
            Toast.makeText(this, if (checked) "تم تشغيل الخدمات واستئناف الطابور" else "تم إيقاف الخدمات. الحوالات الجديدة ستنتظر في الطابور", Toast.LENGTH_LONG).show()
        }
        content.addView(toggle, LinearLayout.LayoutParams(-1, -2))

        addSectionTitle("طابور الإرسال")
        val pendingItems = PendingQueue.pending(this)
        addText("عدد الحوالات المعلقة: " + pendingItems.size)
        if (pendingItems.isEmpty()) {
            addText("لا توجد حوالات معلقة حاليًا.")
        } else {
            pendingItems.take(30).forEachIndexed { index, item ->
                val error = if (item.error.isBlank()) "" else "\n⚠️ " + item.error
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                    setBackgroundColor(Color.WHITE)
                }
                card.addView(TextView(this).apply {
                    text = (index + 1).toString() + ". " + item.amount + " ريال → " + item.phone +
                        " • SIM" + item.sim + " • " + when(item.state) { "PROCESSING", "REVIEW" -> "⚠️ يحتاج مراجعة يدوية"; "RETRYABLE" -> "جاهز لإعادة المحاولة"; else -> if(item.allowed) "مسموح بالإرسال" else "في الانتظار" } + error +
                        (if(item.state=="PROCESSING" || item.state=="REVIEW") "\nلن تعاد هذه الحوالة تلقائيًا منعًا لصرف كرت ثانٍ. تحقق أولًا هل وصل الكرت للمشترك." else "")
                    textSize = 16f
                    setTextColor(Color.rgb(35, 35, 35))
                }, LinearLayout.LayoutParams(-1, -2))
                val actions = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                }
                val allowButton = Button(this).apply {
                    text = if(item.state=="PROCESSING" || item.state=="REVIEW") "إعادة المحاولة بعد التحقق" else if (item.allowed) "سماح ✓" else "سماح"
                    setOnClickListener {
                        if(item.state=="PROCESSING" || item.state=="REVIEW") {
                            android.app.AlertDialog.Builder(this@MainActivity)
                                .setTitle("⚠️ مراجعة حوالة غير محسومة")
                                .setMessage("استخدم إعادة المحاولة فقط بعد التأكد من سجل الرسائل أن الكرت السابق لم يُرسل. إذا كان قد أُرسل، فقد يؤدي ذلك إلى إرسال كرت آخر لنفس الحوالة.")
                                .setNegativeButton("إلغاء", null)
                                .setPositiveButton("تأكدت، أعد المحاولة") { _, _ ->
                                    val interrupted = OperationLog.pendingForQueue(this@MainActivity, item.id)
                                    if(interrupted != null) {
                                        // The operator explicitly confirmed the SMS was not sent;
                                        // return the reserved card before retrying the same transaction.
                                        CardStore.returnCard(this@MainActivity, interrupted.amount, interrupted.card, item.sim)
                                        OperationLog.finish(this@MainActivity, interrupted.id, false, "أُعيد الكرت للمخزون بعد تأكيد المشغّل أن الرسالة لم تُرسل")
                                    } else {
                                        Toast.makeText(this@MainActivity, "لم يُعثر على سجل الكرت السابق؛ أوقفت إعادة المحاولة لحماية المخزون. راجع المخزون وسجل الرسائل يدويًا أولًا.", Toast.LENGTH_LONG).show()
                                        return@setPositiveButton
                                    }
                                    if(PendingQueue.retryAfterReview(this@MainActivity,item.id)) {
                                        CardQueueProcessor.process(this@MainActivity)
                                        showServices()
                                    }
                                }.show()
                        } else {
                            PendingQueue.allow(this@MainActivity, item.id)
                            CardQueueProcessor.process(this@MainActivity)
                            Toast.makeText(this@MainActivity, "تم السماح بمعالجة الحوالة المحددة", Toast.LENGTH_SHORT).show()
                            showServices()
                        }
                    }
                }
                val ignoreButton = Button(this).apply {
                    text = "تجاهل"
                    setOnClickListener {
                        SmsDedup.markProcessed(this@MainActivity, item.fingerprint)
                        PendingQueue.remove(this@MainActivity, item.id)
                        Toast.makeText(this@MainActivity, "تم تجاهل الحوالة ومنع إرسال كرت آخر لها", Toast.LENGTH_LONG).show()
                        showServices()
                    }
                }
                actions.addView(allowButton, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, 6.dp(), 0) })
                actions.addView(ignoreButton, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(6.dp(), 0, 0, 0) })
                card.addView(actions, LinearLayout.LayoutParams(-1, -2))
                content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 8.dp()) })
            }
            if (pendingItems.size > 30) addText("يوجد " + (pendingItems.size - 30) + " حوالة إضافية في الطابور.")
        }

        addButton("🔄 معالجة الطابور الآن", true) {
            if (ServiceControl.isEnabled(this)) {
                CardQueueProcessor.process(this)
                Toast.makeText(this, "تم بدء معالجة الطابور", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "الخدمات متوقفة. شغّلها أولًا.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDashboard() {
        currentScreen = "dashboard"
        updateBottomNav("dashboard")
        content.removeAllViews()

        dashboardCategoryViews.clear()

        val today = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.US).format(java.util.Date())
        val pendingCount = OperationLog.pending(this).size
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val todaySales = CardStore.sales(this).filter { it.time.startsWith(todayKey) }

        // Modern Hero Card
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(18.dp(), 18.dp(), 18.dp(), 18.dp())
            background = gradientBackground(Color.rgb(13, 86, 150), Color.rgb(25, 118, 194), 18.dp())
            elevation = 3.dp().toFloat()
        }
        val heroHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        heroHeader.addView(TextView(this).apply {
            text = "الكامل بلس"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(heroHeader)
        hero.addView(TextView(this).apply {
            text = "إدارة الكروت والإرسال والمبيعات بسهولة"
            textSize = 12.5f
            setTextColor(Color.rgb(215, 235, 252))
            gravity = Gravity.RIGHT
            setPadding(0, 4.dp(), 0, 10.dp())
        }, LinearLayout.LayoutParams(-1, -2))
        val heroBadges = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val dateBadge = TextView(this).apply {
            text = "📅  $today"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(10.dp(), 5.dp(), 10.dp(), 5.dp())
            background = roundedBackground(Color.argb(40, 255, 255, 255), 0, 10.dp())
        }
        val salesBadge = TextView(this).apply {
            text = "📈  ${todaySales.size} عملية بيع اليوم"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(220, 252, 231))
            setPadding(10.dp(), 5.dp(), 10.dp(), 5.dp())
            background = roundedBackground(Color.argb(40, 255, 255, 255), 0, 10.dp())
        }
        heroBadges.addView(dateBadge, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = 8.dp() })
        heroBadges.addView(salesBadge, LinearLayout.LayoutParams(-2, -2))
        hero.addView(heroBadges)
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4.dp(), 0, 12.dp()) })

        // Background service banner
        val backgroundEnabled = BackgroundHelper.isIgnoringBatteryOptimizations(this)
        val backgroundStatus = TextView(this).apply {
            text = if (backgroundEnabled) "🟢  العمل في الخلفية مفعّل — اضغط للمراجعة" else "🟠  العمل في الخلفية يحتاج إلى تفعيل — اضغط هنا"
            textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(if (backgroundEnabled) Color.rgb(6, 95, 70) else Color.rgb(146, 64, 14))
            setPadding(12.dp(), 11.dp(), 12.dp(), 11.dp())
            background = roundedBackground(
                if (backgroundEnabled) Color.rgb(236, 253, 245) else Color.rgb(255, 251, 235),
                if (backgroundEnabled) Color.rgb(167, 243, 208) else Color.rgb(253, 230, 138),
                14.dp()
            )
            setOnClickListener { BackgroundHelper.openBatteryOptimizationSettings(this@MainActivity) }
        }
        content.addView(backgroundStatus, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 12.dp()) })

        // Clean Symmetric Stat Cards with prominent numbers
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val stockCard = statCard("📦 المخزون المتبقي", CardStore.totalStock(this).toString(), Color.rgb(13, 91, 158), "كرت متوفر")
        dashboardStockText = stockCard.second
        val soldCard = statCard("🛒 الكروت المباعة", CardStore.salesCount(this).toString(), Color.rgb(5, 150, 105), "كرت مباع")
        dashboardSoldText = soldCard.second
        stats.addView(stockCard.first, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, 5.dp(), 0) })
        stats.addView(soldCard.first, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(5.dp(), 0, 0, 0) })
        content.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14.dp() })

        addSectionTitle("الوصول السريع")
        addButton("⚠️ مهم | بادئات أرقام الكروت حسب الفئة", true) { showCategoryPrefixes() }

        fun actionTile(icon: String, title: String, subtitle: String, action: () -> Unit): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true
                setPadding(8.dp(), 13.dp(), 8.dp(), 12.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(205, 225, 244), 20.dp())
                elevation = 3.dp().toFloat()
                addView(TextView(this@MainActivity).apply { text = icon; textSize = 27f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 38.dp()))
                addView(TextView(this@MainActivity).apply { text = title; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(31, 70, 108)); gravity = Gravity.CENTER; setPadding(0, 4.dp(), 0, 0) }, LinearLayout.LayoutParams(-1, -2))
                addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 12f; setTextColor(Color.rgb(88, 111, 133)); gravity = Gravity.CENTER; setPadding(4.dp(), 5.dp(), 4.dp(), 0); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, -2))
                setOnClickListener { action() }
                setOnTouchListener { view, event -> if (event.action == android.view.MotionEvent.ACTION_DOWN) view.alpha = 0.78f; if (event.action == android.view.MotionEvent.ACTION_UP || event.action == android.view.MotionEvent.ACTION_CANCEL) view.alpha = 1f; false }
            }
        }
        fun addActionRow(a: View, b: View) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            row.addView(a, LinearLayout.LayoutParams(0, 106.dp(), 1f).apply { setMargins(0, 0, 5.dp(), 0) })
            row.addView(b, LinearLayout.LayoutParams(0, 106.dp(), 1f).apply { setMargins(5.dp(), 0, 0, 0) })
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9.dp() })
        }
        addActionRow(actionTile("➕", "إضافة الكروت", "إدخال بطاقات جديدة") { showAddCards() }, actionTile("📦", "المخزون", "عرض الأرقام المتبقية") { showStock() })
        addActionRow(actionTile("🛒", "المبيعات", "سجل الكروت المباعة") { showSales() }, actionTile("🔗", "ربط الأرقام", "إدارة الأرقام البديلة") { showAlternateNumbers() })
        addActionRow(actionTile("📱", "المخزون حسب SIM", "عرض SIM1 وSIM2") { showSimInventory() }, actionTile("📊", "المبيعات حسب SIM", "إحصاءات الشرائح") { showSimSales() })

        if (pendingCount > 0) {
            addButton("⚠️  مراجعة $pendingCount عملية معلقة", true) { showOperations() }
        }

        addSectionTitle("حالة الإرسال")
        val serviceCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(220, 233, 246), 16.dp())
            val enabled = ServiceControl.isEnabled(this@MainActivity)
            addView(TextView(this@MainActivity).apply { text = if (enabled) "●" else "●"; textSize = 23f; setTextColor(if (enabled) Color.rgb(30, 160, 95) else Color.rgb(210, 65, 65)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(32.dp(), 40.dp()))
            addView(TextView(this@MainActivity).apply { text = if (enabled) "الخدمات مفعّلة" else "الخدمات متوقفة"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(35, 69, 102)); gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; setPadding(8.dp(), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@MainActivity).apply { text = "إدارة  ›"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(27, 110, 175)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-2, 40.dp()))
            setOnClickListener { showServices() }
        }
        content.addView(serviceCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12.dp() })

        addSectionTitle("المخزون حسب الفئة")
        CardStore.categories(this, categoryManagementSimSlot).forEachIndexed { index, amount ->
            val categoryCard = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                background = roundedBackground(
                    if (index % 2 == 0) Color.WHITE else Color.rgb(247, 251, 255),
                    Color.rgb(203, 224, 244), 16.dp()
                )
                elevation = 1.dp().toFloat()
                setOnClickListener { showStock() }
            }
            categoryCard.addView(TextView(this).apply {
                text = "🎫"
                textSize = 23f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(26, 103, 170))
            }, LinearLayout.LayoutParams(38.dp(), 42.dp()))
            val categoryName = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(this@MainActivity).apply {
                    text = "فئة $amount ريال"
                    textSize = 15f
                    typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    setTextColor(Color.rgb(29, 72, 112))
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2))
                addView(TextView(this@MainActivity).apply {
                    text = "اضغط لعرض تفاصيل المخزون"
                    textSize = 11f
                    setTextColor(Color.rgb(103, 128, 151))
                    gravity = Gravity.RIGHT
                    setPadding(0, 3.dp(), 0, 0)
                }, LinearLayout.LayoutParams(-1, -2))
            }
            categoryCard.addView(categoryName, LinearLayout.LayoutParams(0, -2, 1f).apply {
                setMargins(8.dp(), 0, 8.dp(), 0)
            })
            val valueView = TextView(this).apply {
                tag = "stock_value"
                text = "0 كرت"
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(22, 112, 82))
                setPadding(10.dp(), 8.dp(), 10.dp(), 8.dp())
                background = roundedBackground(Color.rgb(229, 247, 238), Color.rgb(190, 229, 210), 12.dp())
            }
            dashboardCategoryViews[amount] = valueView
            categoryCard.addView(valueView, LinearLayout.LayoutParams(-2, -2))
            content.addView(categoryCard, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 8.dp())
            })
        }
        addButton("🏷️  إدارة فئات الكروت") { showCategories() }
        addButton("📋  سجل العمليات") { showOperations() }
        addButton("💾  النسخ الاحتياطي والاستعادة") { showBackup() }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !BackgroundHelper.isIgnoringBatteryOptimizations(this)) {
            addButton("⚡  تحسين العمل بالخلفية", true) { BackgroundHelper.openBatteryOptimizationSettings(this) }
            addText("لضمان استقبال الرسائل عند إغلاق الشاشة، فعّل استثناء البطارية للتطبيق.")
        }

        val copyrightFooter = TextView(this).apply {
            text = "© الكامل بلس — جميع حقوق الملكية محفوظة"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(31, 76, 117))
            setPadding(12.dp(), 14.dp(), 12.dp(), 14.dp())
            background = roundedBackground(Color.rgb(232, 243, 253), Color.rgb(176, 211, 242), 14.dp())
        }
        copyrightFooter.apply {
            isClickable = true
            isFocusable = true
            setOnClickListener {
                try {
                    startActivity(android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://wa.me/967772072056")
                    ))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح واتساب", Toast.LENGTH_SHORT).show()
                }
            }
        }
        content.addView(copyrightFooter, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 14.dp(), 0, 10.dp())
        })
        refreshDashboardStock()
    }

    private fun refreshDashboardStock() {
        dashboardStockText?.text = CardStore.totalStock(this).toString()
        dashboardSoldText?.text = CardStore.salesCount(this).toString()
        CardStore.categories(this).forEach { amount ->
            dashboardCategoryViews[amount]?.text = "${CardStore.count(this, amount)} كرت متبقي"
        }
    }


    private var categoryPrefixSimSlot = 1
    private fun categoryPrefixPrefs(sim: Int = categoryPrefixSimSlot): android.content.SharedPreferences {
        val name = "card_category_prefixes_sim" + if (sim == 2) "2" else "1"
        val prefs = getSharedPreferences(name, MODE_PRIVATE)
        // Preserve existing prefix settings by migrating the legacy shared values to SIM1 once.
        if (sim != 2 && !prefs.getBoolean("_legacy_migrated", false)) {
            val legacy = getSharedPreferences("card_category_prefixes", MODE_PRIVATE)
            val editor = prefs.edit()
            legacy.all.forEach { (key, value) ->
                if (!key.startsWith("_") && value is String && !prefs.contains(key)) editor.putString(key, value)
            }
            editor.putBoolean("_legacy_migrated", true).apply()
        }
        return prefs
    }

    private fun showCategoryPrefixes() {
        currentScreen = "category_prefixes"
        content.removeAllViews()
        addBackButton()
        addTitle("بادئات أرقام الكروت حسب الشريحة")
        addText("اختر الشريحة لعرض وتعديل بادئاتها فقط. إعدادات SIM1 وSIM2 مستقلة.")
        val simPicker = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("SIM 1", "SIM 2"))
            setSelection(if (categoryPrefixSimSlot == 2) 1 else 0)
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        content.addView(simPicker, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 6.dp(), 0, 10.dp()) })
        val categories = CardStore.categories(this)
        if (categories.isEmpty()) {
            addText("لا توجد فئات كروت. أنشئ الفئات أولًا ثم حدد بادئاتها.")
            return
        }
        simPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = if (position == 1) 2 else 1
                if (selected != categoryPrefixSimSlot) {
                    categoryPrefixSimSlot = selected
                    showCategoryPrefixes()
                }
            }
        }
        val fields = linkedMapOf<Int, EditText>()
        categories.forEach { category ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(205, 225, 244), 16.dp())
                elevation = 1.dp().toFloat()
            }
            card.addView(TextView(this).apply {
                text = "فئة ${category} ريال"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(31, 76, 117))
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2))
            val field = EditText(this).apply {
                hint = "مثال: 41"
                textSize = 16f
                setSingleLine(true)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(categoryPrefixPrefs(categoryPrefixSimSlot).getString(category.toString(), "") ?: "")
                setTextColor(Color.rgb(25, 55, 82))
                background = roundedBackground(Color.rgb(247, 250, 254), Color.rgb(205, 225, 244), 12.dp())
                setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
            }
            fields[category] = field
            card.addView(field, LinearLayout.LayoutParams(-1, 48.dp()).apply { topMargin = 8.dp() })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6.dp(), 0, 8.dp()) })
        }
        addButton("💾 حفظ البادئات", true) {
            val entries = fields.mapValues { it.value.text.toString().trim() }
            val configured = entries.filterValues { it.isNotEmpty() }
            val duplicate = configured.entries.groupBy { it.value }.entries.firstOrNull { it.value.size > 1 }
            if (duplicate != null) {
                val names = duplicate.value.joinToString(" و ") { "${it.key} ريال" }
                android.app.AlertDialog.Builder(this)
                    .setTitle("بادئة مكررة")
                    .setMessage("البادئة ${duplicate.key} مخصصة لأكثر من فئة: $names. استخدم بادئة مختلفة لكل فئة.")
                    .setPositiveButton("حسنًا", null).show()
                return@addButton
            }
            val editor = categoryPrefixPrefs(categoryPrefixSimSlot).edit()
            entries.forEach { (category, prefix) ->
                if (prefix.isBlank()) editor.remove(category.toString())
                else editor.putString(category.toString(), prefix)
            }
            editor.apply()
            android.widget.Toast.makeText(this, "تم حفظ بادئات الفئات", android.widget.Toast.LENGTH_LONG).show()
            showDashboard()
        }
    }


    private var pendingCardFileText: ((String) -> Unit)? = null
    private val cardFileImportRequestCode = 7218

    private fun handleCardFileImportResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        if (requestCode != cardFileImportRequestCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val mime = contentResolver.getType(uri).orEmpty()
            val extracted = contentResolver.openInputStream(uri)?.use { stream ->
                if (mime == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")) {
                    PDFBoxResourceLoader.init(applicationContext)
                    PDDocument.load(stream).use { PDFTextStripper().getText(it) }
                } else stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }.orEmpty()
            if (extracted.isBlank()) {
                android.app.AlertDialog.Builder(this).setTitle("الملف لا يحتوي على نص مقروء")
                    .setMessage("تأكد أن ملف TXT صحيح أو أن PDF يحتوي على نص قابل للاستخراج.")
                    .setPositiveButton("حسنًا", null).show()
                return
            }
            pendingCardFileText?.invoke(extracted)
        } catch (e: Exception) {
            android.app.AlertDialog.Builder(this).setTitle("تعذر قراءة الملف")
                .setMessage("لم يتم حفظ أي كرت. جرّب ملف TXT أو PDF آخر.")
                .setPositiveButton("حسنًا", null).show()
        }
    }

    private fun showAddCards() {
        currentScreen = "add_cards"
        updateBottomNav("add_cards")
        content.removeAllViews()
        addBackButton()
        addTitle("إضافة الكروت")
        addText("أضف بطاقاتك بسهولة — اختر الفئة ثم الصق الأرقام.")

        val categories = CardStore.categories(this)
        val stockSummary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 14.dp(), 16.dp(), 14.dp())
            background = roundedBackground(Color.rgb(238, 246, 255), Color.rgb(198, 224, 250), 16.dp())
            elevation = 2.dp().toFloat()
            addView(TextView(this@MainActivity).apply {
                text = "📦  ملخص المخزون"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(25, 80, 130))
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply {
                text = "إجمالي الكروت المتبقية: ${CardStore.totalStock(this@MainActivity)} كرت"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(37, 98, 151))
                gravity = Gravity.RIGHT
                setPadding(0, 8.dp(), 0, 0)
            }, LinearLayout.LayoutParams(-1, -2))
            addView(TextView(this@MainActivity).apply {
                text = "SIM 1: ${CardStore.categories(this@MainActivity).sumOf { CardStore.count(this@MainActivity, it, 1) }} كرت   •   SIM 2: ${CardStore.categories(this@MainActivity).sumOf { CardStore.count(this@MainActivity, it, 2) }} كرت"
                textSize = 13f
                setTextColor(Color.rgb(76, 107, 137))
                gravity = Gravity.RIGHT
                setPadding(0, 4.dp(), 0, 0)
            }, LinearLayout.LayoutParams(-1, -2))
        }
        content.addView(stockSummary, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8.dp(), 0, 12.dp()) })
        if (categories.isEmpty()) {
            val emptyState = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(22.dp(), 24.dp(), 22.dp(), 24.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(216, 232, 248), 18.dp())
                addView(TextView(this@MainActivity).apply {
                    text = "📂"
                    textSize = 38f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(-1, 54.dp()))
                addView(TextView(this@MainActivity).apply {
                    text = "لا توجد فئات للكروت بعد"
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(31, 76, 117))
                }, LinearLayout.LayoutParams(-1, -2))
                addView(TextView(this@MainActivity).apply {
                    text = "أنشئ فئة أولًا، ثم ارجع إلى هذه الشاشة لإضافة الكروت."
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(96, 116, 135))
                    setPadding(0, 8.dp(), 0, 14.dp())
                }, LinearLayout.LayoutParams(-1, -2))
                addView(Button(this@MainActivity).apply {
                    text = "🏷️  فتح فئات الكروت"
                    setOnClickListener { showCategories() }
                }, LinearLayout.LayoutParams(-1, 48.dp()))
            }
            content.addView(emptyState, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 14.dp(), 0, 10.dp()) })
            return
        }

        val categoryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 14.dp(), 16.dp(), 14.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(218, 231, 245), 16.dp())
            elevation = 2.dp().toFloat()
        }
        categoryCard.addView(TextView(this).apply {
            text = "🏷️  فئة الكروت"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(31, 76, 117))
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2))
        val spinner = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(categories.map { "$it ريال" })
            setPadding(8.dp(), 6.dp(), 8.dp(), 6.dp())
        }
        categoryCard.addView(spinner, LinearLayout.LayoutParams(-1, 52.dp()).apply { topMargin = 8.dp() })
        categoryCard.addView(TextView(this).apply {
            text = "📱 الشريحة المستهدفة (الافتراضي SIM1)"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(31,76,117))
            gravity = Gravity.RIGHT
            setPadding(0, 12.dp(), 0, 4.dp())
        }, LinearLayout.LayoutParams(-1, -2))
        val simSpinner = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243,248,254), Color.rgb(203,222,242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("SIM 1 (افتراضية)", "SIM 2"))
            setSelection(0)
            setPadding(8.dp(), 6.dp(), 8.dp(), 6.dp())
        }
        categoryCard.addView(simSpinner, LinearLayout.LayoutParams(-1, 48.dp()))
        categoryCard.addView(TextView(this).apply {
            text = "المخزون الحالي: " + categories.joinToString("  •  ") { "$it ريال: ${CardStore.count(this@MainActivity, it)}" }
            textSize = 12.5f
            setTextColor(Color.rgb(88, 111, 133))
            gravity = Gravity.RIGHT
            setPadding(0, 10.dp(), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(categoryCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10.dp(), 0, 12.dp()) })

        val entryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 14.dp(), 16.dp(), 14.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(218, 231, 245), 18.dp())
            elevation = 2.dp().toFloat()
        }
        entryCard.addView(TextView(this).apply {
            text = "📥  أرقام الكروت"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(31, 76, 117))
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2))
        entryCard.addView(TextView(this).apply {
            text = "الصق الأرقام هنا، رقم واحد في كل سطر."
            textSize = 13f
            setTextColor(Color.rgb(99, 119, 138))
            gravity = Gravity.RIGHT
            setPadding(0, 5.dp(), 0, 8.dp())
        }, LinearLayout.LayoutParams(-1, -2))
        val input = EditText(this).apply {
            hint = "مثال:\n18466933\n10356433\n..."
            setTextColor(Color.rgb(25, 45, 65))
            setHintTextColor(Color.rgb(142, 158, 174))
            textSize = 16f
            minLines = 9
            gravity = Gravity.TOP or Gravity.RIGHT
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = roundedBackground(Color.rgb(247, 250, 254), Color.rgb(211, 226, 241), 12.dp())
            setPadding(12.dp(), 12.dp(), 12.dp(), 12.dp())
        }
        entryCard.addView(input, LinearLayout.LayoutParams(-1, -2))
        content.addView(entryCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 12.dp()) })


        addButton("📎  إرفاق ملف الكروت (TXT / PDF)") {
            pendingCardFileText = { extracted ->
                val lines = extracted.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                // PDF text may place card numbers beside labels or split digits with spaces/hyphens.
                // Extract card-length numeric tokens from each line, without treating short prices as cards.
                val cardNumberPattern = Regex("(?<!\\d)\\d(?:[ \t-]?\\d){7,19}(?!\\d)")
                val numeric = lines.flatMap { line ->
                    cardNumberPattern.findAll(line).map { match ->
                        match.value.replace(" ", "").replace("\t", "").replace("-", "")
                    }.toList()
                }
                val unique = numeric.distinct()
                val duplicates = numeric.size - unique.size
                val invalid = lines.count { line -> cardNumberPattern.find(line) == null }
                val amount = categories.getOrNull(spinner.selectedItemPosition) ?: categories.first()
                val candidates = unique
                val message = "الفئة المستهدفة: $amount ريال\n\n" +
                    "إجمالي الأسطر: ${lines.size}\n" +
                    "أرقام صحيحة وفريدة: ${unique.size}\n" +
                    "مكررة داخل الملف: $duplicates\n" +
                    "التكرار الموجود مسبقًا سيُفحص عند الحفظ\n" +
                    "أسطر غير صالحة: $invalid\n\n" +
                    "بعد المتابعة ستُجهز الأرقام في الخانة؛ اضغط «حفظ الكروت» لإتمام الإضافة. ستظل حماية بادئة الفئة مطبقة."
                android.app.AlertDialog.Builder(this).setTitle("مراجعة ملف الكروت").setMessage(message)
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("متابعة") { _, _ ->
                        input.setText(candidates.joinToString("\n"))
                        Toast.makeText(this, "تم تجهيز ${candidates.size} كرت؛ راجعها ثم اضغط حفظ الكروت.", Toast.LENGTH_LONG).show()
                    }.show()
            }
            startActivityForResult(android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(android.content.Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/pdf", "application/octet-stream")) }, cardFileImportRequestCode)
        }
        addButton("💾  حفظ الكروت", true) {
            val amount = categories[spinner.selectedItemPosition]

            // Validate against the SIM selected on the Add Cards screen.
            val prefixSimSlot = if (simSpinner.selectedItemPosition == 1) 2 else 1
            val pastedCards = input.text.toString().lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
            val configuredPrefixes = CardStore.categories(this).mapNotNull { category ->
                val prefix = categoryPrefixPrefs(prefixSimSlot).getString(category.toString(), "")?.trim().orEmpty()
                if (prefix.isEmpty()) null else category to prefix
            }
            // The longest matching prefix owns the card; this safely supports prefixes such as 4 and 41.
            val wrongOwner = pastedCards.firstNotNullOfOrNull { cardNumber ->
                configuredPrefixes
                    .filter { (_, prefix) -> cardNumber.startsWith(prefix) }
                    .maxByOrNull { (_, prefix) -> prefix.length }
                    ?.takeIf { (ownerCategory, _) -> ownerCategory != amount }
                    ?.let { owner -> Triple(cardNumber, owner.first, owner.second) }
            }
            if (wrongOwner != null) {
                android.app.AlertDialog.Builder(this)
                    .setTitle("بادئة الكروت تخص فئة أخرى")
                    .setMessage("لم تتم إضافة أي كرت. الرقم ${wrongOwner.first} يبدأ بالبادئة ${wrongOwner.third}، وهذه البادئة مخصصة لفئة ${wrongOwner.second} ريال وليست فئة $amount ريال.")
                    .setPositiveButton("حسنًا", null).show()
                return@addButton
            }
            val expectedPrefix = categoryPrefixPrefs(prefixSimSlot).getString(amount.toString(), "")?.trim().orEmpty()
            if (expectedPrefix.isNotEmpty()) {
                val invalid = pastedCards.firstOrNull { !it.startsWith(expectedPrefix) }
                if (invalid != null) {
                    android.app.AlertDialog.Builder(this)
                        .setTitle("بادئة غير مطابقة للفئة")
                        .setMessage("لم تتم إضافة أي كرت. الفئة $amount ريال يجب أن تبدأ بادئتها بـ $expectedPrefix، لكن الرقم $invalid لا يطابقها.")
                        .setPositiveButton("حسنًا", null).show()
                    return@addButton
                }
            }
            
            val selectedSim = if (simSpinner.selectedItemPosition == 1) 2 else 1
            val added = CardStore.addCards(this, amount, input.text.toString(), selectedSim)
            Toast.makeText(this, if (added > 0) "تم حفظ $added كرت في ${SimRouting.label(selectedSim)} من فئة $amount ريال" else "لم يتم العثور على أرقام كروت صحيحة", Toast.LENGTH_LONG).show()
            if (added > 0) {
                input.setText("")
                CardQueueProcessor.process(this)
            }
        }
        addButton("🔄  تصحيح الفئة أو نقل الكروت") { showMoveCards() }
        addText("ℹ️  تتم معالجة الأرقام وحفظها وفق آلية المخزون الحالية.")
    }

    private fun showMoveCards() {
        currentScreen = "move_cards"
        content.removeAllViews()
        addBackButton()
        addTitle("تصحيح فئة الكروت")
        addText("اختر الفئة الخاطئة ثم ستظهر أرقام الكروت الموجودة فعليًا في المخزون. ضع علامة على الكروت التي تريد نقلها فقط، ثم اختر الفئة الصحيحة.")

        val categories = CardStore.categories(this)
        val simSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SIM1", "SIM2"))
        }
        addText("📱 شريحة المصدر:")
        content.addView(simSpinner, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 4.dp(), 0, 6.dp()) })
        val destinationSimSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SIM1", "SIM2"))
        }
        addText("📲 شريحة الوجهة:")
        content.addView(destinationSimSpinner, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 0, 0, 10.dp()) })
        if (categories.size < 2) {
            addText("تحتاج إلى وجود فئتين على الأقل لاستخدام التصحيح.")
            return
        }

        fun categoryLabel(amount: Int) = "$amount ريال — ${CardStore.count(this, amount, simSpinner.selectedItemPosition + 1)} كرت متبقي"

        val fromSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                categories.map { categoryLabel(it) })
        }
        val toSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                categories.map { categoryLabel(it) })
        }

        addText("الفئة الخاطئة (من):")
        content.addView(fromSpinner)
        addText("الفئة الصحيحة (إلى):")
        content.addView(toSpinner)

        val selectionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val countText = TextView(this).apply {
            text = "حدد الكروت المراد نقلها"
            textSize = 15f
            setTextColor(Color.rgb(45, 65, 80))
        }
        selectionBar.addView(countText, LinearLayout.LayoutParams(0, -2, 1f))
        val selectAll = Button(this).apply { text = "تحديد الكل" }
        selectionBar.addView(selectAll)
        content.addView(selectionBar)

        val cardsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        content.addView(cardsList, LinearLayout.LayoutParams(-1, -2))

        val selectedCards = linkedSetOf<String>()
        var visibleCards: List<String> = emptyList()

        fun renderCards() {
            val from = categories[fromSpinner.selectedItemPosition]
            visibleCards = CardStore.cards(this, from, simSpinner.selectedItemPosition + 1)
            selectedCards.retainAll(visibleCards.toSet())
            cardsList.removeAllViews()
            countText.text = "الكروت المتبقية: ${visibleCards.size} — المحدد: ${selectedCards.size}"
            if (visibleCards.isEmpty()) {
                cardsList.addView(TextView(this).apply {
                    text = "لا توجد كروت متبقية في فئة $from ريال."
                    textSize = 16f
                    setPadding(8.dp(), 12.dp(), 8.dp(), 12.dp())
                    setTextColor(Color.DKGRAY)
                })
            } else {
                visibleCards.forEach { card ->
                    val check = CheckBox(this).apply {
                        text = card
                        textSize = 17f
                        isChecked = selectedCards.contains(card)
                        setTextColor(Color.rgb(30, 45, 60))
                        setPadding(8.dp(), 5.dp(), 8.dp(), 5.dp())
                        setOnCheckedChangeListener { _, checked ->
                            if (checked) selectedCards.add(card) else selectedCards.remove(card)
                            countText.text = "الكروت المتبقية: ${visibleCards.size} — المحدد: ${selectedCards.size}"
                            selectAll.text = if (selectedCards.size == visibleCards.size && visibleCards.isNotEmpty()) "إلغاء التحديد" else "تحديد الكل"
                        }
                    }
                    cardsList.addView(check)
                    cardsList.addView(View(this).apply {
                        setBackgroundColor(Color.rgb(225, 230, 235))
                    }, LinearLayout.LayoutParams(-1, 1))
                }
            }
            selectAll.text = if (selectedCards.size == visibleCards.size && visibleCards.isNotEmpty()) "إلغاء التحديد" else "تحديد الكل"
        }

        selectAll.setOnClickListener {
            if (visibleCards.isNotEmpty() && selectedCards.size == visibleCards.size) selectedCards.clear()
            else selectedCards.addAll(visibleCards)
            renderCards()
        }
        simSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val oldFrom = fromSpinner.selectedItemPosition.coerceAtLeast(0)
                val oldTo = toSpinner.selectedItemPosition.coerceAtLeast(0)
                val labels = categories.map { categoryLabel(it) }
                fromSpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                toSpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                fromSpinner.setSelection(oldFrom.coerceAtMost(categories.lastIndex))
                toSpinner.setSelection(oldTo.coerceAtMost(categories.lastIndex))
                selectedCards.clear()
                renderCards()
            }
        }
        fromSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedCards.clear()
                renderCards()
            }
        }
        renderCards()

        addButton("نقل الكروت المحددة") {
            val from = categories[fromSpinner.selectedItemPosition]
            val to = categories[toSpinner.selectedItemPosition]
            if (from == to) {
                Toast.makeText(this, "اختر فئتين مختلفتين", Toast.LENGTH_LONG).show()
                return@addButton
            }
            if (selectedCards.isEmpty()) {
                Toast.makeText(this, "حدد كرتًا واحدًا على الأقل من القائمة", Toast.LENGTH_LONG).show()
                return@addButton
            }
            val moved = CardStore.moveCardsBetween(this, from, to, selectedCards.joinToString("\n"), simSpinner.selectedItemPosition + 1, destinationSimSpinner.selectedItemPosition + 1)
            Toast.makeText(this,
                if (moved > 0) "تم نقل $moved كرت من $from إلى $to ريال"
                else "لم يتم نقل أي كرت. حدّث القائمة وتأكد من وجود الكروت في الفئة المحددة.",
                Toast.LENGTH_LONG).show()
            if (moved > 0) showMoveCards()
        }

        addButton("نقل جميع كروت الفئة") {
            val from = categories[fromSpinner.selectedItemPosition]
            val to = categories[toSpinner.selectedItemPosition]
            if (from == to) {
                Toast.makeText(this, "اختر فئتين مختلفتين", Toast.LENGTH_LONG).show()
                return@addButton
            }
            val sourceSim = simSpinner.selectedItemPosition + 1
            val destinationSim = destinationSimSpinner.selectedItemPosition + 1
            val cards = CardStore.cards(this, from, sourceSim)
            if (cards.isEmpty()) {
                Toast.makeText(this, "لا توجد كروت متبقية في فئة $from ريال", Toast.LENGTH_LONG).show()
                return@addButton
            }
            android.app.AlertDialog.Builder(this)
                .setTitle("تأكيد نقل الكروت")
                .setMessage("سيتم نقل جميع الكروت المتبقية من SIM$sourceSim / فئة $from ريال إلى SIM$destinationSim / فئة $to ريال.\n\nعدد الكروت: ${cards.size}\n\nهل تريد المتابعة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("نقل الكل") { _, _ ->
                    val moved = CardStore.moveCardsBetween(this, from, to, cards.joinToString("\n"), sourceSim, destinationSim)
                    Toast.makeText(this, "تم نقل $moved كرت من $from إلى $to ريال", Toast.LENGTH_LONG).show()
                    showMoveCards()
                }
                .show()
        }

        addText("ملاحظة: تظهر هنا الكروت المتبقية في المخزون فقط؛ الكروت التي تم بيعها لا تظهر.")
    }

    private fun showSimInventory() {
        currentScreen = "sim_inventory"
        content.removeAllViews()
        addBackButton()
        addTitle("📱 مخزون SIM1 / SIM2")
        addText("كل شريحة مستقلة عن الأخرى. عند وصول تحويل على SIM1 يستخدم التطبيق مخزون SIM1 فقط، وعند وصوله على SIM2 يستخدم مخزون SIM2 فقط.")

        val simSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SIM1", "SIM2"))
        }
        content.addView(simSpinner)

        val categories = CardStore.categories(this)
        if (categories.isEmpty()) {
            addText("لا توجد فئات كروت.")
            return
        }

        val amountSpinner = Spinner(this).apply { setBackgroundColor(Color.WHITE) }
        content.addView(amountSpinner)

        val input = EditText(this).apply {
            hint = "الصق أرقام الكروت، كل رقم في سطر"
            minLines = 8
            gravity = Gravity.TOP or Gravity.RIGHT
            textSize = 17f
            setTextColor(Color.rgb(25,25,25))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        content.addView(input)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        fun refresh() {
            val sim = simSpinner.selectedItemPosition + 1
            amountSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                categories.map { amount -> "$amount ريال — ${CardStore.count(this, amount, sim)} كرت" })
            val amount = categories[amountSpinner.selectedItemPosition.coerceAtMost(categories.lastIndex)]
            val cards = CardStore.cards(this, amount, sim)
            list.removeAllViews()
            list.addView(TextView(this).apply {
                text = "${SimRouting.label(sim)} • $amount ريال • ${cards.size} كرت متبقي"
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(30,85,125))
                gravity = Gravity.RIGHT
                setPadding(0, 12.dp(), 0, 8.dp())
            })
            cards.take(300).forEachIndexed { index, card ->
                list.addView(TextView(this).apply {
                    text = "${index + 1}. $card"
                    textSize = 15f
                    gravity = Gravity.RIGHT
                    setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
                    setTextColor(Color.rgb(40,40,40))
                    setBackgroundColor(Color.WHITE)
                })
            }
        }

        simSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        addButton("💾 إضافة الكروت إلى الشريحة المحددة", true) {
            val sim = simSpinner.selectedItemPosition + 1
            val amount = categories[amountSpinner.selectedItemPosition]
            val added = CardStore.addCards(this, amount, input.text.toString(), sim).also { if (it > 0) CardQueueProcessor.process(this) }
            Toast.makeText(this, if (added > 0) "تم حفظ $added كرت في ${SimRouting.label(sim)} لفئة $amount" else "لم تتم إضافة أي كرت", Toast.LENGTH_LONG).show()
            if (added > 0) input.setText("")
            refresh()
        }

        addButton("🔄 تحديث") { refresh() }
        refresh()
    }

    private fun showSimSales() {
        currentScreen = "sim_sales"
        content.removeAllViews()
        addBackButton()
        addTitle("📊 مبيعات SIM1 / SIM2")
        val simSpinner = Spinner(this).apply {
            setBackgroundColor(Color.WHITE)
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SIM1", "SIM2"))
        }
        content.addView(simSpinner)
        val result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(result)
        fun refresh() {
            val sim = simSpinner.selectedItemPosition + 1
            val sales = CardStore.sales(this, sim)
            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val todaySales = sales.filter { it.time.startsWith(today) }
            result.removeAllViews()
            result.addView(TextView(this).apply {
                text = "${SimRouting.label(sim)}\nإجمالي المبيعات: ${sales.size} كرت\nمبيعات اليوم: ${todaySales.size} كرت\nقيمة مبيعات اليوم: ${todaySales.sumOf { it.amount }} ريال"
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                setTextColor(Color.rgb(35,75,105))
                setPadding(0, 10.dp(), 0, 12.dp())
            })
            todaySales.take(300).forEach { sale ->
                result.addView(TextView(this).apply {
                    text = "${sale.time} • ${sale.amount} ريال\nالمشتري: ${sale.phone}\nالكرت: ${sale.card}"
                    textSize = 14f
                    gravity = Gravity.RIGHT
                    setTextColor(Color.rgb(55,65,75))
                    setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                    setBackgroundColor(Color.WHITE)
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 6.dp()) })
            }
        }
        simSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        refresh()
    }
    private fun showStock() {
        currentScreen = "stock"
        updateBottomNav("stock")
        content.removeAllViews()
        addBackButton()
        addTitle("مخزون الكروت")
        val categories = CardStore.categories(this)
        if (categories.isEmpty()) {
            addText("لا توجد فئات. أضف فئة من قسم الفئات.")
            return
        }
        addText("اختر SIM والفئة. للدخول إلى وضع التعديل اضغط «✏️ تعديل الكروت» ثم اختر الكروت التي تريد حذفها.")

        fun stockSpinnerAdapter(items: List<String>): ArrayAdapter<String> = styledSpinnerAdapter(items)

        val simSpinner = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = stockSpinnerAdapter(listOf("SIM 1", "SIM 2"))
            setPadding(8.dp(), 6.dp(), 8.dp(), 6.dp())
        }
        content.addView(simSpinner, LinearLayout.LayoutParams(-1, 52.dp()).apply { setMargins(0, 6.dp(), 0, 6.dp()) })

        val spinner = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            setPadding(8.dp(), 6.dp(), 8.dp(), 6.dp())
        }
        content.addView(spinner, LinearLayout.LayoutParams(-1, 52.dp()).apply { setMargins(0, 6.dp(), 0, 8.dp()) })

        val actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
        }
        content.addView(actionBar)

        val cardsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(cardsContainer)

        var editMode = false
        var selectedCards = mutableSetOf<String>()
        var currentCards = emptyList<String>()

        fun currentSim(): Int = simSpinner.selectedItemPosition + 1
        fun currentAmount(): Int {
            val list = CardStore.categories(this)
            return list[spinner.selectedItemPosition.coerceIn(0, (list.size - 1).coerceAtLeast(0))]
        }

        fun setSpinnerItems() {
            val sim = currentSim()
            val list = CardStore.categories(this)
            val position = spinner.selectedItemPosition.coerceAtLeast(0)
            spinner.adapter = stockSpinnerAdapter(
                list.map { amount -> "${amount} ريال — ${CardStore.count(this, amount, sim)} كرت" }
            )
            if (spinner.adapter.count > 0) spinner.setSelection(position.coerceAtMost(spinner.adapter.count - 1))
        }

        lateinit var renderCards: () -> Unit
        lateinit var deleteButton: Button

        fun addActionButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
            actionBar.addView(Button(this).apply {
                this.text = text
                isEnabled = enabled
                textSize = 16f
                setTextColor(Color.rgb(20, 91, 150))
                background = roundedBackground(Color.WHITE, Color.rgb(205, 220, 232), 1.dp())
                setPadding(14.dp(), 0, 14.dp(), 0)
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4, 0, 4) })
        }

        fun deleteSelected() {
            if (selectedCards.isEmpty()) {
                Toast.makeText(this, "حدد كرتًا واحدًا على الأقل أولًا", Toast.LENGTH_SHORT).show()
                return
            }
            val amount = currentAmount()
            val sim = currentSim()
            val count = CardStore.deleteCards(this, amount, selectedCards, sim)
            Toast.makeText(this, "تم حذف $count كرت من المخزون", Toast.LENGTH_LONG).show()
            editMode = false
            selectedCards.clear()
            setSpinnerItems()
            renderCards()
        }

        fun rebuildActions() {
            actionBar.removeAllViews()
            if (!editMode) {
                addActionButton("✏️ تعديل الكروت") {
                    editMode = true
                    selectedCards.clear()
                    renderCards()
                }
                addActionButton("➖ إنقاص عدد من المخزون") {
                    val amount = currentAmount()
                    val sim = currentSim()
                    val available = CardStore.count(this, amount, sim)
                    if (available <= 0) {
                        Toast.makeText(this, "المخزون فارغ", Toast.LENGTH_SHORT).show()
                        return@addActionButton
                    }
                    val input = EditText(this).apply {
                        hint = "عدد الكروت المراد إنقاصها"
                        inputType = android.text.InputType.TYPE_CLASS_NUMBER
                        setSingleLine(true)
                        textSize = 18f
                        gravity = Gravity.RIGHT
                        setTextColor(Color.rgb(25,25,25))
                    }
                    android.app.AlertDialog.Builder(this)
                        .setTitle("إنقاص المخزون — SIM$sim — $amount ريال")
                        .setView(input)
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("إنقاص") { _, _ ->
                            val quantity = input.text.toString().trim().toIntOrNull() ?: 0
                            val removed = CardStore.removeFirstCards(this, amount, quantity, sim)
                            Toast.makeText(this, "تم إنقاص $removed كرت من المخزون", Toast.LENGTH_LONG).show()
                            setSpinnerItems()
                            renderCards()
                        }.show()
                }
            } else {
                addActionButton("☑️ تحديد الكل") {
                    selectedCards = currentCards.toMutableSet()
                    renderCards()
                }
                deleteButton = Button(this).apply {
                    text = "🗑️ حذف الكروت المحددة (0)"
                    isEnabled = true
                    textSize = 16f
                    setTextColor(Color.rgb(170, 55, 45))
                    background = roundedBackground(Color.WHITE, Color.rgb(205, 220, 232), 1.dp())
                    setOnClickListener { deleteSelected() }
                }
                actionBar.addView(deleteButton, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4, 0, 4) })
                addActionButton("↩️ إلغاء وضع التعديل") {
                    editMode = false
                    selectedCards.clear()
                    renderCards()
                }
            }
        }

        renderCards = renderCardsLabel@{
            cardsContainer.removeAllViews()
            val amount = currentAmount()
            val sim = currentSim()
            currentCards = CardStore.cards(this, amount, sim)

            cardsContainer.addView(TextView(this).apply {
                text = "SIM$sim — فئة $amount ريال — ${currentCards.size} كرت متبقي"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(30,30,30))
                setPadding(0, 16, 0, 10)
            })

            if (currentCards.isEmpty()) {
                cardsContainer.addView(TextView(this).apply {
                    text = "لا يوجد كروت متبقية في هذه الفئة على SIM$sim."
                    textSize = 15f
                    setTextColor(Color.rgb(45,45,45))
                    setPadding(0, 8, 0, 10)
                })
                rebuildActions()
                return@renderCardsLabel
            }

            if (editMode) {
                cardsContainer.addView(TextView(this).apply {
                    text = "وضع التعديل: ضع علامة ✓ أمام الكروت التي تريد حذفها"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(180, 70, 40))
                    setPadding(0, 6, 0, 12)
                })
            }

            currentCards.forEachIndexed { index, card ->
                if (editMode) {
                    val check = CheckBox(this).apply {
                        text = "${index + 1}.  $card"
                        textSize = 17f
                        setTextColor(Color.rgb(25,25,25))
                        isChecked = selectedCards.contains(card)
                        setPadding(10, 8, 10, 8)
                        setOnCheckedChangeListener { _, checked ->
                            if (checked) selectedCards.add(card) else selectedCards.remove(card)
                            deleteButton.text = "🗑️ حذف الكروت المحددة (${selectedCards.size})"
                            deleteButton.isEnabled = true
                        }
                    }
                    cardsContainer.addView(check, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 4) })
                } else {
                    cardsContainer.addView(TextView(this).apply {
                        text = "${index + 1}.  $card"
                        textSize = 17f
                        setTextColor(Color.rgb(25,25,25))
                        setPadding(14, 10, 14, 10)
                        setBackgroundColor(Color.WHITE)
                    }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 4) })
                }
            }
            rebuildActions()
            if (editMode) {
                deleteButton.text = "🗑️ حذف الكروت المحددة (${selectedCards.size})"
                deleteButton.isEnabled = true
            }
        }

        simSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                editMode = false
                selectedCards.clear()
                setSpinnerItems()
                renderCards()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                editMode = false
                selectedCards.clear()
                renderCards()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        addButton("🔄 تحديث المخزون والأرقام") {
            selectedCards.clear()
            setSpinnerItems()
            renderCards()
        }

        setSpinnerItems()
        renderCards()
    }

    private fun showCategories() {
        currentScreen = "categories"
        content.removeAllViews()
        addBackButton()
        addTitle("إدارة فئات الكروت")
        addText("اختر الشريحة لإدارة فئاتها. إعدادات الفئات والمخزون وحدود التنبيه تُدار لكل شريحة بصورة مستقلة.")
        val categorySimSelector = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("الشريحة الأولى (SIM 1)", "الشريحة الثانية (SIM 2)"))
            setSelection(if (categoryManagementSimSlot == 2) 1 else 0)
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        content.addView(categorySimSelector, LinearLayout.LayoutParams(-1, 48.dp()).apply {
            setMargins(0, 6.dp(), 0, 10.dp())
        })
        categorySimSelector.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedSim = if (position == 1) 2 else 1
                if (categoryManagementSimSlot != selectedSim) {
                    categoryManagementSimSlot = selectedSim
                    showCategories()
                }
            }
        }
        addText("أضف أي فئة تريدها يدويًا. بعد الحفظ ستظهر تلقائيًا في الإضافة والمخزون والإرسال والتنبيهات والنسخ الاحتياطي.")
        val input = EditText(this).apply {
            hint = "اكتب قيمة الفئة مثل 300"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 18f
            setTextColor(Color.rgb(25,25,25))
            setHintTextColor(Color.rgb(110,110,110))
            gravity = Gravity.RIGHT
        }
        content.addView(input)
        addButton("حفظ وإضافة الفئة") {
            val amount = input.text.toString().trim().toIntOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(this, "أدخل رقم فئة صحيح أكبر من صفر", Toast.LENGTH_LONG).show()
            } else if (CardStore.categories(this).contains(amount)) {
                Toast.makeText(this, "هذه الفئة موجودة بالفعل", Toast.LENGTH_LONG).show()
            } else {
                CardStore.addCategory(this, amount)
                StockNotification.setThreshold(this, amount, 20)
                Toast.makeText(this, "تمت إضافة فئة " + amount + " ريال", Toast.LENGTH_SHORT).show()
                input.setText("")
                showCategories()
            }
        }
        addSectionTitle("الفئات الحالية")
        CardStore.categories(this).forEach { amount ->
            addText("• " + amount + " ريال — " + CardStore.count(this, amount) + " كرت")
        }
    }

    fun showAlternateNumbers() {
        currentScreen = "alternate_numbers"
        content.removeAllViews()
        addBackButton()
        addTitle("إدارة الأرقام البديلة")
        addText("اختر الشريحة أولاً؛ لكل شريحة أرقام بديلة وإضافات مستقلة. SIM1 هي الافتراضية.")
        val simPicker = Spinner(this).apply {
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("SIM 1 — الافتراضية", "SIM 2"))
            setSelection(0)
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        alternateNumbersSimSlot = 1
        content.addView(simPicker, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 6.dp(), 0, 10.dp()) })
        simPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                alternateNumbersSimSlot = if (position == 1) 2 else 1
                renderAlternateNumbers()
            }
        }

        val formCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16.dp(), 14.dp(), 16.dp(), 16.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(211, 229, 246), 18.dp())
            elevation = 2.dp().toFloat()
        }
        formCard.addView(TextView(this).apply {
            text = "➕  إضافة ربط جديد"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(27, 87, 139))
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2))

        fun field(hintText: String, inputTypeValue: Int): EditText = EditText(this).apply {
            hint = hintText
            inputType = inputTypeValue
            textSize = 15f
            setTextColor(Color.rgb(30, 50, 70))
            setHintTextColor(Color.rgb(132, 151, 170))
            gravity = Gravity.RIGHT
            background = roundedBackground(Color.rgb(247, 250, 254), Color.rgb(218, 231, 244), 12.dp())
            setPadding(12.dp(), 7.dp(), 12.dp(), 7.dp())
        }
        val alternate = field("الرقم البديل", android.text.InputType.TYPE_CLASS_PHONE)
        val phone = field("رقم الجوال الأساسي", android.text.InputType.TYPE_CLASS_PHONE)
        val note = field("اسم الشخص أو ملاحظة (اختياري)", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        listOf(
            "📱  الرقم البديل" to alternate,
            "☎️  رقم الجوال الأساسي" to phone,
            "📝  الاسم / التعليق" to note
        ).forEach { pair ->
            formCard.addView(TextView(this).apply {
                text = pair.first
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(70, 99, 128))
                gravity = Gravity.RIGHT
                setPadding(0, 10.dp(), 0, 3.dp())
            }, LinearLayout.LayoutParams(-1, -2))
            formCard.addView(pair.second, LinearLayout.LayoutParams(-1, 48.dp()))
        }
        content.addView(formCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8.dp(), 0, 12.dp()) })

        addButton("💾  حفظ الربط", true) {
            val a = alternate.text.toString().trim()
            val p = phone.text.toString().trim()
            if (a.length < 4 || p.length !in 9..15) {
                Toast.makeText(this, "تأكد من إدخال الرقم البديل ورقم الجوال بشكل صحيح", Toast.LENGTH_LONG).show()
            } else {
                ContactMap.setPhone(this, a, p, alternateNumbersSimSlot)
                    renderAlternateNumbers()
                getSharedPreferences("alternate_numbers_notes_sim" + alternateNumbersSimSlot, MODE_PRIVATE).edit()
                    .putString("note_" + a, note.text.toString().trim()).apply()
                Toast.makeText(this, "تم حفظ الربط والملاحظة", Toast.LENGTH_SHORT).show()
                alternate.setText("")
                phone.setText("")
                note.setText("")
                renderAlternateNumbers()
            }
        }

        val alternateSearch = EditText(this).apply {
            tag = "alternate_search"
            hint = "🔎 بحث في الأرقام البديلة أو رقم الجوال أو الاسم"
            textSize = 14f
            setSingleLine(true)
            setTextColor(Color.rgb(25, 55, 82))
            setHintTextColor(Color.rgb(112, 133, 153))
            background = roundedBackground(Color.WHITE, Color.rgb(176, 211, 242), 14.dp())
            setPadding(14.dp(), 4.dp(), 14.dp(), 4.dp())
        }
        content.addView(alternateSearch, LinearLayout.LayoutParams(-1, 50.dp()).apply {
            setMargins(0, 4.dp(), 0, 10.dp())
        })
        alternateSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderAlternateNumbers(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        addSectionTitle("الروابط المحفوظة  •  العدد: ${ContactMap.all(this, alternateNumbersSimSlot).size}")
        renderAlternateNumbers()
    }

    private fun renderAlternateNumbers(query: String = content.findViewWithTag<EditText>("alternate_search")?.text?.toString().orEmpty()) {
        content.findViewWithTag<View>("alternate_list")?.let { content.removeView(it) }
        val list = LinearLayout(this).apply {
            tag = "alternate_list"
            orientation = LinearLayout.VERTICAL
        }
        val normalizedQuery = query.trim()
        // Searching checks both SIMs; without a query, show only the selected SIM.
        val simEntries = (if (normalizedQuery.isBlank()) listOf(alternateNumbersSimSlot) else listOf(1, 2))
            .flatMap { slot ->
                val slotNotes = getSharedPreferences("alternate_numbers_notes_sim" + slot, MODE_PRIVATE)
                ContactMap.all(this, slot).toSortedMap().mapNotNull { (alternate, phone) ->
                    val savedNote = slotNotes.getString("note_" + alternate, "").orEmpty()
                    val matches = normalizedQuery.isBlank() ||
                        alternate.contains(normalizedQuery, ignoreCase = true) ||
                        phone.contains(normalizedQuery, ignoreCase = true) ||
                        savedNote.contains(normalizedQuery, ignoreCase = true)
                    if (matches) Triple(slot, alternate, phone) else null
                }
            }
        if (simEntries.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (normalizedQuery.isBlank()) "لا توجد أرقام مرتبطة حتى الآن." else "لا توجد نتائج مطابقة للبحث."
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(106, 127, 147))
                setPadding(16.dp(), 22.dp(), 16.dp(), 22.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(225, 236, 247), 16.dp())
            }, LinearLayout.LayoutParams(-1, -2))
        }
        simEntries.forEachIndexed { index, entry ->
            val (entrySim, a, p) = entry
            val entryNotes = getSharedPreferences("alternate_numbers_notes_sim" + entrySim, MODE_PRIVATE)
            val noteText = entryNotes.getString("note_" + a, "").orEmpty()
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(218, 232, 247), 16.dp())
                elevation = 1.dp().toFloat()
            }
            card.addView(TextView(this).apply {
                text = "${index + 1}. [SIM$entrySim] " + if (noteText.isBlank()) "👤  بدون اسم" else "👤  $noteText"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(28, 83, 132))
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2))
            card.addView(TextView(this).apply {
                text = "البديل: $a"
                textSize = 14f
                setTextColor(Color.rgb(45, 68, 91))
                gravity = Gravity.RIGHT
                setPadding(0, 6.dp(), 0, 2.dp())
            }, LinearLayout.LayoutParams(-1, -2))
            card.addView(TextView(this).apply {
                text = "الجوال الأساسي: $p"
                textSize = 14f
                setTextColor(Color.rgb(45, 68, 91))
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2))
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, 10.dp(), 0, 0)
            }
            actions.addView(Button(this).apply {
                text = "✏️ تعديل"
                setOnClickListener {
                    val editPanel = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(18.dp(), 4.dp(), 18.dp(), 4.dp())
                    }
                    fun editField(value: String, hintValue: String, type: Int) = EditText(this@MainActivity).apply {
                        setText(value); hint = hintValue; inputType = type; textSize = 15f
                    }
                    val newA = editField(a, "الرقم البديل", android.text.InputType.TYPE_CLASS_PHONE)
                    val newP = editField(p, "رقم الجوال الأساسي", android.text.InputType.TYPE_CLASS_PHONE)
                    val newNote = editField(noteText, "اسم الشخص أو ملاحظة", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                    editPanel.addView(newA); editPanel.addView(newP); editPanel.addView(newNote)
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("تعديل بيانات الربط")
                        .setView(editPanel)
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حفظ") { _, _ ->
                            val aa = newA.text.toString().trim()
                            val pp = newP.text.toString().trim()
                            if (aa.length < 4 || pp.length !in 9..15) {
                                Toast.makeText(this@MainActivity, "تحقق من الأرقام المدخلة", Toast.LENGTH_LONG).show()
                            } else {
                                if (aa != a) ContactMap.remove(this@MainActivity, a, entrySim)
                                ContactMap.setPhone(this@MainActivity, aa, pp, entrySim)
                                entryNotes.edit().remove("note_" + a).putString("note_" + aa, newNote.text.toString().trim()).apply()
                                renderAlternateNumbers()
                            }
                        }.show()
                }
            }, LinearLayout.LayoutParams(0, 44.dp(), 1f).apply { setMargins(0, 0, 5.dp(), 0) })
            actions.addView(Button(this).apply {
                text = "🗑️ حذف"
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("حذف الربط")
                        .setMessage("هل تريد حذف الربط بين الرقم البديل $a والجوال $p؟")
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حذف") { _, _ ->
                            ContactMap.remove(this@MainActivity, a, entrySim)
                            entryNotes.edit().remove("note_" + a).apply()
                            renderAlternateNumbers()
                        }.show()
                }
            }, LinearLayout.LayoutParams(0, 44.dp(), 1f).apply { setMargins(5.dp(), 0, 0, 0) })
            card.addView(actions)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, 9.dp()) })
        }
        content.addView(list, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showStockAlertSettings() {
        currentScreen = "stock_alert_settings"
        content.removeAllViews()
        addBackButton()
        addTitle("تنبيه انخفاض المخزون")
        addText("اختر الشريحة أولاً، ثم حدّد حد التنبيه لكل فئة. تُحفظ الإعدادات لكل شريحة بصورة مستقلة.")

        val simSelector = android.widget.Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("الشريحة الأولى (SIM1)", "الشريحة الثانية (SIM2)")
            )
        }
        content.addView(TextView(this).apply {
            text = "الشريحة المطلوب ضبط تنبيهاتها"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setTextColor(Color.rgb(38, 75, 110))
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(simSelector, LinearLayout.LayoutParams(-1, 48.dp()).apply {
            setMargins(0, 4.dp(), 0, 12.dp())
        })

        val thresholdsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(thresholdsContainer, LinearLayout.LayoutParams(-1, -2))

        fun renderThresholds(sim: Int) {
            thresholdsContainer.removeAllViews()
            val categories = CardStore.categories(this@MainActivity, sim)
            if (categories.isEmpty()) {
                thresholdsContainer.addView(TextView(this@MainActivity).apply {
                    text = "لا توجد فئات مخزون لهذه الشريحة."
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setPadding(12.dp(), 18.dp(), 12.dp(), 18.dp())
                })
                return
            }
            categories.forEach { amount ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(218, 232, 247), 14.dp())
                }
                val valueLabel = TextView(this@MainActivity).apply {
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                    setTextColor(Color.rgb(28, 83, 132))
                }
                val initial = StockNotification.getThreshold(this@MainActivity, amount, sim)
                valueLabel.text = "فئة $amount ريال — حد التنبيه: $initial كرت"
                card.addView(valueLabel, LinearLayout.LayoutParams(-1, -2))
                val seek = android.widget.SeekBar(this@MainActivity).apply {
                    max = 500
                    progress = initial.coerceIn(0, 500)
                }
                card.addView(seek, LinearLayout.LayoutParams(-1, 42.dp()))
                seek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(bar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                        valueLabel.text = "فئة $amount ريال — حد التنبيه: $progress كرت"
                    }
                    override fun onStartTrackingTouch(bar: android.widget.SeekBar?) {}
                    override fun onStopTrackingTouch(bar: android.widget.SeekBar?) {
                        val value = bar?.progress ?: 0
                        StockNotification.setThreshold(this@MainActivity, amount, value, sim)
                        Toast.makeText(this@MainActivity, "تم حفظ حد التنبيه لفئة $amount ريال في SIM$sim", Toast.LENGTH_SHORT).show()
                    }
                })
                thresholdsContainer.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, 8.dp())
                })
            }
        }
        simSelector.setSelection(0, false)
        simSelector.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                renderThresholds(if (position == 1) 2 else 1)
            }
        }
        renderThresholds(1)
    }

    private fun showSales(){
        currentScreen = "sales"
        updateBottomNav("sales")
        content.removeAllViews()
        addBackButton()
        addTitle("مبيعات اليوم")

        val sales = CardStore.sales(this)
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val todaySales = sales.filter { it.time.startsWith(today) }

        val salesSummary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(12.dp(), 14.dp(), 12.dp(), 14.dp())
            background = roundedBackground(Color.rgb(231, 248, 240), Color.rgb(190, 229, 210), 18.dp())
            elevation = 2.dp().toFloat()
            fun metric(icon: String, label: String, value: String, color: Int): LinearLayout {
                return LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    addView(TextView(this@MainActivity).apply { text = icon; textSize = 22f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 30.dp()))
                    addView(TextView(this@MainActivity).apply { text = value; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(color) }, LinearLayout.LayoutParams(-1, -2))
                    addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.rgb(80, 110, 98)) }, LinearLayout.LayoutParams(-1, -2))
                }
            }
            addView(metric("🛒", "عدد المبيعات اليوم", todaySales.size.toString(), Color.rgb(26, 120, 78)), LinearLayout.LayoutParams(0, -2, 1f))
            addView(metric("💰", "قيمة المبيعات", "${todaySales.sumOf { it.amount }} ريال", Color.rgb(26, 120, 78)), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(salesSummary, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8.dp(), 0, 12.dp()) })
        addText("تاريخ اليوم: $today")

        addSectionTitle("البحث عن كرت")
        addText("أدخل رقم الكرت لمعرفة تفاصيل شرائه وتاريخ ووقت البيع.")
        val searchInput = EditText(this).apply {
            hint = "أدخل رقم الكرت"
            textSize = 17f
            setSingleLine(true)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setTextColor(Color.rgb(25,25,25))
            setHintTextColor(Color.rgb(110,110,110))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            background = roundedBackground(Color.WHITE, Color.rgb(205,215,225), 1.dp())
            setPadding(14.dp(), 0, 14.dp(), 0)
        }
        content.addView(searchInput, LinearLayout.LayoutParams(-1, 52.dp()).apply {
            setMargins(0, 0, 0, 8.dp())
        })

        val searchResult = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(45,55,65))
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            visibility = View.GONE
        }
        content.addView(searchResult, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 12.dp())
        })

        fun searchCard() {
            val query = searchInput.text.toString().trim()
            if (query.isBlank()) {
                searchResult.visibility = View.GONE
                Toast.makeText(this, "أدخل رقم الكرت أولًا", Toast.LENGTH_SHORT).show()
                return
            }

            val matches = sales.filter { it.card == query }
            if (matches.isEmpty()) {
                searchResult.text = "لم يتم العثور على هذا الكرت في سجل المبيعات."
                searchResult.setTextColor(Color.rgb(180, 55, 55))
                searchResult.background = roundedBackground(Color.rgb(255, 245, 245), Color.rgb(235, 190, 190), 1.dp())
                searchResult.visibility = View.VISIBLE
                return
            }

            searchResult.setTextColor(Color.rgb(35, 75, 95))
            searchResult.background = roundedBackground(Color.rgb(240, 248, 252), Color.rgb(190, 215, 230), 1.dp())
            searchResult.text = "تم العثور على ${matches.size} عملية شراء لهذا الكرت."
            searchResult.visibility = View.VISIBLE

            matches.forEach { sale ->
                val parts = sale.time.split(" ", limit = 2)
                val date = parts.getOrNull(0) ?: sale.time
                val time = parts.getOrNull(1) ?: ""
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(220, 228, 235), 1.dp())
                }
                box.addView(TextView(this).apply {
                    text = "الكرت: ${sale.card}"
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(31, 91, 139))
                })
                box.addView(TextView(this).apply {
                    text = "الباقة: ${sale.amount} ريال"
                    textSize = 15f
                    setTextColor(Color.rgb(45, 55, 65))
                    setPadding(0, 5.dp(), 0, 0)
                })
                box.addView(TextView(this).apply {
                    text = "رقم المشتري: ${sale.phone}"
                    textSize = 15f
                    setTextColor(Color.rgb(45, 55, 65))
                    setPadding(0, 4.dp(), 0, 0)
                })
                box.addView(TextView(this).apply {
                    text = "تاريخ الشراء: $date\nوقت الشراء: $time"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(38, 120, 85))
                    setPadding(0, 5.dp(), 0, 0)
                })
                content.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, 8.dp())
                })
            }
        }

        addButton("🔎 بحث عن الكرت", true) { searchCard() }
        addButton("📊 تقارير المبيعات بالتاريخ", true) { showSalesReport() }
        searchInput.setOnEditorActionListener { _, _, _ ->
            searchCard()
            true
        }

        addSectionTitle("ملخص المبيعات حسب الباقة")
        val summary = todaySales.groupBy { it.amount }.toSortedMap()
        if (summary.isEmpty()) {
            addText("لا توجد مبيعات مسجلة اليوم.")
        } else {
            summary.forEach { (amount, items) ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(222,229,236), 1.dp())
                }
                row.addView(TextView(this).apply {
                    text = "باقة $amount ريال"
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(25,85,130))
                })
                row.addView(TextView(this).apply {
                    text = "عدد المبيعات: ${items.size} كرت"
                    textSize = 14f
                    setTextColor(Color.rgb(75,85,95))
                })
                row.addView(TextView(this).apply {
                    text = "السعر: $amount ريال  •  الإجمالي: ${amount * items.size} ريال"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(38,120,85))
                })
                content.addView(row, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,8.dp()) })
            }
        }

        val totalCount = todaySales.size
        val totalAmount = todaySales.sumOf { it.amount }
        val totalBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16.dp(),16.dp(),16.dp(),16.dp())
            background = gradientBackground(Color.rgb(18,82,133),Color.rgb(31,125,188),12.dp())
        }
        totalBox.addView(TextView(this).apply {
            text = "إجمالي مبيعات اليوم"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        totalBox.addView(TextView(this).apply {
            text = "$totalCount كرت  •  $totalAmount ريال"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0,6.dp(),0,0)
        })
        content.addView(totalBox, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,8.dp(),0,14.dp()) })

        addSectionTitle("تفاصيل مبيعات اليوم")
        todaySales.take(300).forEach { sale ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp(),12.dp(),14.dp(),12.dp())
                setBackgroundColor(Color.WHITE)
            }
            box.addView(TextView(this).apply {
                text = "كرت ${sale.amount} ريال  •  ${sale.time.substringAfter(" ")}"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
            })
            box.addView(TextView(this).apply {
                text = "الرقم: ${sale.phone}\nالكرت: ${sale.card}"
                textSize = 14f
            })
            content.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8.dp())})
        }
    }

    private fun showSalesReport() {
        currentScreen = "sales_report"
        content.removeAllViews()
        addBackButton()
        addTitle("تقارير المبيعات بالتاريخ")
        addText("اختر تاريخ البداية والنهاية لعرض تقرير مفصل عن المبيعات خلال الفترة المحددة.")

        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        dateFormat.isLenient = false
        val fromCalendar = java.util.Calendar.getInstance()
        val toCalendar = java.util.Calendar.getInstance()

        fun formatDate(calendar: java.util.Calendar): String = dateFormat.format(calendar.time)

        val fromButton = TextView(this).apply {
            text = "من تاريخ: " + formatDate(fromCalendar)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(27, 91, 141))
            background = roundedBackground(Color.WHITE, Color.rgb(213, 224, 234), 1.dp())
            setPadding(12.dp(), 14.dp(), 12.dp(), 14.dp())
        }
        content.addView(fromButton, LinearLayout.LayoutParams(-1, 52.dp()).apply {
            setMargins(0, 0, 0, 8.dp())
        })

        val toButton = TextView(this).apply {
            text = "إلى تاريخ: " + formatDate(toCalendar)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(27, 91, 141))
            background = roundedBackground(Color.WHITE, Color.rgb(213, 224, 234), 1.dp())
            setPadding(12.dp(), 14.dp(), 12.dp(), 14.dp())
        }
        content.addView(toButton, LinearLayout.LayoutParams(-1, 52.dp()).apply {
            setMargins(0, 0, 0, 12.dp())
        })

        fun chooseDate(calendar: java.util.Calendar, target: TextView, prefix: String) {
            android.app.DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    calendar.set(year, month, dayOfMonth, 0, 0, 0)
                    calendar.set(java.util.Calendar.MILLISECOND, 0)
                    target.text = prefix + ": " + formatDate(calendar)
                },
                calendar.get(java.util.Calendar.YEAR),
                calendar.get(java.util.Calendar.MONTH),
                calendar.get(java.util.Calendar.DAY_OF_MONTH)
            ).show()
        }

        fromButton.setOnClickListener { chooseDate(fromCalendar, fromButton, "من تاريخ") }
        toButton.setOnClickListener { chooseDate(toCalendar, toButton, "إلى تاريخ") }

        addButton("📊 عرض التقرير", true) {
            val fromDate = formatDate(fromCalendar)
            val toDate = formatDate(toCalendar)

            if (fromDate > toDate) {
                Toast.makeText(this, "تاريخ البداية يجب أن يكون قبل تاريخ النهاية", Toast.LENGTH_LONG).show()
                return@addButton
            }

            val periodSales = CardStore.sales(this).filter { sale ->
                sale.time.length >= 10 && sale.time.substring(0, 10) in fromDate..toDate
            }

            content.findViewWithTag<View>("sales_report_result")?.let { content.removeView(it) }

            val result = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                tag = "sales_report_result"
            }

            result.addView(TextView(this).apply {
                text = "نتيجة التقرير: " + fromDate + " إلى " + toDate
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(24, 78, 117))
                gravity = Gravity.RIGHT
                setPadding(0, 8.dp(), 0, 10.dp())
            })

            val totalCount = periodSales.size
            val totalAmount = periodSales.sumOf { it.amount }

            val totalBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(16.dp(), 16.dp(), 16.dp(), 16.dp())
                background = gradientBackground(Color.rgb(18, 82, 133), Color.rgb(31, 125, 188), 12.dp())
            }
            totalBox.addView(TextView(this).apply {
                text = "إجمالي المبيعات"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            })
            totalBox.addView(TextView(this).apply {
                text = totalCount.toString() + " كرت  •  " + totalAmount + " ريال"
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(0, 6.dp(), 0, 0)
            })
            result.addView(totalBox, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 12.dp())
            })

            result.addView(TextView(this).apply {
                text = "تفصيل المبيعات حسب الباقة"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(24, 78, 117))
                gravity = Gravity.RIGHT
                setPadding(0, 8.dp(), 0, 8.dp())
            })

            val byAmount = periodSales.groupBy { it.amount }.toSortedMap()
            if (byAmount.isEmpty()) {
                result.addView(TextView(this).apply {
                    text = "لا توجد مبيعات في الفترة المحددة."
                    textSize = 15f
                    setTextColor(Color.rgb(90, 100, 110))
                    gravity = Gravity.RIGHT
                    setPadding(0, 4.dp(), 0, 12.dp())
                })
            } else {
                byAmount.forEach { (amount, items) ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                        background = roundedBackground(Color.WHITE, Color.rgb(222, 229, 236), 1.dp())
                    }
                    row.addView(TextView(this).apply {
                        text = "باقة " + amount + " ريال"
                        textSize = 17f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.rgb(25, 85, 130))
                    })
                    row.addView(TextView(this).apply {
                        text = "عدد المبيعات: " + items.size + " كرت"
                        textSize = 14f
                        setTextColor(Color.rgb(75, 85, 95))
                        setPadding(0, 4.dp(), 0, 0)
                    })
                    row.addView(TextView(this).apply {
                        text = "الإجمالي: " + (amount * items.size) + " ريال"
                        textSize = 15f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.rgb(38, 120, 85))
                        setPadding(0, 3.dp(), 0, 0)
                    })
                    result.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                        setMargins(0, 0, 0, 7.dp())
                    })
                }
            }

            result.addView(TextView(this).apply {
                text = "التفصيل اليومي"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(24, 78, 117))
                gravity = Gravity.RIGHT
                setPadding(0, 12.dp(), 0, 8.dp())
            })

            val byDay = periodSales.groupBy { it.time.substring(0, 10) }.toSortedMap()
            byDay.forEach { (day, items) ->
                result.addView(TextView(this).apply {
                    text = day + "  •  " + items.size + " كرت  •  " + items.sumOf { it.amount } + " ريال"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(45, 55, 65))
                    gravity = Gravity.RIGHT
                    setPadding(14.dp(), 11.dp(), 14.dp(), 11.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(222, 229, 236), 1.dp())
                }, LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, 7.dp())
                })
            }

            result.addView(TextView(this).apply {
                text = "تفاصيل العمليات (" + periodSales.size + ")"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(24, 78, 117))
                gravity = Gravity.RIGHT
                setPadding(0, 12.dp(), 0, 8.dp())
            })

            periodSales.take(500).forEach { sale ->
                result.addView(TextView(this).apply {
                    text = sale.time + "  •  " + sale.amount + " ريال\nرقم المشتري: " + sale.phone + "\nالكرت: " + sale.card
                    textSize = 14f
                    setTextColor(Color.rgb(55, 65, 75))
                    gravity = Gravity.RIGHT
                    setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
                    background = roundedBackground(Color.WHITE, Color.rgb(222, 229, 236), 1.dp())
                }, LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, 7.dp())
                })
            }

            content.addView(result)
        }
    }

    private fun showOperations() {
        currentScreen = "operations"
        content.removeAllViews()
        addBackButton()
        addTitle("سجل العمليات")
        val operationsSimSelector = Spinner(this).apply {
            tag = "operations_sim_selector"
            background = roundedBackground(Color.rgb(243, 248, 254), Color.rgb(203, 222, 242), 12.dp())
            adapter = styledSpinnerAdapter(listOf("SIM 1", "SIM 2"))
            setSelection(if (operationLogSimSlot == 2) 1 else 0)
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        content.addView(operationsSimSelector, LinearLayout.LayoutParams(-1, 48.dp()).apply { setMargins(0, 4.dp(), 0, 10.dp()) })
        operationsSimSelector.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val next = if (position == 1) 2 else 1
                if (operationLogSimSlot != next) { operationLogSimSlot = next; showOperations() }
            }
        }

        val operationsSearch = EditText(this).apply {
            hint = "🔎 بحث في سجل العمليات"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.rgb(25, 55, 82))
            setHintTextColor(Color.rgb(112, 133, 153))
            background = roundedBackground(Color.WHITE, Color.rgb(176, 211, 242), 14.dp())
            setPadding(14.dp(), 4.dp(), 14.dp(), 4.dp())
        }
        content.addView(operationsSearch, LinearLayout.LayoutParams(-1, 50.dp()).apply {
            setMargins(0, 6.dp(), 0, 12.dp())
        })

        addText("سجل محفوظ لعمليات إرسال الكروت: ناجحة، فاشلة، أو ما زالت قيد المعالجة.")

        val pending = OperationLog.pending(this, operationLogSimSlot)
        if (pending.isNotEmpty()) {
            addSectionTitle("⚠️ عمليات معلقة")
            addText("هذه العمليات لم تكتمل بصورة مؤكدة. لا تعاد تلقائياً حتى لا يتم إرسال نفس الكرت مرتين.")
            pending.forEach { op ->
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                    background = roundedBackground(Color.rgb(255, 248, 230), Color.rgb(230, 190, 100), 1.dp())
                }
                box.addView(TextView(this@MainActivity).apply {
                    text = "قيد المعالجة • ${op.amount} ريال • ${op.time}"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.rgb(130, 85, 15))
                })
                box.addView(TextView(this@MainActivity).apply {
                    text = "الرقم: ${op.phone}\nالكرت: ${op.card}"
                    textSize = 14f
                    setTextColor(Color.rgb(50, 50, 50))
                })
                content.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 0, 0, 8.dp())
                })
            }
        }

        val operations = OperationLog.recent(this, 300, operationLogSimSlot)
        val success = operations.count { it.status == "SUCCESS" }
        val failed = operations.count { it.status == "FAILED" }
        addSectionTitle("ملخص السجل")
        addText("ناجحة: $success   •   فاشلة: $failed   •   معلقة: ${pending.size}")

        addSectionTitle("آخر العمليات")
        if (operations.isEmpty()) {
            addText("لا توجد عمليات مسجلة بعد.")
            return
        }

        operations.forEach { op ->
            val statusText = when (op.status) {
                "SUCCESS" -> "✅ ناجحة"
                "FAILED" -> "❌ فاشلة"
                else -> "⏳ قيد المعالجة"
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp(), 11.dp(), 14.dp(), 11.dp())
                setBackgroundColor(Color.WHITE)
            }
            box.addView(TextView(this@MainActivity).apply {
                text = "$statusText • ${op.amount} ريال • ${op.time}"
                textSize = 14.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(35, 45, 55))
            })
            box.addView(TextView(this@MainActivity).apply {
                text = "الرقم: ${op.phone}\nالكرت: ${op.card}" +
                    if (op.error.isNotBlank()) "\nالسبب: ${op.error}" else ""
                textSize = 13.5f
                setTextColor(Color.rgb(75, 85, 95))
                setPadding(0, 5.dp(), 0, 0)
            })
            content.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 7.dp())
            })
        }

        fun viewContainsSearchText(view: android.view.View, query: String): Boolean {
            if (query.isBlank()) return true
            if (view is TextView && (view.text?.toString()?.contains(query, ignoreCase = true) == true)) return true
            if (view is android.view.ViewGroup) {
                for (i in 0 until view.childCount) {
                    if (viewContainsSearchText(view.getChildAt(i), query)) return true
                }
            }
            return false
        }
        operationsSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString()?.trim().orEmpty()
                for (i in 0 until content.childCount) {
                    val child = content.getChildAt(i)
                    if (child === operationsSearch) continue
                    child.visibility = if (viewContainsSearchText(child, query)) View.VISIBLE else View.GONE
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

    }

    private fun showMessageSettings() {
        currentScreen = "message_settings"
        content.removeAllViews()
        addBackButton()
        addTitle("نص رسالة الكرت")
        addText("اكتب رسالة مستقلة لكل شريحة. استخدم {السعر} لإدراج سعر الفئة تلقائيًا. إذا لم يُحفظ نص للشريحة الثانية فسيستخدم التطبيق النص العام القديم.")
        val prefs = getSharedPreferences("message_settings", MODE_PRIVATE)
        fun templateInput(key: String, fallback: String, label: String): EditText {
            addSectionTitle(label)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
                background = roundedBackground(Color.WHITE, Color.rgb(211, 226, 241), 14.dp())
            }
            val field = EditText(this).apply {
                setText(prefs.getString(key, fallback) ?: fallback)
                textSize = 16f
                gravity = Gravity.TOP or Gravity.RIGHT
                minLines = 3
                maxLines = 5
                setTextColor(Color.rgb(25,45,65))
                setHintTextColor(Color.rgb(110,125,140))
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                background = roundedBackground(Color.rgb(247,250,254), Color.rgb(220,232,244), 10.dp())
                setPadding(10.dp(), 10.dp(), 10.dp(), 10.dp())
            }
            box.addView(field, LinearLayout.LayoutParams(-1, -2))
            content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4.dp(), 0, 10.dp()) })
            return field
        }
        val defaultTemplate = "شبكة الكامل - كرت {السعر} ريال - رقم الكرت👇\n"
        val sim1 = templateInput("template_sim1", prefs.getString("template", defaultTemplate) ?: defaultTemplate, "📱 نص رسالة SIM1")
        val sim2 = templateInput("template_sim2", prefs.getString("template_sim2", prefs.getString("template", defaultTemplate)) ?: defaultTemplate, "📲 نص رسالة SIM2")
        addButton("💾 حفظ نصوص الشريحتين", true) {
            val first = sim1.text.toString()
            val second = sim2.text.toString()
            if (first.length > 44 || second.length > 44) {
                Toast.makeText(this, "يجب ألا يتجاوز نص كل شريحة 44 حرفًا", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putString("template", first).putString("template_sim1", first).putString("template_sim2", second).apply()
                Toast.makeText(this, "تم حفظ نص SIM1 وSIM2", Toast.LENGTH_SHORT).show()
            }
        }
        addText("الحد الأقصى 44 حرفًا لكل نص قبل إضافة رقم الكرت. مثال: شبكة الكامل - كرت {السعر} ريال👇")
    }

    private fun showBackup() {
        currentScreen = "backup"
        content.removeAllViews()
        addBackButton()
        addTitle("النسخ الاحتياطية")
        addText("يمكنك إنشاء نسخة احتياطية واستعادتها لاحقًا. النسخة تشمل مخزون الكروت، الكروت المباعة، وأرقام المستلمين وإعدادات التنبيه.")

        val last = getSharedPreferences("settings", MODE_PRIVATE)
            .getString("last_backup", "لم يتم إنشاء نسخة بعد")
        addText("آخر نسخة احتياطية ناجحة: " + last)
        val backupTimes = getSharedPreferences("settings", MODE_PRIVATE)
        addText("آخر نسخة تلقائية ناجحة: " + (backupTimes.getString("last_auto_backup", "لم تنجح نسخة تلقائية بعد") ?: "لم تنجح نسخة تلقائية بعد"))
        addText("آخر نسخة يدوية ناجحة: " + (backupTimes.getString("last_manual_backup", "لم يتم إنشاء نسخة يدوية بعد") ?: "لم يتم إنشاء نسخة يدوية بعد"))
        addText("آخر استعادة ناجحة: " + (backupTimes.getString("last_restore", "لم تتم استعادة نسخة بعد") ?: "لم تتم استعادة نسخة بعد"))
        val prefsForBackup = getSharedPreferences("settings", MODE_PRIVATE)
        val lastPath = prefsForBackup.getString("last_backup_path", null)
        if (!lastPath.isNullOrBlank()) addText("مكان آخر نسخة محفوظة: " + lastPath)
        val backupError = prefsForBackup.getString("last_backup_error", null)
        if (!backupError.isNullOrBlank()) addText("آخر خطأ في النسخ الاحتياطي: " + backupError)

        val settings = getSharedPreferences("settings", MODE_PRIVATE)
        val backupUri = settings.getString("backup_tree_uri", null)
        val backupFolderName = backupUri?.let {
            runCatching { DocumentFile.fromTreeUri(this, android.net.Uri.parse(it))?.name }.getOrNull()
        }
        addText(
            if (backupFolderName != null)
                "مسار النسخ الاحتياطية المحدد: " + backupFolderName + "\nالمجلد المطلوب: الكامل اونلاين بلاس المطور/نسخه احتياطيه\nسيتم إنشاء نسخة تلقائيًا كل 12 ساعة، واسم كل نسخة يتضمن تاريخ ووقت الإنشاء."
            else
                "لم يتم تحديد مجلد النسخ الاحتياطية بعد. اختر المجلد الكامل اونلاين بلاس المطور ثم نسخه احتياطيه. لن تُحفظ النسخ في التنزيلات."
        )

        addButton("📁 تحديد مسار النسخ الاحتياطية", true) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    putExtra("android.content.extra.SHOW_ADVANCED", true)
                }
            }
            startActivityForResult(intent, backupFolderRequestCode)
        }

        addButton("💾 إنشاء نسخة احتياطية الآن", true) {
            val name = BackupManager.createBackup(this)
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            if (name != null) prefs.edit().putString("last_manual_backup", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())).commit()
            val message = if (name != null) {
                "تم حفظ النسخة بنجاح: " + name + "\nالمسار: " + (prefs.getString("last_backup_path", "") ?: "")
            } else {
                "فشل إنشاء النسخة: " + (prefs.getString("last_backup_error", "سبب غير معروف") ?: "سبب غير معروف")
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            showBackup()
        }

        addButton("♻️ استعادة نسخة احتياطية") {
            android.app.AlertDialog.Builder(this)
                .setTitle("♻️ استعادة نسخة احتياطية")
                .setMessage("سيتم استبدال المخزون الحالي والمبيعات بالبيانات الموجودة في النسخة الاحتياطية. تأكد من اختيار الملف الصحيح قبل المتابعة.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("اختيار ملف النسخة") { _, _ ->
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/zip"
                    }
                    startActivityForResult(intent, restoreRequestCode)
                }
                .show()
        }

        addText("نصيحة: قبل الاستعادة، يفضل إنشاء نسخة احتياطية من البيانات الحالية.")
    }

    private fun addBackButton() {
        val backBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true
            isFocusable = true
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            background = roundedBackground(Color.rgb(238, 245, 253), Color.rgb(205, 226, 246), 12.dp())
            addView(TextView(this@MainActivity).apply {
                text = "←"
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(13, 85, 148))
                setPadding(0, 0, 8.dp(), 0)
            })
            addView(TextView(this@MainActivity).apply {
                text = "العودة إلى الشاشة الرئيسية"
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(13, 85, 148))
            })
            setOnClickListener { showDashboard() }
            setOnTouchListener { view, event ->
                if (event.action == android.view.MotionEvent.ACTION_DOWN) view.alpha = 0.75f
                if (event.action == android.view.MotionEvent.ACTION_UP || event.action == android.view.MotionEvent.ACTION_CANCEL) view.alpha = 1f
                false
            }
        }
        content.addView(backBar, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = 10.dp()
        })
    }

    private fun addTitle(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(15, 41, 66))
            gravity = Gravity.RIGHT
            setPadding(2.dp(), 8.dp(), 2.dp(), 3.dp())
        })
    }

    private fun addSectionTitle(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(15, 80, 138))
            gravity = Gravity.RIGHT
            setPadding(2.dp(), 16.dp(), 2.dp(), 8.dp())
        })
    }

    private fun addText(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 13.5f
            setTextColor(Color.rgb(71, 85, 105))
            gravity = Gravity.RIGHT
            setPadding(2.dp(), 3.dp(), 2.dp(), 10.dp())
        })
    }

    private fun addButton(text: String, primary: Boolean = false, action: () -> Unit) {
        val button = TextView(this).apply {
            this.text = text
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (primary) Color.WHITE else Color.rgb(13, 85, 148))
            background = if (primary) {
                gradientBackground(Color.rgb(13, 91, 158), Color.rgb(25, 118, 194), 14.dp())
            } else {
                roundedBackground(Color.WHITE, Color.rgb(215, 228, 242), 14.dp())
            }
            if (primary) elevation = 2.dp().toFloat()
            setPadding(16.dp(), 0, 16.dp(), 0)
            setOnClickListener { action() }
            setOnTouchListener { view, event ->
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> view.alpha = 0.82f
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> view.alpha = 1f
                }
                false
            }
        }
        content.addView(button, LinearLayout.LayoutParams(-1, 52.dp()).apply {
            setMargins(0, 0, 0, 9.dp())
        })
    }

    private fun statCard(
        title: String,
        initial: String,
        accent: Int,
        unit: String
    ): Pair<View, TextView> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14.dp(), 16.dp(), 14.dp(), 16.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(222, 234, 246), 16.dp())
            elevation = 2.dp().toFloat()
        }

        box.addView(TextView(this).apply {
            text = title
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(71, 95, 120))
            gravity = Gravity.CENTER
        })

        val value = TextView(this).apply {
            text = initial
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, 6.dp(), 0, 2.dp())
        }
        box.addView(value)

        box.addView(TextView(this).apply {
            text = unit
            textSize = 12f
            setTextColor(Color.rgb(115, 135, 156))
            gravity = Gravity.CENTER
        })

        return Pair(box, value)
    }

    private fun cardRow(title: String, value: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16.dp(), 13.dp(), 16.dp(), 13.dp())
            background = roundedBackground(Color.WHITE, Color.rgb(222, 234, 246), 14.dp())

            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 15.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(38, 48, 58))
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))

            addView(TextView(this@MainActivity).apply {
                text = value
                tag = "stock_value"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(13, 91, 158))
                gravity = Gravity.LEFT
            })

            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 0, 0, 7.dp())
            }
        }
    }

    private fun roundedBackground(fill: Int, stroke: Int, strokeWidth: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            val effectiveRadius = if (strokeWidth > 4.dp()) strokeWidth.toFloat() else 14.dp().toFloat()
            val effectiveStrokeWidth = if (stroke == 0 || stroke == Color.TRANSPARENT) 0 else 1.dp()
            cornerRadius = effectiveRadius
            if (effectiveStrokeWidth > 0) setStroke(effectiveStrokeWidth, stroke)
        }

    private fun gradientBackground(start: Int, end: Int, radius: Int): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(start, end)
        ).apply {
            cornerRadius = radius.toFloat()
        }

    private fun setupSmsArchiveSchedules() {
        // Initialize only the isolated SMS database; no operational app data is touched.
        SmsArchiveDb(this).close()
        val sync = PeriodicWorkRequestBuilder<SmsArchiveSyncWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "alkamel_sms_archive_sync_v121", ExistingPeriodicWorkPolicy.KEEP, sync
        )
        val backup = PeriodicWorkRequestBuilder<SmsArchiveBackupWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "alkamel_sms_archive_backup_v121", ExistingPeriodicWorkPolicy.KEEP, backup
        )
    }

    private fun setupBackupSchedule() {
        val request = PeriodicWorkRequestBuilder<BackupWorker>(12, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "alkamel_12h_backup",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
    private fun requestPermissions(){val needed=mutableListOf(Manifest.permission.RECEIVE_SMS,Manifest.permission.READ_SMS,Manifest.permission.SEND_SMS);if(android.os.Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)needed.add(Manifest.permission.POST_NOTIFICATIONS);val missing=needed.filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED};if(missing.isNotEmpty())ActivityCompat.requestPermissions(this,missing.toTypedArray(),requestCode)}
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}

// ALKAMEL_PRO_UI_POLISH_V1

// ALKAMEL_STOCK_SEARCH_COPYRIGHT_V1

// ALKAMEL_CATEGORY_PREFIX_GUARD_V1

// ALKAMEL_CATEGORY_PREFIX_GUARD_V1

// ALKAMEL_CARD_FILE_IMPORT_V1

// ALKAMEL_CATEGORY_MANAGEMENT_SIM_SELECTOR_V1
