package ye.alkamel.cardsender

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One-time low-value unavailable-card notice, keyed by the resolved recipient mobile. */
object UnavailableCardManager {
    private const val PREFS = "unavailable_card_service"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_MESSAGE = "message"
    private const val KEY_SENT = "sent_numbers"
    private const val KEY_PENDING = "pending_notices"
    private const val KEY_HISTORY = "history"

    data class Notice(val id: String, val phone: String, val amount: Int, val sim: Int, val subscriptionId: Int)
    data class History(val phone: String, val amount: Int, val sim: Int, val time: String)

    fun isEnabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) { prefs(context).edit().putBoolean(KEY_ENABLED, enabled).commit() }
    fun message(context: Context) = prefs(context).getString(KEY_MESSAGE, "نعتذر، الكرت المطلوب غير متوفر حالياً. شكراً لتفهمك.").orEmpty()
    fun setMessage(context: Context, value: String) { prefs(context).edit().putString(KEY_MESSAGE, value).commit() }

    @Synchronized fun reserve(context: Context, phoneRaw: String, amount: Int, sim: Int, subscriptionId: Int, transferAmount: Int = amount): Notice? {
        if (!isEnabled(context) || transferAmount !in 1..499 || amount <= 0) return null
        val phone = LoanManager.normalizePhone(phoneRaw)
        if (phone.length != 9) return null
        val p = prefs(context)
        val sent = p.getStringSet(KEY_SENT, emptySet())?.toMutableSet() ?: mutableSetOf()
        val pending = readPending(context)
        if (phone in sent || pending.values.any { it.phone == phone }) return null
        val id = "UN-${System.currentTimeMillis()}-${System.nanoTime().toString().takeLast(5)}"
        val notice = Notice(id, phone, amount, if (sim == 2) 2 else 1, subscriptionId)
        pending[id] = notice
        writePending(context, pending)
        return notice
    }

    @Synchronized fun finish(context: Context, id: String, success: Boolean) {
        val pending = readPending(context)
        val notice = pending[id] ?: return
        if (success) {
            pending.remove(id)
            val p = prefs(context)
            val sent = p.getStringSet(KEY_SENT, emptySet())?.toMutableSet() ?: mutableSetOf()
            sent.add(notice.phone)
            val history = JSONArray(p.getString(KEY_HISTORY, "[]") ?: "[]")
            history.put(JSONObject().put("phone", notice.phone).put("amount", notice.amount)
                .put("sim", notice.sim).put("time", now()))
            p.edit().putStringSet(KEY_SENT, sent).putString(KEY_HISTORY, history.toString()).commit()
        }
        // Keep an uncertain send reserved after a failed/ambiguous callback. This
        // prevents a second notice from being sent to the same customer.
        writePending(context, pending)
    }

    fun sendOnce(context: Context, phone: String, amount: Int, sim: Int, subscriptionId: Int, transferAmount: Int = amount): Boolean {
        val notice = reserve(context, phone, amount, sim, subscriptionId, transferAmount) ?: return false
        return UnavailableNoticeSender.send(context, notice)
    }

    fun history(context: Context): List<History> {
        val array = try { JSONArray(prefs(context).getString(KEY_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        return (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            History(o.optString("phone"), o.optInt("amount"), o.optInt("sim", 1), o.optString("time"))
        }.reversed()
    }

    fun sentCount(context: Context) = prefs(context).getStringSet(KEY_SENT, emptySet())?.size ?: 0
    fun pendingCount(context: Context) = readPending(context).size

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    private fun readPending(context: Context): MutableMap<String, Notice> {
        val a = try { JSONArray(prefs(context).getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val result = linkedMapOf<String, Notice>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isNotBlank()) result[id] = Notice(id, o.optString("phone"), o.optInt("amount"), o.optInt("sim", 1), o.optInt("sub"))
        }
        return result
    }
    private fun writePending(context: Context, values: Map<String, Notice>) {
        val a = JSONArray()
        values.values.forEach { a.put(JSONObject().put("id", it.id).put("phone", it.phone).put("amount", it.amount).put("sim", it.sim).put("sub", it.subscriptionId)) }
        prefs(context).edit().putString(KEY_PENDING, a.toString()).commit()
    }
}
