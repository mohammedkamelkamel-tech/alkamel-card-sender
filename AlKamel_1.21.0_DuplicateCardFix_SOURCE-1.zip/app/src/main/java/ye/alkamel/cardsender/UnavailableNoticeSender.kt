package ye.alkamel.cardsender

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

object UnavailableNoticeSender {
    fun send(context: Context, notice: UnavailableCardManager.Notice): Boolean {
        return try {
            val message = UnavailableCardManager.message(context).trim()
            if (message.isBlank()) {
                UnavailableCardManager.finish(context, notice.id, false)
                false
            } else {
        val manager = SmsManager.getSmsManagerForSubscriptionId(notice.subscriptionId)
        val parts = manager.divideMessage(message)
        val callbacks = ArrayList<PendingIntent>()
        parts.indices.forEach { index ->
            val intent = Intent(context, UnavailableNoticeSentReceiver::class.java).apply {
                action = "ye.alkamel.cardsender.UNAVAILABLE_SENT.${notice.id}.$index"
                putExtra("notice_id", notice.id)
                putExtra("part_index", index)
                putExtra("part_count", parts.size)
            }
            callbacks.add(PendingIntent.getBroadcast(context, (notice.id + ":" + index).hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
        if (parts.size == 1) manager.sendTextMessage(notice.phone, null, message, callbacks[0], null)
        else manager.sendMultipartTextMessage(notice.phone, null, ArrayList(parts), callbacks, null)
                true
            }
        } catch (_: Exception) {
            UnavailableCardManager.finish(context, notice.id, false)
            false
        }
    }
}
