package ye.alkamel.cardsender
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import android.net.Uri
import android.util.Base64
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream

object BackupManager {
    /**
     * ينشئ نسخة احتياطية واحدة فقط ويستبدل النسخة السابقة.
     */
    fun createBackup(context: Context): String? {
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        return try {
            val name = "alkamel_backup" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".zip"
            val selectedTree = prefs.getString("backup_tree_uri", null)
                ?: throw IllegalStateException("حدد مجلد النسخ الاحتياطية أولًا: الكامل اونلاين بلاس المطور/نسخه احتياطيه")
            if (selectedTree.isBlank()) {
                throw IllegalStateException("حدد مجلد النسخ الاحتياطية أولًا: الكامل اونلاين بلاس المطور/نسخه احتياطيه")
            }
            val treeUri = Uri.parse(selectedTree)
            val tree = DocumentFile.fromTreeUri(context, treeUri)
                ?: throw IllegalStateException("مسار النسخ الاحتياطي غير متاح؛ أعد تحديد المجلد")
            if (!tree.canWrite()) {
                throw IllegalStateException("لا توجد صلاحية للكتابة في المجلد المحدد؛ أعد تحديد مسار النسخ الاحتياطي")
            }
            val file = tree.createFile("application/zip", name)
                ?: throw IllegalStateException("تعذر إنشاء ملف داخل المجلد المحدد")
            var savedLocation = tree.name ?: selectedTree
            try {
                val output = context.contentResolver.openOutputStream(file.uri, "w")
                    ?: throw IllegalStateException("تعذر فتح ملف النسخة للكتابة")
                output.use { stream ->
                    ZipOutputStream(BufferedOutputStream(stream)).use { zip -> writeZip(context, zip) }
                }
                if (file.length() <= 0L) throw IllegalStateException("تم إنشاء ملف النسخة لكنه فارغ")
                val hasEntries = context.contentResolver.openInputStream(file.uri)?.use { input ->
                    ZipInputStream(BufferedInputStream(input)).use { zip ->
                        var entryCount = 0
                        var entry = zip.nextEntry
                        while (entry != null) {
                            while (zip.read() != -1) { }
                            entryCount++
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                        entryCount > 0
                    }
                } ?: false
                if (!hasEntries) throw IllegalStateException("فشل التحقق من ملف النسخة الاحتياطية")
            } catch (e: Exception) {
                file.delete()
                throw e
            }

            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            prefs.edit().putString("last_backup", stamp).putString("last_backup_path", savedLocation)
                .remove("last_backup_error").commit()
            name
        } catch (e: Exception) {
            prefs.edit().putString("last_backup_error", e.localizedMessage ?: e.javaClass.simpleName).commit()
            null
        }
    }
    private fun resolverInsert(context: Context, collection: Uri, values: ContentValues): Uri? =
        context.contentResolver.insert(collection, values)

    fun restoreBackup(context: Context, uri: Uri): Result {
        return try {
            val tempRoot = File(context.cacheDir, "restore_" + System.currentTimeMillis()).apply {
                deleteRecursively()
                mkdirs()
            }
            val tempCards = File(tempRoot, "cards").apply { mkdirs() }
            var hasCardFile = false
            var hasSales = false
            var hasOperations = false
            var hasAppSettings = false
            val thresholds = mutableMapOf<Int, Int>()
            val alternateMappings = mutableMapOf<String, String>()
            var messageTemplate: String? = null

            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(BufferedInputStream(input)).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.isDirectory) {
                            zip.closeEntry()
                            entry = zip.nextEntry
                            continue
                        }

                        val name = entry.name.replace('\\', '/')
                        if (name.contains("..") || name.startsWith("/") || name.contains(":")) {
                            throw IllegalArgumentException("ملف النسخة الاحتياطية غير صالح")
                        }

                        when {
                            name.startsWith("appdata/") -> {
                                val relative = name.removePrefix("appdata/")
                                val base = File(tempRoot, "appdata").canonicalFile
                                val target = File(base, relative).canonicalFile
                                if (!target.path.startsWith(base.path + File.separator)) throw IllegalArgumentException("مسار بيانات غير صالح داخل النسخة الاحتياطية")
                                target.parentFile?.mkdirs()
                                BufferedOutputStream(target.outputStream()).use { zip.copyTo(it) }
                            }
                            name.startsWith("cards/") && (name.endsWith(".txt") || name.endsWith(".csv")) -> {
                                val relative = name.removePrefix("cards/")
                                val parts = relative.split("/")
                                val sim = if (parts.size >= 2 && (parts[0] == "sim1" || parts[0] == "sim2")) parts[0] else "sim1"
                                val fileName = if (parts.size >= 2) parts.last() else parts[0]
                                val targetDir = File(tempCards, sim).apply { mkdirs() }
                                if (fileName.endsWith(".txt")) {
                                    val amount = fileName.removeSuffix(".txt").toIntOrNull()
                                        ?: throw IllegalArgumentException("فئة كرت غير صالحة")
                                    if (amount <= 0) throw IllegalArgumentException("فئة كرت غير صالحة")
                                    val out = File(targetDir, "$amount.txt")
                                    BufferedOutputStream(out.outputStream()).use { zip.copyTo(it) }
                                    hasCardFile = true
                                } else {
                                    val out = File(targetDir, "sales.csv")
                                    BufferedOutputStream(out.outputStream()).use { zip.copyTo(it) }
                                    hasSales = true
                                }
                            }
                            name == "sales.csv" -> {
                                val out = File(tempCards, "sim1/sales.csv")
                                out.parentFile?.mkdirs()
                                BufferedOutputStream(out.outputStream()).use { zip.copyTo(it) }
                                hasSales = true
                            }
                            name == "operations.log" -> {
                                val out = File(tempRoot, "operations.log")
                                BufferedOutputStream(out.outputStream()).use { zip.copyTo(it) }
                                hasOperations = true
                            }
                            name == "app_settings.txt" -> {
                                val text = zip.readBytes().toString(Charsets.UTF_8)
                                text.lineSequence().forEach { line ->
                                    when {
                                        line.startsWith("template_b64=") -> {
                                            runCatching {
                                                messageTemplate = String(
                                                    Base64.decode(line.removePrefix("template_b64="), Base64.DEFAULT),
                                                    Charsets.UTF_8
                                                )
                                            }
                                        }
                                        line.startsWith("map_b64=") -> {
                                            val parts = line.removePrefix("map_b64=").split("|", limit = 2)
                                            if (parts.size == 2) {
                                                runCatching {
                                                    val a = String(Base64.decode(parts[0], Base64.DEFAULT), Charsets.UTF_8)
                                                    val p = String(Base64.decode(parts[1], Base64.DEFAULT), Charsets.UTF_8)
                                                    if (a.isNotBlank() && p.isNotBlank()) alternateMappings[a] = p
                                                }
                                            }
                                        }
                                    }
                                }
                                hasAppSettings = true
                            }
                            name == "settings.txt" -> {
                                val text = zip.readBytes().toString(Charsets.UTF_8)
                                text.lineSequence().forEach { line ->
                                    val prefix = "stock_alert_threshold_"
                                    if (line.startsWith(prefix)) {
                                        val p = line.substring(prefix.length).split("=", limit = 2)
                                        val amount = p.getOrNull(0)?.toIntOrNull()
                                        val value = p.getOrNull(1)?.toIntOrNull()
                                        if (amount != null && value != null && amount > 0 && value >= 0) {
                                            thresholds[amount] = value
                                        }
                                    }
                                }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: throw IllegalArgumentException("تعذر قراءة ملف النسخة الاحتياطية")

            if (!hasCardFile && !hasSales && !hasOperations && !hasAppSettings) {
                throw IllegalArgumentException("ملف النسخة الاحتياطية لا يحتوي على بيانات صالحة")
            }

            val cardFiles = tempCards.walkTopDown().filter { it.isFile && it.extension == "txt" }.toList()
            val categories = cardFiles.mapNotNull { it.nameWithoutExtension.toIntOrNull() }
                .filter { it > 0 }.distinct().sorted()
            if (categories.isEmpty()) {
                throw IllegalArgumentException("لا توجد فئات كروت في النسخة الاحتياطية")
            }

            val liveCards = File(context.filesDir, "cards").apply { mkdirs() }
            liveCards.listFiles()?.forEach { it.deleteRecursively() }
            tempCards.listFiles()?.filter { it.isDirectory }?.forEach { source ->
                source.copyRecursively(File(liveCards, source.name), overwrite = true)
            }

            if (hasSales) {
                for (sim in listOf("sim1", "sim2")) {
                    val source = File(tempCards, "$sim/sales.csv")
                    if (source.exists()) source.copyTo(File(liveCards, "$sim/sales.csv"), overwrite = true)
                }
            }
            if (hasOperations) {
                File(tempRoot, "operations.log").copyTo(OperationLog.backupFile(context), overwrite = true)
            }

            if (hasAppSettings) {
                if (messageTemplate != null) {
                    context.getSharedPreferences("message_settings", Context.MODE_PRIVATE)
                        .edit().putString("template", messageTemplate).apply()
                }
                alternateMappings.forEach { (alternate, phone) ->
                    ContactMap.setPhone(context, alternate, phone)
                }
            }

            context.getSharedPreferences("card_categories", Context.MODE_PRIVATE)
                .edit()
                .putStringSet("categories", categories.map { it.toString() }.toSet())
                .apply()

            categories.forEach { amount ->
                StockNotification.setThreshold(
                    context,
                    amount,
                    thresholds[amount] ?: StockNotification.getThreshold(context, amount)
                )
            }

            restoreCompleteAppData(context, File(tempRoot, "appdata"))
            CardStore.initializeFiles(context)
            tempRoot.deleteRecursively()
            Result.Success(categories.size)
        } catch (e: Exception) {
            Result.Error(e.message ?: "تعذر استعادة النسخة الاحتياطية")
        }
    }

    sealed class Result {
        data class Success(val categories: Int) : Result()
        data class Error(val message: String) : Result()
    }

    private fun writeZip(context: Context, zip: ZipOutputStream) {
        CardStore.backupFiles(context).forEach { file ->
            if (file.exists()) {
                val parent = file.parentFile?.name
                val relative = when {
                    file.name == "operations.log" -> "operations.log"
                    parent == "sim1" || parent == "sim2" -> "cards/$parent/${file.name}"
                    else -> "cards/${file.name}"
                }
                zip.putNextEntry(ZipEntry(relative))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        zip.putNextEntry(ZipEntry("settings.txt"))
        val settings = buildString {
            append("app=الكامل أونلاين\n")
            append("version=1.16.0\n")
            CardStore.categories(context).forEach { amount ->
                append("stock_alert_threshold_$amount=${StockNotification.getThreshold(context, amount)}\n")
            }
        }
        zip.write(settings.toByteArray(Charsets.UTF_8))
        zip.closeEntry()

        zip.putNextEntry(ZipEntry("app_settings.txt"))
        val prefs = context.getSharedPreferences("message_settings", Context.MODE_PRIVATE)
        val template = prefs.getString("template", "") ?: ""
        val appSettings = buildString {
            append("template_b64=")
            append(Base64.encodeToString(template.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
            append("\n")
            ContactMap.all(context).forEach { (alternate, phone) ->
                append("map_b64=")
                append(Base64.encodeToString(alternate.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                append("|")
                append(Base64.encodeToString(phone.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                append("\n")
            }
        }
        zip.write(appSettings.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        writeCompleteAppData(context, zip)
    }

    private fun writeCompleteAppData(context: Context, zip: ZipOutputStream) {
        addTreeToZip(context.filesDir, "appdata/files/", zip)
        addTreeToZip(context.noBackupFilesDir, "appdata/no_backup/", zip)
        addTreeToZip(File(context.applicationInfo.dataDir, "shared_prefs"), "appdata/shared_prefs/", zip)
        addTreeToZip(File(context.applicationInfo.dataDir, "databases"), "appdata/databases/", zip)
        context.getExternalFilesDir(null)?.let { addTreeToZip(it, "appdata/external_files/", zip) }
    }

    private fun addTreeToZip(root: File, prefix: String, zip: ZipOutputStream) {
        if (!root.isDirectory) return
        root.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(root).invariantSeparatorsPath
            if (relative.isNotBlank() && !relative.startsWith("../")) {
                zip.putNextEntry(ZipEntry(prefix + relative))
                file.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }
    private fun restoreCompleteAppData(context: Context, root: File) {
        if (!root.isDirectory) return
        val filesBackup=File(root,"files")
        if(filesBackup.isDirectory) {
            context.filesDir.listFiles()?.forEach { it.deleteRecursively() }
            filesBackup.listFiles()?.forEach { it.copyRecursively(File(context.filesDir,it.name),overwrite=true) }
        }
        val noBackup=File(root,"no_backup")
        if(noBackup.isDirectory) {
            context.noBackupFilesDir.listFiles()?.forEach { it.deleteRecursively() }
            noBackup.listFiles()?.forEach { it.copyRecursively(File(context.noBackupFilesDir,it.name),overwrite=true) }
        }
        val dbSource=File(root,"databases")
        if(dbSource.isDirectory) {
            context.databaseList().forEach { context.deleteDatabase(it) }
            val dbTarget=File(context.applicationInfo.dataDir,"databases").apply { mkdirs() }
            dbSource.listFiles()?.forEach { it.copyRecursively(File(dbTarget,it.name),overwrite=true) }
        }
        val settingsBefore=context.getSharedPreferences("settings",Context.MODE_PRIVATE)
        val treeUri=settingsBefore.getString("backup_tree_uri",null)
        val lastBackup=settingsBefore.getString("last_backup",null)
        val lastPath=settingsBefore.getString("last_backup_path",null)
        val lastAuto=settingsBefore.getString("last_auto_backup",null)
        val lastManual=settingsBefore.getString("last_manual_backup",null)
        val prefsSource=File(root,"shared_prefs")
        if(prefsSource.isDirectory) {
            val backedNames=prefsSource.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.map { it.name.removeSuffix(".xml") }?.toSet() ?: emptySet()
            File(context.applicationInfo.dataDir,"shared_prefs").listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach {
                val n=it.name.removeSuffix(".xml")
                // Keep the locally device-bound purchase license, even if the backup lacks it.
                if(n !in backedNames && n != "license") context.getSharedPreferences(n,Context.MODE_PRIVATE).edit().clear().commit()
            }
            prefsSource.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { applyPrefsXml(context,it) }
            val e=context.getSharedPreferences("settings",Context.MODE_PRIVATE).edit()
            if(treeUri!=null)e.putString("backup_tree_uri",treeUri)
            if(lastBackup!=null)e.putString("last_backup",lastBackup)
            if(lastPath!=null)e.putString("last_backup_path",lastPath)
            if(lastAuto!=null)e.putString("last_auto_backup",lastAuto)
            if(lastManual!=null)e.putString("last_manual_backup",lastManual)
            if(!e.commit()) throw IllegalStateException("تعذر حفظ إعدادات النسخ الاحتياطي لهذا الجهاز")
        }
        val extSource=File(root,"external_files")
        val extTarget=context.getExternalFilesDir(null)
        if(extSource.isDirectory && extTarget!=null) {
            extTarget.listFiles()?.forEach { it.deleteRecursively() }
            extSource.listFiles()?.forEach { it.copyRecursively(File(extTarget,it.name),overwrite=true) }
        }
    }

    private fun applyPrefsXml(context: Context, xml: File) {
        val name=xml.name.removeSuffix(".xml")
        // Never restore the license preference file from a backup: its device binding is local.
        if (name == "license") return
        val parser=android.util.Xml.newPullParser()
        xml.inputStream().use { input ->
            parser.setInput(input,"UTF-8")
            val editor=context.getSharedPreferences(name,Context.MODE_PRIVATE).edit().clear()
            var event=parser.eventType
            while(event!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                if(event==org.xmlpull.v1.XmlPullParser.START_TAG) when(parser.name) {
                    "string" -> { val k=parser.getAttributeValue(null,"name"); val v=parser.nextText(); if(k!=null)editor.putString(k,v) }
                    "int" -> { val k=parser.getAttributeValue(null,"name"); val v=parser.getAttributeValue(null,"value")?.toIntOrNull(); if(k!=null&&v!=null)editor.putInt(k,v) }
                    "long" -> { val k=parser.getAttributeValue(null,"name"); val v=parser.getAttributeValue(null,"value")?.toLongOrNull(); if(k!=null&&v!=null)editor.putLong(k,v) }
                    "float" -> { val k=parser.getAttributeValue(null,"name"); val v=parser.getAttributeValue(null,"value")?.toFloatOrNull(); if(k!=null&&v!=null)editor.putFloat(k,v) }
                    "boolean" -> { val k=parser.getAttributeValue(null,"name"); val v=parser.getAttributeValue(null,"value")?.toBooleanStrictOrNull(); if(k!=null&&v!=null)editor.putBoolean(k,v) }
                    "set" -> {
                        val k=parser.getAttributeValue(null,"name"); val values=linkedSetOf<String>(); var nested=parser.next()
                        while(!(nested==org.xmlpull.v1.XmlPullParser.END_TAG && parser.name=="set") && nested!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                            if(nested==org.xmlpull.v1.XmlPullParser.START_TAG && parser.name=="string") values.add(parser.nextText())
                            nested=parser.next()
                        }
                        if(k!=null)editor.putStringSet(k,values)
                    }
                }
                event=parser.next()
            }
            if(!editor.commit()) throw IllegalStateException("تعذر حفظ إعدادات النسخة المستعادة: $name")
        }
    }

}
