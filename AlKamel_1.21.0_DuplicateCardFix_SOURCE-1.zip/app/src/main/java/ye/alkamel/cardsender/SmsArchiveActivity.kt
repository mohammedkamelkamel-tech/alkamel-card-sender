package ye.alkamel.cardsender

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import java.io.FileOutputStream

class SmsArchiveActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var db: SmsArchiveDb
    private var threadId: Long? = null
    private var currentAddress = ""
    private val blue = Color.rgb(18, 103, 171)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = SmsArchiveDb(this)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), 910)
        } else {
            requestContactsIfNeeded()
        }
        showConversations()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 910) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                requestContactsIfNeeded()
            } else {
                showConversations()
            }
        }
        if (requestCode == 911) showConversations()
    }

    private fun requestContactsIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), 911)
        }
    }

    override fun onDestroy() { db.close(); super.onDestroy() }

    @Deprecated("Deprecated in Android API but retained for compatibility with the app's Activity structure")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 912 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            // Close the archive helper on the UI thread before replacing its database file.
            // A modal progress dialog prevents taps from racing with the restore operation.
            val progress = ProgressDialog.show(this, "استعادة الأرشيف", "جارٍ التحقق والاستعادة...", true, false)
            db.close()
            Thread {
                var failure: Exception? = null
                try { restoreArchiveFile(uri) } catch (e: Exception) { failure = e }
                runOnUiThread {
                    db = SmsArchiveDb(this)
                    progress.dismiss()
                    if (failure == null) {
                        Toast.makeText(this, "تمت استعادة أرشيف SMS فقط", Toast.LENGTH_LONG).show()
                        showConversations()
                    } else {
                        Toast.makeText(this, failure?.message ?: "فشلت الاستعادة", Toast.LENGTH_LONG).show()
                        showConversations()
                    }
                }
            }.start()
        }
    }

    private fun restoreArchiveFile(uri: Uri) = synchronized(SmsArchiveGate.lock) {
        val temp = File(cacheDir, "sms-restore-${System.currentTimeMillis()}.db")
        var found = false
        contentResolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    require(entry.name == "alkamel_sms_archive_v121.db" && !found) {
                        "ملف النسخة الاحتياطية يحتوي على عناصر غير متوقعة"
                    }
                    FileOutputStream(temp).use { out ->
                        val buffer = ByteArray(8192)
                        var total = 0L
                        while (true) {
                            val n = zip.read(buffer)
                            if (n < 0) break
                            if (n == 0) continue
                            total += n
                            require(total <= 250L * 1024L * 1024L) { "ملف الأرشيف أكبر من الحد المسموح" }
                            out.write(buffer, 0, n)
                        }
                    }
                    found = true
                    zip.closeEntry()
                }
            }
        } ?: error("تعذر قراءة ملف النسخة الاحتياطية")
        require(found && temp.length() > 0) { "الملف لا يحتوي على أرشيف SMS صالح" }
        val check = android.database.sqlite.SQLiteDatabase.openDatabase(
            temp.absolutePath, null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY
        )
        try {
            check.rawQuery("PRAGMA quick_check", null).use { c ->
                require(c.moveToFirst() && c.getString(0) == "ok") { "قاعدة بيانات النسخة تالفة" }
            }
            check.rawQuery("PRAGMA table_info(sms_archive)", null).use { c ->
                val columns = mutableSetOf<String>()
                val nameColumn = c.getColumnIndexOrThrow("name")
                while (c.moveToNext()) columns.add(c.getString(nameColumn))
                require(columns.containsAll(setOf("id", "thread_id", "address", "body", "date", "type"))) {
                    "بنية قاعدة بيانات الأرشيف غير متوافقة"
                }
            }
        } finally { check.close() }
        val target = getDatabasePath("alkamel_sms_archive_v121.db")
        val old = File(target.parentFile, target.name + ".previous")
        val wal = File(target.path + "-wal")
        val shm = File(target.path + "-shm")
        if (old.exists() && !old.delete()) error("تعذر حذف ملف الاستعادة السابق")
        if (target.exists() && !target.renameTo(old)) error("تعذر تجهيز قاعدة البيانات الحالية للاستعادة")
        // Sidecar files belong to the old database and must never be applied to the restored DB.
        wal.delete(); shm.delete()
        if (!temp.renameTo(target)) {
            if (old.exists() && !old.renameTo(target)) {
                error("تعذر تثبيت قاعدة البيانات المستعادة، والنسخة السابقة محفوظة باسم ${old.name}")
            }
            error("تعذر تثبيت قاعدة البيانات المستعادة")
        }
        old.delete()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(246,249,253))
        }
        root.addView(TextView(this).apply {
            text = "‹   $title"; textSize = 21f; setTextColor(blue)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(4,8,4,16)
            setOnClickListener { if(threadId != null) showConversations() else finish() }
        }, LinearLayout.LayoutParams(-1,-2))
        setContentView(root)
    }

    private fun searchBox(hint: String, changed: (String)->Unit): EditText {
        val e = EditText(this).apply {
            this.hint=hint; textSize=15f; isSingleLine=true
            setPadding(12,4,12,4)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius=24f; setStroke(1,Color.LTGRAY)
            }
        }
        e.addTextChangedListener { changed(it?.toString().orEmpty()) }
        root.addView(e,LinearLayout.LayoutParams(-1,48).apply { bottomMargin=10 })
        return e
    }

    private fun scrollList(): LinearLayout {
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) },LinearLayout.LayoutParams(-1,0,1f))
        return list
    }

    private fun showConversations(query: String = "") {
        threadId=null
        base("جميع رسائل SMS")
        val statusPrefs = getSharedPreferences("sms_archive_status_v121", MODE_PRIVATE)
        val syncStatus = statusPrefs.getString("sync_status", "never")
        val lastSync = statusPrefs.getLong("last_sync_time", 0L)
        val syncLine = when (syncStatus) {
            "ok" -> "آخر مزامنة ناجحة: " + SimpleDateFormat("yyyy/MM/dd  hh:mm a", Locale.getDefault()).format(Date(lastSync))
            "permission_denied" -> "اسمح للتطبيق بقراءة SMS لتفعيل الأرشيف"
            "error" -> "تعذرت المزامنة الأخيرة؛ ستتم المحاولة في الموعد القادم"
            else -> "المزامنة التلقائية كل 6 ساعات"
        }
        val lastBackup = statusPrefs.getLong("last_backup_time", 0L)
        val backupLine = if (lastBackup > 0L) "آخر نسخة احتياطية: " + SimpleDateFormat("yyyy/MM/dd  hh:mm a", Locale.getDefault()).format(Date(lastBackup)) else "النسخ الاحتياطي التلقائي يومياً"
        val statusText = "$syncLine\n$backupLine"
        root.addView(TextView(this).apply {
            text = statusText; textSize = 12f; setTextColor(Color.GRAY)
            gravity = Gravity.RIGHT; setPadding(4, 0, 4, 8)
        })
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val backup=Button(this).apply { text="نسخة احتياطية"; setOnClickListener {
            Thread { try { val f=SmsArchiveBackup.create(this@SmsArchiveActivity); runOnUiThread {
                getSharedPreferences("sms_archive_status_v121", MODE_PRIVATE).edit()
                    .putString("backup_status", "ok").putLong("last_backup_time", System.currentTimeMillis()).apply()
                Toast.makeText(this@SmsArchiveActivity,"تم التحقق من النسخة: ${f.name}",Toast.LENGTH_LONG).show()
            }} catch(e:Exception) { runOnUiThread { Toast.makeText(this@SmsArchiveActivity,e.message ?: "فشل النسخ",Toast.LENGTH_LONG).show() } } }.start()
        }}
        val restore=Button(this).apply { text="استعادة"; setOnClickListener {
            val pick=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type="application/zip"
            }
            startActivityForResult(pick, 912)
        }}
        actions.addView(backup,LinearLayout.LayoutParams(0,48,1f))
        actions.addView(restore,LinearLayout.LayoutParams(0,48,1f))
        root.addView(actions)
        val search = EditText(this).apply {
            hint="ابحث في جميع الرسائل أو الأرقام أو أرقام الكروت"; textSize=15f; isSingleLine=true
            setPadding(12,4,12,4)
            background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=24f; setStroke(1,Color.LTGRAY) }
        }
        root.addView(search,LinearLayout.LayoutParams(-1,48).apply { bottomMargin=10 })
        val list=scrollList()
        fun renderRows(term: String) {
            list.removeAllViews()
            val rows=if(term.isBlank()) db.conversations() else db.search(term)
            rows.forEach { msg ->
            val name=contactName(msg.address) ?: msg.address
            val row=TextView(this).apply {
                text="$name\n${msg.body}\n${formatDate(msg.date)}"
                textSize=14f; setTextColor(Color.rgb(35,55,75)); gravity=Gravity.RIGHT
                setPadding(14,12,14,12)
                background=android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius=16f; setStroke(1,Color.rgb(225,234,244))
                }
                setOnClickListener { threadId=msg.threadId; currentAddress=msg.address; showThread(msg.threadId,msg.address) }
            }
            list.addView(row,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
        }
            if(rows.isEmpty()) list.addView(TextView(this).apply {
                text=if (ContextCompat.checkSelfPermission(this@SmsArchiveActivity, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) "لا توجد رسائل محفوظة بعد. تتم المزامنة التلقائية كل 6 ساعات." else "يلزم السماح للتطبيق بقراءة رسائل SMS لعرض الأرشيف."
                textSize=15f; gravity=Gravity.CENTER; setPadding(12,30,12,30); setTextColor(Color.GRAY)
            })
        }
        renderRows(query)
        search.addTextChangedListener { renderRows(it?.toString().orEmpty()) }
    }

    private fun showThread(id: Long, address: String, query: String = "") {
        threadId=id; currentAddress=address
        base(contactName(address) ?: address)
        val search = EditText(this).apply {
            hint="بحث داخل هذه المحادثة"; textSize=15f; isSingleLine=true
            setPadding(12,4,12,4)
            background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=24f; setStroke(1,Color.LTGRAY) }
        }
        root.addView(search,LinearLayout.LayoutParams(-1,48).apply { bottomMargin=10 })
        val list=scrollList()
        fun renderMessages(term: String) {
            list.removeAllViews()
            db.messages(id,term).forEach { msg ->
            val incoming=msg.type==1
            val bubble=TextView(this).apply {
                text=msg.body+"\n"+formatDate(msg.date)
                textSize=15f; setTextColor(Color.rgb(30,45,60)); setPadding(14,10,14,10)
                gravity=Gravity.RIGHT
                background=android.graphics.drawable.GradientDrawable().apply {
                    setColor(if(incoming) Color.WHITE else Color.rgb(220,239,255))
                    cornerRadius=18f
                }
                setOnLongClickListener {
                    val clip=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clip.setPrimaryClip(android.content.ClipData.newPlainText("SMS",msg.body))
                    Toast.makeText(this@SmsArchiveActivity,"تم نسخ نص الرسالة",Toast.LENGTH_SHORT).show()
                    true
                }
            }
            val wrap=LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL
                gravity=if(incoming) Gravity.START else Gravity.END
                addView(bubble,LinearLayout.LayoutParams((resources.displayMetrics.widthPixels*0.78f).toInt(),-2))
            }
            list.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
            }
        }
        renderMessages(query)
        search.addTextChangedListener { renderMessages(it?.toString().orEmpty()) }
    }

    private fun contactName(number: String): String? {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return null
        return try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI.buildUpon().appendPath(number).build(),
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),null,null,null
            )?.use { c -> if(c.moveToFirst()) c.getString(0) else null }
        } catch(_:Exception) { null }
    }

    private fun formatDate(time:Long):String =
        SimpleDateFormat("yyyy/MM/dd  hh:mm a",Locale.getDefault()).format(Date(time))
}
