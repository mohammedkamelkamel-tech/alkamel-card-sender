package ye.alkamel.cardsender

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.util.Log

class LoanSmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val id=intent.getStringExtra("loan_id") ?: return
        val phone=intent.getStringExtra("loan_phone").orEmpty()
        val card=intent.getStringExtra("loan_card").orEmpty()
        val sim=intent.getIntExtra("loan_sim",1)
        if (!LoanManager.isPendingRequest(context,id)) return
        if(resultCode==Activity.RESULT_OK) {
            LoanManager.finishRequest(context,id,true)
            Log.i("AlKamelLoan","Loan SMS confirmed for $phone")
        } else {
            if(card.isNotBlank()) CardStore.returnCard(context,LoanManager.LOAN_AMOUNT,card,sim)
            LoanManager.finishRequest(context,id,false)
            Log.w("AlKamelLoan","Loan SMS failed for $phone; card returned to stock (result=$resultCode)")
        }
    }
}
