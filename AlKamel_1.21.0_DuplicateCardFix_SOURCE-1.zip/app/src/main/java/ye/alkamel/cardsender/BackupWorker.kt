package ye.alkamel.cardsender
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
class BackupWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val app = applicationContext
        return if (BackupManager.createBackup(app) != null) {
            app.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
                .putString("last_auto_backup", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).commit()
            Result.success()
        } else Result.retry()
    }
}
