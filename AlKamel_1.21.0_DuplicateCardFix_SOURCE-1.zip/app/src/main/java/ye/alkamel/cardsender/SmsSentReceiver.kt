package ye.alkamel.cardsender

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.util.Log

/** Completes a queued sale after Android reports the SMS send status. */
class SmsSentReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_QUEUE_ID = "queue_id"
        const val EXTRA_PART_INDEX = "part_index"
        const val EXTRA_PART_COUNT = "part_count"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val queueId = intent.getStringExtra(EXTRA_QUEUE_ID) ?: return
        val partIndex = intent.getIntExtra(EXTRA_PART_INDEX, 0)
        val partCount = intent.getIntExtra(EXTRA_PART_COUNT, 1)
        if (partCount < 1 || partIndex !in 0 until partCount) {
            val reason = "تعذر التحقق من أجزاء رسالة SMS؛ تحقق من الرسائل قبل إعادة المحاولة"
            PendingQueue.markForReview(app, queueId, reason)
            OperationLog.markQueueReview(app, queueId, reason)
            CardQueueProcessor.process(app)
            return
        }
        if (resultCode != android.app.Activity.RESULT_OK) {
            val reason = when (resultCode) {
                SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "فشل إرسال SMS (خطأ عام)"
                SmsManager.RESULT_ERROR_NO_SERVICE -> "فشل إرسال SMS: لا توجد خدمة شبكة"
                SmsManager.RESULT_ERROR_NULL_PDU -> "فشل إرسال SMS: بيانات الرسالة غير صالحة"
                SmsManager.RESULT_ERROR_RADIO_OFF -> "فشل إرسال SMS: الراديو/الشبكة متوقف"
                else -> "لم يؤكد Android إرسال الرسالة (الرمز $resultCode)"
            }
            // Ambiguous failures stay in PROCESSING for manual review; never auto-send a
            // second card where the carrier may already have accepted the first one.
            PendingQueue.markForReview(app, queueId, reason)
            OperationLog.markQueueReview(app, queueId, reason)
            Log.e("AlKamelCardSender", "SMS callback failed for $queueId: $reason")
            // REVIEW rows are never replayed automatically; allow later independent rows to proceed.
            CardQueueProcessor.process(app)
            return
        }

        if (PendingQueue.pending(app).none { it.id == queueId && it.state == "PROCESSING" }) return
        // Multipart SMS can produce one successful callback per part. Complete only
        // after every part has succeeded; never label a successfully sent multipart
        // message as failed merely because it contains multiple parts.
        val tracker = app.getSharedPreferences("sms_sent_parts", Context.MODE_PRIVATE)
        val key = "parts_$queueId"
        val received = tracker.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (!received.add(partIndex.toString())) return // duplicate callback: idempotent
        if (received.size < partCount) {
            tracker.edit().putStringSet(key, received).commit()
            return
        }
        tracker.edit().remove(key).commit()
        val pending = PendingQueue.pending(app).firstOrNull { it.id == queueId && it.state == "PROCESSING" } ?: return
        val operation = OperationLog.pendingForQueue(app, queueId)
        try {
            if (operation != null && pending.amount > 0 && operation.card.isNotBlank()) {
                CardStore.recordSale(app, pending.amount, pending.phone, operation.card, pending.sim)
                SaleCounter.recordConfirmed(app, pending.phone)
                val gift = RewardManager.recordPurchase(app, pending.phone, pending.amount, pending.sim, pending.subscriptionId)
                if (gift != null && !RewardGiftSender.send(app, gift)) {
                    Log.e("AlKamelCardSender", "Reward gift SMS submission failed; purchase counter remains eligible")
                }
            }
            // Repayment is committed when the incoming transfer is allocated, not
            // when the remaining-card SMS callback arrives. Do not clear a newer loan here.
            SmsDedup.markProcessed(app, pending.fingerprint)
            if (operation != null) OperationLog.finish(app, operation.id, true)
            PendingQueue.remove(app, queueId)
            StockNotification.notifyIfLow(app, pending.amount, CardStore.count(app, pending.amount, pending.sim), pending.sim)
            Log.i("AlKamelCardSender", "SMS send confirmed; queue removed: $queueId")
        } catch (e: Exception) {
            // SMS has already been accepted by Android. Never leave it eligible for replay.
            SmsDedup.markProcessed(app, pending.fingerprint)
            if (operation != null) OperationLog.finish(app, operation.id, true, "تم تأكيد إرسال الرسالة، لكن تعذر إكمال التسجيل: ${e.message ?: "خطأ غير معروف"}")
            PendingQueue.remove(app, queueId)
            Log.e("AlKamelCardSender", "Post-send bookkeeping failed; queue safely removed", e)
        }
        CardQueueProcessor.process(app)
    }
}
