package ye.alkamel.cardsender

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Operation(
    val id: String,
    val time: String,
    val status: String,
    val amount: Int,
    val phone: String,
    val card: String,
    val error: String,
    val queueId: String = "",
    val sim: Int = 1
)

object OperationLog {
    private const val FILE_NAME = "operations.log"
    private fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    @Synchronized
    fun start(context: Context, amount: Int, phone: String, card: String, queueId: String = "", sim: Int = 1): String {
        val id = System.currentTimeMillis().toString() + "-" + System.nanoTime().toString().takeLast(6)
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        append(context, "${id}|${time}|PROCESSING|${amount}|${clean(phone)}|${clean(card)}||${clean(queueId)}|${if (sim == 2) 2 else 1}")
        return id
    }

    @Synchronized
    fun finish(context: Context, id: String, success: Boolean, error: String = "") {
        val rows = read(context).toMutableList()
        val index = rows.indexOfFirst { it.id == id }
        if (index < 0) return
        rows[index] = rows[index].copy(
            status = if (success) "SUCCESS" else "FAILED",
            error = clean(error)
        )
        write(context, rows)
    }

    @Synchronized
    fun review(context: Context, amount: Int, phone: String, reason: String, message: String, sim: Int = 1) {
        val id = "REVIEW-" + System.currentTimeMillis().toString() + "-" + System.nanoTime().toString().takeLast(6)
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        append(context, "${id}|${time}|REVIEW|${amount}|${clean(phone)}||${clean(reason + " | " + message)}||${if (sim == 2) 2 else 1}")
    }

    @Synchronized
    fun recent(context: Context, limit: Int = 300, sim: Int? = null): List<Operation> =
        read(context).asReversed().filter { sim == null || it.sim == (if (sim == 2) 2 else 1) }.take(limit)

    @Synchronized
    fun pending(context: Context, sim: Int? = null): List<Operation> =
        read(context).filter { it.status == "PROCESSING" && (sim == null || it.sim == (if (sim == 2) 2 else 1)) }.asReversed()

    @Synchronized
    fun pendingForQueue(context: Context, queueId: String): Operation? =
        read(context).lastOrNull { it.status == "PROCESSING" && it.queueId == queueId }

    @Synchronized
    fun markQueueReview(context: Context, queueId: String, reason: String) {
        val rows = read(context).toMutableList()
        val index = rows.indexOfLast { it.status == "PROCESSING" && it.queueId == queueId }
        if (index < 0) return
        rows[index] = rows[index].copy(status = "REVIEW", error = clean(reason))
        write(context, rows)
    }

    fun backupFile(context: Context): File = file(context)

    private fun append(context: Context, line: String) {
        val f = file(context)
        f.parentFile?.mkdirs()
        f.appendText(line + "\n")
    }

    private fun read(context: Context): List<Operation> {
        val f = file(context)
        if (!f.exists()) return emptyList()
        val cutoff = System.currentTimeMillis() - 48L * 60L * 60L * 1000L
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val rows = f.readLines().mapNotNull { line ->
            val p = line.split("|", limit = 9)
            if (p.size < 7) null else Operation(
                p[0], p[1], p[2],
                p[3].toIntOrNull() ?: return@mapNotNull null,
                p[4], p[5], p[6], p.getOrNull(7).orEmpty(), p.getOrNull(8)?.toIntOrNull()?.let { if (it == 2) 2 else 1 } ?: 1
            )
        }.filter { row ->
            val parsed = try { formatter.parse(row.time)?.time ?: 0L } catch (_: Exception) { 0L }
            parsed >= cutoff
        }
        if (rows.size != f.readLines().size) write(context, rows)
        return rows
    }

    private fun write(context: Context, rows: List<Operation>) {
        val f = file(context)
        f.writeText(rows.joinToString("\n") {
            "${it.id}|${it.time}|${it.status}|${it.amount}|${clean(it.phone)}|${clean(it.card)}|${clean(it.error)}|${clean(it.queueId)}|${if (it.sim == 2) 2 else 1}"
        } + if (rows.isNotEmpty()) "\n" else "")
    }

    private fun clean(value: String): String =
        value.replace("|", " ").replace("\n", " ").replace("\r", " ")
}
