package ye.alkamel.cardsender

import android.content.Context

object ContactMap {
    private const val PREFS = "alternate_numbers"
    private const val KEY_MAP = "map_"
    private fun simKey(sim: Int, alternate: String) = "map_sim${if (sim == 2) 2 else 1}_" + alternate.trim()

    fun getPhone(context: Context, alternate: String): String? = getPhone(context, alternate, 1)

    fun getPhone(context: Context, alternate: String, sim: Int): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = simKey(sim, alternate)
        val current = prefs.getString(key, null)
        if (!current.isNullOrBlank()) return current
        if (sim != 2) {
            val legacy = prefs.getString(KEY_MAP + alternate.trim(), null)
            if (!legacy.isNullOrBlank()) {
                prefs.edit().putString(key, legacy).remove(KEY_MAP + alternate.trim()).apply()
                return legacy
            }
        }
        return null
    }

    fun setPhone(context: Context, alternate: String, phone: String) = setPhone(context, alternate, phone, 1)

    fun setPhone(context: Context, alternate: String, phone: String, sim: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(simKey(sim, alternate), phone.trim()).remove(KEY_MAP + alternate.trim()).apply()
    }

    fun remove(context: Context, alternate: String) = remove(context, alternate, 1)

    fun remove(context: Context, alternate: String, sim: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(simKey(sim, alternate)).apply()
    }

    fun all(context: Context): Map<String, String> = all(context, 1)

    fun all(context: Context, sim: Int): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (sim != 2) {
            val legacy = prefs.all.filterKeys { it.startsWith(KEY_MAP) && !it.startsWith("map_sim1_") && !it.startsWith("map_sim2_") }
            if (legacy.isNotEmpty()) {
                val editor = prefs.edit()
                legacy.forEach { (key, value) ->
                    val alternate = key.removePrefix(KEY_MAP)
                    val phone = value as? String
                    if (alternate.isNotBlank() && !phone.isNullOrBlank()) editor.putString(simKey(1, alternate), phone)
                    editor.remove(key)
                }
                editor.apply()
            }
        }
        val prefix = "map_sim${if (sim == 2) 2 else 1}_"
        return prefs.all.filterKeys { it.startsWith(prefix) }.mapNotNull { (key, value) ->
            val alternate = key.removePrefix(prefix)
            val phone = value as? String
            if (alternate.isNotBlank() && !phone.isNullOrBlank()) alternate to phone else null
        }.toMap()
    }
}
