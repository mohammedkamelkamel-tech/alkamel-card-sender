package ye.alkamel.cardsender

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object StockNotification {
    private const val CHANNEL_ID = "low_stock"
    private const val PREFS = "stock_alert_settings"
    private const val DEFAULT_THRESHOLD = 20
    private const val MAX_THRESHOLD = 9999

    private fun thresholdKey(amount: Int, sim: Int) = "threshold_sim${if (sim == 2) 2 else 1}_$amount"

    fun getThreshold(context: Context, amount: Int): Int = getThreshold(context, amount, 1)

    fun getThreshold(context: Context, amount: Int, sim: Int): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = thresholdKey(amount, sim)
        if (!prefs.contains(key)) {
            val migrated = if (sim != 2 && prefs.contains("threshold_$amount"))
                prefs.getInt("threshold_$amount", DEFAULT_THRESHOLD) else DEFAULT_THRESHOLD
            prefs.edit().putInt(key, migrated).apply()
        }
        return prefs.getInt(key, DEFAULT_THRESHOLD).coerceIn(0, MAX_THRESHOLD)
    }

    fun setThreshold(context: Context, amount: Int, threshold: Int) = setThreshold(context, amount, threshold, 1)

    fun setThreshold(context: Context, amount: Int, threshold: Int, sim: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(thresholdKey(amount, sim), threshold.coerceIn(0, MAX_THRESHOLD))
            .apply()
    }

    fun notifyIfLow(context: Context, amount: Int, remaining: Int) = notifyIfLow(context, amount, remaining, 1)

    fun notifyIfLow(context: Context, amount: Int, remaining: Int, sim: Int) {
        val threshold = getThreshold(context, amount, sim)
        if (threshold <= 0 || remaining > threshold) return

        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "تنبيهات نقص المخزون", NotificationManager.IMPORTANCE_HIGH
            ))
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("تنبيه نقص المخزون")
            .setContentText("مخزون SIM${if (sim == 2) 2 else 1} - فئة $amount ريال: $remaining كرت فقط")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val notificationId = (System.currentTimeMillis() and 0x7fffffff).toInt()
        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
}
