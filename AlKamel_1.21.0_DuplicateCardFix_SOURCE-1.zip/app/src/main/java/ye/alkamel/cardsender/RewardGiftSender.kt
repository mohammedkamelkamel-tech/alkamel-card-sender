package ye.alkamel.cardsender

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

object RewardGiftSender {
    fun send(context: Context, gift: RewardManager.Gift): Boolean = try {
        val requiredCount = RewardManager.rules(context).firstOrNull { it.id == gift.ruleId }?.requiredCount ?: 10
        val message = "🎁 هدية من شبكة الكامل\nبعد شراء( $requiredCount ) كروت\nرقم الكرت😘${gift.card}"
        val manager = SmsManager.getSmsManagerForSubscriptionId(gift.subscriptionId)
        val parts = manager.divideMessage(message)
        val callbacks = ArrayList<PendingIntent>()
        parts.indices.forEach { index ->
            val intent = Intent(context, RewardGiftSentReceiver::class.java).apply {
                action = "ye.alkamel.cardsender.GIFT_SENT.${gift.id}.$index"
                putExtra("gift_id", gift.id)
                putExtra("part_index", index)
                putExtra("part_count", parts.size)
            }
            callbacks.add(PendingIntent.getBroadcast(context, (gift.id + ":" + index).hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
        if (parts.size == 1) manager.sendTextMessage(gift.phone, null, message, callbacks[0], null)
        else manager.sendMultipartTextMessage(gift.phone, null, ArrayList(parts), callbacks, null)
        true
    } catch (_: Exception) {
        CardStore.returnCard(context, gift.giftAmount, gift.card, gift.sim)
        RewardManager.cancelGiftSubmission(context, gift.id)
        false
    }
}
