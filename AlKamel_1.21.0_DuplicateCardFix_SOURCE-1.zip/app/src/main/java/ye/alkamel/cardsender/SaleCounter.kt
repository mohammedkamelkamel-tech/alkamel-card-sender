package ye.alkamel.cardsender

import android.content.Context
import org.json.JSONObject

/** Fast persistent lifetime counts for confirmed card sales; migrated from sales archive once. */
object SaleCounter {
    private const val PREFS = "confirmed_sale_counts"
    private const val KEY = "counts"
    private const val INIT = "initialized"
    private fun phoneKey(raw: String) = LoanManager.normalizePhone(raw)
    private fun key(phone: String) = phoneKey(phone)

    @Synchronized private fun ensureInitialized(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(INIT, false)) return
        val counts = JSONObject()
        CardStore.sales(context).forEach { sale ->
            val p = phoneKey(sale.phone)
            if (p.length == 9) counts.put(p, counts.optInt(p, 0) + 1)
        }
        prefs.edit().putString(KEY, counts.toString()).putBoolean(INIT, true).commit()
    }

    @Synchronized fun count(context: Context, phone: String): Int {
        ensureInitialized(context)
        val p = key(phone)
        if (p.length != 9) return 0
        val counts = read(context)
        return counts.optInt(p, 0)
    }

    @Synchronized fun all(context: Context): List<Pair<String, Int>> {
        ensureInitialized(context)
        val counts = read(context)
        val keys = counts.keys().asSequence().toList()
        return keys.mapNotNull { p -> if (p.length == 9) p to counts.optInt(p, 0) else null }.sortedByDescending { it.second }
    }

    /** Only called after SMS delivery confirmation; phone initialization is automatic. */
    @Synchronized fun recordConfirmed(context: Context, phone: String) {
        ensureInitialized(context)
        val p = key(phone)
        if (p.length != 9) return
        val counts = read(context)
        counts.put(p, counts.optInt(p, 0) + 1)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, counts.toString()).commit()
    }

    private fun read(context: Context): JSONObject = try {
        JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }
}
