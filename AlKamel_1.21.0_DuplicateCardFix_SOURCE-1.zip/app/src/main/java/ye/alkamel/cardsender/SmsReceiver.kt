package ye.alkamel.cardsender

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.util.Log
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.regex.Pattern

class SmsReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "AlKamelCardSender"
        private val executor = Executors.newSingleThreadExecutor()
        private val phonePattern = Pattern.compile("""(?<!\d)(7\d{8})(?!\d)""")
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED") return
        val pendingResult = goAsync()
        executor.execute {
            try { process(context.applicationContext, intent) }
            catch (e: Exception) { Log.e(TAG, "SMS processing error", e) }
            finally { pendingResult.finish() }
        }
    }

    private fun process(context: Context, intent: Intent) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return
        val bundle: Bundle = intent.extras ?: return

        val sim = SimRouting.simFromIntent(intent) ?: run {
            Log.w(TAG, "Incoming SMS SIM could not be determined; ignored")
            return
        }
        val subscriptionId = SimRouting.subscriptionIdFromIntent(intent) ?: run {
            Log.w(TAG, "Incoming SMS subscriptionId could not be determined; ignored")
            return
        }
        val pdus = bundle.get("pdus") as? Array<*> ?: return
        val format = bundle.getString("format")
        val messages = pdus.mapNotNull {
            try { SmsMessage.createFromPdu(it as ByteArray, format) } catch (_: Exception) { null }
        }
        if (messages.isEmpty()) return

        val originating = messages.firstOrNull()?.originatingAddress?.trim().orEmpty()
        val displayOriginating = messages.firstOrNull()?.displayOriginatingAddress?.trim().orEmpty()
        val rawBody = messages.joinToString("") { it.messageBody ?: "" }.trim()
        if (rawBody.isBlank()) return
        // Normalize Arabic-Indic and Eastern Arabic-Indic numerals before parsing.
        val body = normalizeSmsText(normalizeDigits(rawBody))

        // Customer-initiated loan request. This branch is deliberately handled before
        // wallet sender validation because the SMS originates from the subscriber.
        if (body.equals("سلفني", ignoreCase = true) || body.equals("سلفني ", ignoreCase = true)) {
            handleLoanRequest(context, originating, subscriptionId, sim)
            return
        }

        val senderHint = when {
            isTrustedSender(originating) -> normalizeSender(originating)
            isTrustedSender(displayOriginating) -> normalizeSender(displayOriginating)
            else -> return
        }

        // منع معالجة نفس رسالة SMS مرتين، وهو أهم إجراء لمنع إرسال كرتين بسبب
        // تكرار بث الرسالة من النظام أو إعادة تسليم الـ Intent.
        val smsTimestamp = messages.firstOrNull()?.timestampMillis ?: 0L
        val fingerprint = fingerprint(originating, displayOriginating, smsTimestamp, body, sim)

        val lower = body.lowercase()
        val isJawali = senderHint == "jawali"
        val isJaib = senderHint == "jaib"
        // Automatic dispatch is limited to Jaib and Jawali. Custom sender/format settings
        // remain available in the UI but cannot authorize automatic card delivery.
        if (!isJawali && !isJaib) {
            Log.d(TAG, "Ignoring non-Jaib/Jawali sender: $senderHint")
            return
        }
        val transactionLike = lower.contains("تحويل") || lower.contains("استلمت") ||
            lower.contains("اضيف") || lower.contains("أضيف") || lower.contains("yer") ||
            lower.contains("ريال") || lower.contains("مبلغ") || lower.contains("وصل")
        if (!transactionLike) return

        // Categories are SIM-specific. A denomination configured on SIM2 must not
        // be inferred from SIM1 (or vice versa).
        val categories = CardStore.categories(context, sim)
        val configuredAmounts = categories.sortedDescending().joinToString("|") { Pattern.quote(it.toString()) }
        val amountMatch = if (configuredAmounts.isNotBlank())
            Pattern.compile("""(?<!\d)($configuredAmounts)(?!\d)""").matcher(body)
        else null
        val configuredAmount = amountMatch?.let { if (it.find()) it.group(1)?.toIntOrNull() else null }
        val amount = extractTransferAmount(body) ?: configuredAmount
        if (amount == null || amount <= 0) {
            OperationLog.review(context, 0, "غير محدد", "لم يتضح مبلغ التحويل من الرسالة", body, sim)
            Log.w(TAG, "SMS saved for manual review: amount unclear")
            return
        }

        val phoneMatches = phonePattern.matcher(body)
        val phones = mutableListOf<String>()
        while (phoneMatches.find()) {
            phoneMatches.group(1)?.let { phones.add(it) }
        }

        // Jaib can send a short alternate ID instead of a full phone number; resolve it through the app's mapping.
        val alternate = if (isJaib) findAlternateDestination(context, body, sim) else null
        val destination = if (isJaib) {
            val fullNumber = phones.lastOrNull { it.length >= 9 }
            fullNumber ?: alternate
        } else {
            phones.firstOrNull { it.length >= 9 }
        }

        if (destination.isNullOrBlank()) {
            val reason = if (isJaib) "رقم المستفيد مفقود أو الرقم البديل غير مسجل" else "رقم المستفيد غير واضح"
            OperationLog.review(context, amount, "غير محدد", reason, body, sim)
            Log.w(TAG, "SMS saved for manual review: destination unclear")
            return
        }

        // A low-value transfer for which this SIM has no matching denomination
        // or no card in stock receives one configurable notice per resolved mobile.
        val activeLoan = LoanManager.active(context, destination)
        val expectedDeliveryAmount = if (activeLoan != null && amount >= LoanManager.LOAN_AMOUNT)
            amount - LoanManager.LOAN_AMOUNT else amount
        val stockAvailable = expectedDeliveryAmount == 0 ||
            (categories.contains(expectedDeliveryAmount) && CardStore.count(context, expectedDeliveryAmount, sim) > 0)
        // With an outstanding loan, always queue the transaction: the queue processor
        // must settle the debt first, even when the remaining card denomination is absent.
        if (!stockAvailable && activeLoan == null) {
            if (SmsDedup.wasProcessed(context, fingerprint)) return
            if (amount < 500 && UnavailableCardManager.isEnabled(context)) {
                UnavailableCardManager.sendOnce(context, destination, amount, sim, subscriptionId, amount)
            } else {
                val reason = if (amount >= 500) "لا توجد فئة/كرت مطابق؛ لم يُرسل إشعار لأن المبلغ 500 ريال أو أكثر"
                    else "لا توجد فئة/كرت مطابق، وخدمة إشعار الكروت غير المتوفرة متوقفة"
                OperationLog.review(context, amount, destination, reason, body, sim)
            }
            SmsDedup.markProcessed(context, fingerprint)
            return
        }

        // سجل الرسالة كمُعالجة فقط بعد التأكد أنها رسالة بيع صحيحة
        // وتوفر رقم المشتري والفئة.
        if (wasAlreadyProcessed(context, fingerprint)) {
            Log.w(TAG, "Duplicate SMS ignored: $fingerprint")
            return
        }

        // لا نرسل مباشرة من مستقبل الرسائل.
        // نضع عملية البيع في طابور دائم أولاً، ثم يتولى المعالج إرسالها بالتسلسل.
        // هذا يمنع فقدان الحوالة أثناء وضع الصيانة ويمنع تداخل عمليتي إرسال.
        val queued = PendingQueue.enqueue(
            context,
            fingerprint,
            amount,
            destination,
            sim,
            subscriptionId
        )
        if (!queued) {
            Log.w(TAG, "Duplicate/pending SMS ignored: $fingerprint")
            return
        }

        Log.i(
            TAG,
            "Sale queued: sim=${SimRouting.label(sim)} amount=$amount phone=$destination"
        )
        CardQueueProcessor.process(context)
    }

    private fun handleLoanRequest(context: Context, sender: String, subscriptionId: Int, sim: Int) {
        // Disabling the service blocks only NEW loan issuance. Existing loans are
        // still collected by CardQueueProcessor during normal purchases.
        if (!LoanManager.isServiceEnabled(context)) {
            sendPlainReply(context, sender, subscriptionId, "خدمة سلفني متوقفة حالياً. لا يتم صرف سلف جديدة.")
            return
        }
        val phone = LoanManager.normalizePhone(sender)
        val eligibility = LoanManager.eligibility(context, phone)
        if (!eligibility.eligible) {
            val message = if (eligibility.reason.contains("سلفة"))
                "عذراً، لديك سلفة سابقة لم يتم سدادها. لا يمكن طلب سلفة أخرى قبل السداد."
            else "عذراً، لا يمكنك استخدام خدمة سلفني إلا بعد شراء 10 كروت على الأقل. مشترياتك الحالية: ${eligibility.count}."
            sendPlainReply(context, sender, subscriptionId, message)
            return
        }
        val loanId = LoanManager.createPending(context, phone, sim)
        if (loanId == null) {
            sendPlainReply(context, sender, subscriptionId, "طلبك قيد المعالجة أو لديك سلفة قائمة. لا يمكن تكرار الطلب.")
            return
        }
        val card = CardStore.takeFirstCard(context, LoanManager.LOAN_AMOUNT, sim)
        if (card.isNullOrBlank()) {
            LoanManager.finishRequest(context, loanId, false)
            sendPlainReply(context, sender, subscriptionId, "عذراً، لا يتوفر حالياً كرت سلفة بقيمة 100 ريال. حاول لاحقاً.")
            return
        }
        LoanManager.attachCard(context, loanId, card)
        try {
            val message = "شبكة الكامل - سلفة 100 ريال - رقم الكرت👇\n$card"
            val manager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            val callback = Intent(context, LoanSmsSentReceiver::class.java).apply {
                action = "ye.alkamel.cardsender.LOAN_SENT.$loanId"
                putExtra("loan_id", loanId)
                putExtra("loan_phone", phone)
                putExtra("loan_card", card)
                putExtra("loan_sim", sim)
            }
            val pending = android.app.PendingIntent.getBroadcast(
                context, loanId.hashCode(), callback,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            manager.sendTextMessage(sender, null, message, pending, null)
        } catch (e: Exception) {
            CardStore.returnCard(context, LoanManager.LOAN_AMOUNT, card, sim)
            LoanManager.finishRequest(context, loanId, false)
            sendPlainReply(context, sender, subscriptionId, "تعذر إرسال كرت السلفة حالياً. حاول لاحقاً.")
            Log.e(TAG, "Loan send submission failed", e)
        }
    }

    private fun sendPlainReply(context: Context, phone: String, subscriptionId: Int, message: String) {
        try { SmsManager.getSmsManagerForSubscriptionId(subscriptionId).sendTextMessage(phone, null, message, null, null) }
        catch (e: Exception) { Log.e(TAG, "Unable to send loan reply", e) }
    }

    private fun extractTransferAmount(body: String): Int? {
        val suffix = Pattern.compile("""(?<!\d)(\d{1,7})\s*(?:ريال|ريالات|ر\.?ي)""", Pattern.CASE_INSENSITIVE)
        suffix.matcher(body).let { if (it.find()) return it.group(1)?.toIntOrNull() }
        val afterKeyword = Pattern.compile("""(?:مبلغ|قيمة|تحويل|حول(?:ت)?|استلمت|وصل(?:ني|ك)?)\s*(?:هو|قد|بمبلغ)?\s*[:：-]?\s*(\d{1,7})(?!\d)""")
        afterKeyword.matcher(body).let { if (it.find()) return it.group(1)?.toIntOrNull() }
        return null
    }

    private fun normalizeSmsText(value: String): String {
        return value
            // Arabic hamza/alif variants should not change keyword matching.
            .replace(Regex("[أإآٱ]"), "ا")
            // Providers sometimes insert a hyphen before the beneficiary number.
            .replace(Regex("[-‐‑‒–—−]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeDigits(value: String): String = buildString(value.length) {
        value.forEach { ch ->
            append(when (ch) {
                in '\u0660'..'\u0669' -> ('0'.code + (ch.code - '\u0660'.code)).toChar()
                in '\u06F0'..'\u06F9' -> ('0'.code + (ch.code - '\u06F0'.code)).toChar()
                else -> ch
            })
        }
    }

    private fun fingerprint(originating: String, displayOriginating: String, timestamp: Long, body: String, sim: Int): String {
        val raw = "$originating|$displayOriginating|$timestamp|$body|sim=$sim"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun wasAlreadyProcessed(context: Context, fingerprint: String): Boolean {
        val prefs = context.getSharedPreferences("processed_sms", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val window = 7L * 24L * 60L * 60L * 1000L
        val all = prefs.all
        val editor = prefs.edit()
        all.forEach { (key, value) ->
            val time = value as? Long
            if (time == null || now - time > window) editor.remove(key)
        }
        val previous = prefs.getLong(fingerprint, 0L)
        editor.apply()
        return previous > 0L && now - previous <= window
    }

    private fun markProcessed(context: Context, fingerprint: String) {
        context.getSharedPreferences("processed_sms", Context.MODE_PRIVATE)
            .edit()
            .putLong(fingerprint, System.currentTimeMillis())
            .apply()
    }

    private fun normalizeSender(sender: String): String {
        return sender.trim().lowercase().replace(" ", "").replace("-", "")
    }

    private fun isTrustedSender(sender: String): Boolean {
        return normalizeSender(sender) == "jaib" || normalizeSender(sender) == "jawali"
    }

    private fun findAlternateDestination(context: Context, body: String, sim: Int): String? {
        val fromIndex = body.lastIndexOf("من")
        if (fromIndex < 0) return null

        val tail = body.substring(fromIndex + 2)
        val numberPattern = Pattern.compile("""(?<!\d)(\d{4,12})(?!\d)""")
        val matcher = numberPattern.matcher(tail)
        var alternate: String? = null
        while (matcher.find()) alternate = matcher.group(1)

        if (alternate.isNullOrBlank()) return null
        val phone = ContactMap.getPhone(context, alternate, sim)
        Log.d(TAG, "Jaib alternate destination: " + alternate + " -> " + (phone ?: "NOT_MAPPED"))
        return phone
    }

    private data class SendResult(val success: Boolean, val error: String = "")

    private fun sendSms(context: Context, phone: String, card: String, amount: Int, subscriptionId: Int): SendResult {
        return try {
            val prefs = context.getSharedPreferences("message_settings", Context.MODE_PRIVATE)
            val savedTemplate = prefs.getString(
                "template",
                "شبكة الكامل - كرت {السعر} ريال - رقم الكرت👇\n"
            ).orEmpty()

            // Convert a user-entered literal "\\n" into a real line break.
            // This prevents the SMS from displaying the characters "\\n".
            val template = savedTemplate
                .replace("\\r\\n", "\n")
                .replace("\\n", "\n")
                .replace("{السعر}", amount.toString())
                .take(44)

            val availableForTemplate = (54 - card.length).coerceAtLeast(0)
            val safeTemplate = template.take(availableForTemplate)
            val message = safeTemplate + card

            val smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            val parts = smsManager.divideMessage(message)
            if (parts.size == 1) smsManager.sendTextMessage(phone, null, message, null, null)
            else smsManager.sendMultipartTextMessage(phone, null, ArrayList(parts), null, null)
            SendResult(true)
        } catch (e: Exception) {
            Log.e(TAG, "SMS send failed", e)
            SendResult(false, e.message ?: "تعذر إرسال الرسالة")
        }
    }
}

// ALKAMEL_SMS_REVIEW_V1
