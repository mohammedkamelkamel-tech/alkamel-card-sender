package ye.alkamel.cardsender

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class UnavailableNoticeSentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("notice_id") ?: return
        val index = intent.getIntExtra("part_index", 0)
        val count = intent.getIntExtra("part_count", 1)
        if (resultCode != Activity.RESULT_OK || count < 1 || index !in 0 until count) {
            UnavailableCardManager.finish(context, id, false)
            return
        }
        val prefs = context.getSharedPreferences("unavailable_sms_parts", Context.MODE_PRIVATE)
        val key = "parts_$id"
        val received = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        received.add(index.toString())
        if (received.size >= count) {
            prefs.edit().remove(key).commit()
            UnavailableCardManager.finish(context, id, true)
        } else prefs.edit().putStringSet(key, received).commit()
    }
}
