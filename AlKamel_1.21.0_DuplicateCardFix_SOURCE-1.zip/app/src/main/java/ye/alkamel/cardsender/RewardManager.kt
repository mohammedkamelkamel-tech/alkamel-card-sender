package ye.alkamel.cardsender

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Purchase-count rewards. Counts advance only after a normal sale SMS is confirmed. */
object RewardManager {
    private const val PREFS = "collect_win_service"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_RULES = "rules"
    private const val KEY_COUNTS = "counts"
    private const val KEY_PENDING = "pending_gifts"
    private const val KEY_HISTORY = "gift_history"
    private const val KEY_LAST_ROUTE = "last_route"

    data class Rule(val id: String, val purchaseAmount: Int, val requiredCount: Int, val giftAmount: Int, val enabled: Boolean = true)
    data class Gift(val id: String, val phone: String, val purchaseAmount: Int, val giftAmount: Int, val card: String, val sim: Int, val subscriptionId: Int, val ruleId: String)
    data class History(val phone: String, val purchaseAmount: Int, val giftAmount: Int, val card: String, val sim: Int, val time: String)

    fun isEnabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, value: Boolean) { prefs(context).edit().putBoolean(KEY_ENABLED, value).commit() }

    fun rules(context: Context): List<Rule> {
        val a = try { JSONArray(prefs(context).getString(KEY_RULES, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            Rule(o.optString("id"), o.optInt("purchase"), o.optInt("required"), o.optInt("gift"), o.optBoolean("enabled", true))
        }
    }

    @Synchronized fun saveRule(context: Context, purchaseAmount: Int, requiredCount: Int, giftAmount: Int): Boolean {
        if (purchaseAmount <= 0 || requiredCount <= 0 || giftAmount <= 0) return false
        val rows = rules(context).filterNot { it.purchaseAmount == purchaseAmount }.toMutableList()
        rows.add(Rule("R-$purchaseAmount", purchaseAmount, requiredCount, giftAmount, true))
        val a = JSONArray(); rows.sortedBy { it.purchaseAmount }.forEach { a.put(JSONObject().put("id", it.id).put("purchase", it.purchaseAmount).put("required", it.requiredCount).put("gift", it.giftAmount).put("enabled", it.enabled)) }
        return prefs(context).edit().putString(KEY_RULES, a.toString()).commit()
    }

    @Synchronized fun deleteRule(context: Context, id: String) {
        val a = JSONArray(); rules(context).filterNot { it.id == id }.forEach { a.put(JSONObject().put("id", it.id).put("purchase", it.purchaseAmount).put("required", it.requiredCount).put("gift", it.giftAmount).put("enabled", it.enabled)) }
        prefs(context).edit().putString(KEY_RULES, a.toString()).commit()
    }

    fun count(context: Context, phoneRaw: String, purchaseAmount: Int): Int {
        val key = countKey(phoneRaw, purchaseAmount)
        val o = try { JSONObject(prefs(context).getString(KEY_COUNTS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        return o.optInt(key, 0)
    }

    /** Called once from the successful sale callback; reserves and returns any eligible gift. */
    @Synchronized fun recordPurchase(context: Context, phoneRaw: String, purchaseAmount: Int, sim: Int, subscriptionId: Int): Gift? {
        if (!isEnabled(context)) return null
        val phone = LoanManager.normalizePhone(phoneRaw)
        if (phone.length != 9) return null
        val rule = rules(context).firstOrNull { it.enabled && it.purchaseAmount == purchaseAmount } ?: return null
        val counts = readCounts(context)
        val key = countKey(phone, purchaseAmount)
        val next = (counts.optInt(key, 0) + 1)
        counts.put(key, next)
        writeCounts(context, counts)
        val routes = try { JSONObject(prefs(context).getString(KEY_LAST_ROUTE, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        routes.put(key, JSONObject().put("sim", if (sim == 2) 2 else 1).put("sub", subscriptionId))
        prefs(context).edit().putString(KEY_LAST_ROUTE, routes.toString()).commit()
        if (next < rule.requiredCount) return null
        val pending = readPending(context)
        if (pending.values.any { it.phone == phone && it.ruleId == rule.id }) return null
        // Gift stock is taken from the same SIM that delivered the qualifying purchase.
        val card = CardStore.takeFirstCard(context, rule.giftAmount, sim) ?: return null
        val id = "GW-${System.currentTimeMillis()}-${System.nanoTime().toString().takeLast(5)}"
        val gift = Gift(id, phone, purchaseAmount, rule.giftAmount, card, if (sim == 2) 2 else 1, subscriptionId, rule.id)
        pending[id] = gift
        writePending(context, pending)
        return gift
    }

    /** Retry only threshold-reached customers after stock is replenished; never duplicates a pending gift. */
    @Synchronized fun processEligible(context: Context): List<Gift> {
        if (!isEnabled(context)) return emptyList()
        val counts = readCounts(context)
        val routes = try { JSONObject(prefs(context).getString(KEY_LAST_ROUTE, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val pending = readPending(context)
        val created = mutableListOf<Gift>()
        val countKeys = counts.keys().asSequence().toList()
        for (rule in rules(context).filter { it.enabled }) {
            val suffix = "_${rule.purchaseAmount}"
            val keys = countKeys.filter { it.endsWith(suffix) }
            for (key in keys) {
                val phone = key.removeSuffix(suffix)
                if (counts.optInt(key, 0) < rule.requiredCount || pending.values.any { it.phone == phone && it.ruleId == rule.id }) continue
                val route = routes.optJSONObject(key) ?: continue
                val sim = route.optInt("sim", 1)
                val sub = route.optInt("sub", -1)
                if (sub < 0) continue
                val card = CardStore.takeFirstCard(context, rule.giftAmount, sim) ?: continue
                val id = "GW-${System.currentTimeMillis()}-${System.nanoTime().toString().takeLast(5)}"
                val gift = Gift(id, phone, rule.purchaseAmount, rule.giftAmount, card, sim, sub, rule.id)
                pending[id] = gift
                created.add(gift)
            }
        }
        if (created.isNotEmpty()) writePending(context, pending)
        return created
    }

    @Synchronized fun cancelGiftSubmission(context: Context, id: String) {
        val pending = readPending(context)
        val gift = pending.remove(id) ?: return
        writePending(context, pending)
        CardStore.returnCard(context, gift.giftAmount, gift.card, gift.sim)
    }

    @Synchronized fun finishGift(context: Context, id: String, success: Boolean) {
        val pending = readPending(context)
        val gift = pending.remove(id) ?: return
        if (success) {
            val counts = readCounts(context)
            counts.put(countKey(gift.phone, gift.purchaseAmount), 0)
            writeCounts(context, counts)
            val history = JSONArray(prefs(context).getString(KEY_HISTORY, "[]") ?: "[]")
            history.put(JSONObject().put("phone", gift.phone).put("purchase", gift.purchaseAmount).put("gift", gift.giftAmount)
                .put("card", gift.card).put("sim", gift.sim).put("time", now()))
            prefs(context).edit().putString(KEY_HISTORY, history.toString()).commit()
        } else {
            // Ambiguous carrier result: keep the card reserved and mark REVIEW; never auto-send twice.
            pending[id] = gift
        }
        writePending(context, pending)
    }

    fun history(context: Context): List<History> {
        val a = try { JSONArray(prefs(context).getString(KEY_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            History(o.optString("phone"), o.optInt("purchase"), o.optInt("gift"), o.optString("card"), o.optInt("sim", 1), o.optString("time"))
        }.reversed()
    }

    fun pending(context: Context): List<Gift> = readPending(context).values.toList()

    /** Deletes only displayed gift-history rows for selected phone numbers. Counters and pending gifts stay intact. */
    @Synchronized fun deleteHistoryPhones(context: Context, phones: Set<String>): Int {
        val selected = phones.map { LoanManager.normalizePhone(it) }.toSet()
        val old = try { JSONArray(prefs(context).getString(KEY_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val kept = JSONArray(); var removed = 0
        for (i in 0 until old.length()) {
            val row = old.optJSONObject(i) ?: continue
            if (LoanManager.normalizePhone(row.optString("phone")) in selected) removed++ else kept.put(row)
        }
        if (removed > 0) prefs(context).edit().putString(KEY_HISTORY, kept.toString()).commit()
        return removed
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun countKey(phone: String, amount: Int) = "${LoanManager.normalizePhone(phone)}_$amount"
    private fun readCounts(context: Context) = try { JSONObject(prefs(context).getString(KEY_COUNTS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun writeCounts(context: Context, o: JSONObject) { prefs(context).edit().putString(KEY_COUNTS, o.toString()).commit() }
    private fun readPending(context: Context): MutableMap<String, Gift> {
        val a = try { JSONArray(prefs(context).getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val result = linkedMapOf<String, Gift>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isNotBlank()) result[id] = Gift(id, o.optString("phone"), o.optInt("purchase"), o.optInt("gift"), o.optString("card"), o.optInt("sim", 1), o.optInt("sub"), o.optString("rule"))
        }
        return result
    }
    private fun writePending(context: Context, values: Map<String, Gift>) {
        val a = JSONArray()
        values.values.forEach { a.put(JSONObject().put("id", it.id).put("phone", it.phone).put("purchase", it.purchaseAmount).put("gift", it.giftAmount).put("card", it.card).put("sim", it.sim).put("sub", it.subscriptionId).put("rule", it.ruleId)) }
        prefs(context).edit().putString(KEY_PENDING, a.toString()).commit()
    }
    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
}
