package ye.alkamel.cardsender

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

data class LoanRecord(val id:String, val phone:String, val card:String, val sim:Int, val time:String, val status:String, val settlementQueueId:String="")

data class LoanEligibility(val eligible:Boolean, val count:Int, val reason:String)

/** Persistent, idempotent loan ledger. A loan becomes ACTIVE only after Android confirms SMS delivery. */
object LoanManager {
    const val LOAN_AMOUNT = 100
    const val REQUIRED_PURCHASES = 10
    private val lock = ReentrantLock()
    private const val PREFS_NAME = "salfni_service_settings"
    private const val KEY_SERVICE_ENABLED = "service_enabled"

    /** New-loan issuance can be paused independently from repayment collection. */
    fun isServiceEnabled(context: Context): Boolean = context
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        .getBoolean(KEY_SERVICE_ENABLED, true)

    fun setServiceEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    }

    private fun file(context:Context) = File(context.filesDir, "loans_v121.csv")
    private fun clean(value:String) = value.replace("|", " ").replace("\n", " ").replace("\r", " ")
    fun normalizePhone(raw:String):String {
        val digits = raw.filter { it.isDigit() }
        val local = if (digits.startsWith("967") && digits.length >= 12) digits.takeLast(9) else digits.takeLast(9)
        return local
    }
    private fun read(context:Context):List<LoanRecord> {
        val f=file(context); if(!f.exists()) return emptyList()
        return f.readLines().mapNotNull { line ->
            val p=line.split("|", limit=7); if(p.size<6) null else LoanRecord(p[0],p[1],p[2],p[3].toIntOrNull()?:1,p[4],p[5],p.getOrNull(6).orEmpty())
        }
    }
    private fun write(context:Context, rows:List<LoanRecord>) {
        val f=file(context); f.parentFile?.mkdirs(); val tmp=File(f.parentFile,"${f.name}.tmp")
        tmp.writeText(rows.joinToString("\n") { listOf(it.id,it.phone,it.card,it.sim,it.time,it.status,it.settlementQueueId).joinToString("|") } + if(rows.isNotEmpty()) "\n" else "")
        if(!tmp.renameTo(f)) { f.writeText(tmp.readText()); tmp.delete() }
    }
    fun records(context:Context):List<LoanRecord> = lock.withLock { read(context).sortedByDescending { it.time } }
    fun active(context:Context, phone:String):LoanRecord? = lock.withLock {
        val normalized=normalizePhone(phone); read(context).lastOrNull { it.phone==normalized && it.status in listOf("ACTIVE","SETTLING") }
    }
    fun hasPending(context:Context, phone:String):Boolean = lock.withLock {
        val normalized=normalizePhone(phone); read(context).any { it.phone==normalized && it.status=="PENDING" }
    }
    fun eligibility(context:Context, phone:String):LoanEligibility {
        val normalized=normalizePhone(phone)
        if(normalized.length!=9 || !normalized.startsWith("7")) return LoanEligibility(false,0,"رقم الجوال غير صالح")
        val rows=lock.withLock { read(context).filter { it.phone==normalized } }
        // Eligibility is lifetime successful purchases: repayment must not reset the
        // customer's qualification counter or require another batch of ten cards.
        val count=SaleCounter.count(context, normalized)
        val existing=rows.lastOrNull { it.status in listOf("ACTIVE","SETTLING","PENDING") }
        return when {
            existing?.status=="ACTIVE" || existing?.status=="SETTLING" -> LoanEligibility(false,count,"عليك سلفة سابقة لم تُسدد")
            existing?.status=="PENDING" -> LoanEligibility(false,count,"طلب السلفة قيد المعالجة")
            count<REQUIRED_PURCHASES -> LoanEligibility(false,count,"يجب شراء 10 كروت على الأقل")
            else -> LoanEligibility(true,count,"")
        }
    }
    fun createPending(context:Context, phone:String, sim:Int):String? = lock.withLock {
        // Re-check inside the ledger operation to close the race with a UI toggle.
        if (!isServiceEnabled(context)) return null
        val normalized=normalizePhone(phone)
        val rows=read(context)
        // Keep the ten-purchase qualification after repayment; count all confirmed sales.
        val count=SaleCounter.count(context, normalized)
        if(normalized.length!=9 || count<REQUIRED_PURCHASES) return null
        if(rows.any { it.phone==normalized && it.status in listOf("ACTIVE","SETTLING","PENDING") }) return null
        val id="LN-${System.currentTimeMillis()}-${System.nanoTime().toString().takeLast(5)}"
        val time=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
        write(context,rows+LoanRecord(id,normalized,"",if(sim==2)2 else 1,time,"PENDING")); id
    }
    fun attachCard(context:Context,id:String,card:String):Boolean = lock.withLock {
        val rows=read(context); if(rows.none { it.id==id && it.status=="PENDING" }) return false
        write(context,rows.map { if(it.id==id) it.copy(card=clean(card)) else it }); true
    }
    fun isPendingRequest(context:Context,id:String):Boolean = lock.withLock { read(context).any { it.id==id && it.status=="PENDING" } }
    fun finishRequest(context:Context,id:String,success:Boolean) = lock.withLock {
        val rows=read(context); write(context,rows.map { if(it.id==id && it.status=="PENDING") it.copy(status=if(success)"ACTIVE" else "FAILED") else it })
    }
    fun reserveSettlement(context:Context,phone:String,queueId:String):Boolean = lock.withLock {
        val normalized=normalizePhone(phone); val rows=read(context)
        if(rows.none { it.phone==normalized && it.status=="ACTIVE" }) return false
        write(context,rows.map { if(it.phone==normalized && it.status=="ACTIVE") it.copy(status="SETTLING",card="SETTLE:$queueId") else it }); true
    }
    /** Finalize repayment for one queue transaction. Repeated calls are idempotent. */
    fun markPaidForQueue(context:Context,phone:String,queueId:String):Boolean = lock.withLock {
        val normalized=normalizePhone(phone)
        val rows=read(context)
        // If this queue already settled an older loan, never let a delayed retry
        // accidentally settle a newer loan for the same phone.
        if(rows.any { it.phone==normalized && it.status=="PAID" && it.settlementQueueId==queueId }) return true
        val matching=rows.lastOrNull { it.phone==normalized && it.status in listOf("ACTIVE","SETTLING") }
        if(matching==null) return false
        val paidAt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
        write(context,rows.map { if(it.id==matching.id) it.copy(status="PAID",time=paidAt,settlementQueueId=queueId) else it })
        true
    }

    fun markPaid(context:Context,phone:String):Boolean = lock.withLock {
        val normalized=normalizePhone(phone); val rows=read(context)
        if(rows.none { it.phone==normalized && it.status in listOf("ACTIVE","SETTLING") }) return false
        val paidAt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
        write(context,rows.map { if(it.phone==normalized && it.status in listOf("ACTIVE","SETTLING")) it.copy(status="PAID",time=paidAt) else it }); true
    }
    fun activeLoans(context:Context):List<LoanRecord> = records(context).filter { it.status in listOf("ACTIVE","SETTLING") }
    fun customerCounts(context:Context):List<Pair<String,Int>> = SaleCounter.all(context)

    /** Removes only closed historical loan records; active, settling and pending loans are never touched. */
    fun deleteClosedHistoryPhones(context:Context, phones:Set<String>):Int = lock.withLock {
        val normalized=phones.map { normalizePhone(it) }.toSet()
        val rows=read(context)
        val filtered=rows.filterNot { it.phone in normalized && it.status in listOf("PAID","FAILED") }
        val removed=rows.size-filtered.size
        if(removed>0) write(context,filtered)
        removed
    }
}
