package ye.alkamel.cardsender

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

object CardQueueProcessor {
    private val executor=Executors.newSingleThreadExecutor()
    fun process(context:Context){val appContext=context.applicationContext;executor.execute{processNow(appContext)}}
    private fun processNow(context:Context){
        if(ContextCompat.checkSelfPermission(context,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)return
        while(true){
            val servicesEnabled=ServiceControl.isEnabled(context)
            val pending=PendingQueue.nextForProcessing(context,servicesEnabled)?:return
            if(SmsDedup.wasProcessed(context,pending.fingerprint)){PendingQueue.remove(context,pending.id);continue}
            // Persist the in-flight state before touching inventory or sending SMS.
            // If Android kills the process, this transaction will require manual review
            // instead of silently consuming a second card on the next launch.
            if(!PendingQueue.markProcessing(context,pending.id)) return
            var deliveryAmount = pending.amount
            var card: String? = null
            var suffix = ""
            var repaymentApplied = pending.loanSettled

            if (pending.loanSettled) {
                suffix = "\nتم خصم مبلغ السلفة 100 ريال من حوالتك. شكراً لاستخدامك شبكة الكامل."
                // A previous attempt already deducted the loan. Reconcile the ledger
                // before retrying the remaining card; never deduct the 100 again.
                if (!LoanManager.markPaidForQueue(context,pending.phone,pending.id)) {
                    val reason = "تم تسجيل خصم السلفة في الحوالة لكن تعذر تحديث سجل السداد؛ تمت إحالة العملية للمراجعة"
                    PendingQueue.markForReview(context,pending.id,reason)
                    OperationLog.markQueueReview(context,pending.id,reason)
                    continue
                }
            } else {
                val activeLoan = LoanManager.active(context,pending.phone)
                if (activeLoan != null) {
                    if (activeLoan.status == "SETTLING") {
                        // Migrate a settlement started by the previous version: it had
                        // already reduced the queue amount before reserving the loan.
                        if (activeLoan.card == "SETTLE:${pending.id}" &&
                            PendingQueue.markLegacyLoanSettlementApplied(context,pending.id) &&
                            LoanManager.markPaidForQueue(context,pending.phone,pending.id)) {
                            repaymentApplied = true
                            deliveryAmount = pending.amount
                            suffix = "\nتم خصم مبلغ السلفة 100 ريال من حوالتك. شكراً لاستخدامك شبكة الكامل."
                        } else {
                            val reason = "توجد عملية سداد سلفة قديمة لا تطابق هذه الحوالة؛ تمت إحالة العملية للمراجعة لمنع الخصم المكرر"
                            PendingQueue.markForReview(context,pending.id,reason)
                            OperationLog.markQueueReview(context,pending.id,reason)
                            continue
                        }
                    } else {
                        if (pending.amount < LoanManager.LOAN_AMOUNT) {
                            val reason = "قيمة التحويل أقل من مبلغ السلفة؛ لم يتم إرسال كرت أو إسقاط الدين"
                            PendingQueue.markForReview(context,pending.id,reason)
                            OperationLog.markQueueReview(context,pending.id,reason)
                            continue
                        }
                        deliveryAmount = pending.amount - LoanManager.LOAN_AMOUNT
                        // Save the net amount + settled marker atomically in the queue first.
                        // A retry will therefore resume at the net amount and cannot deduct twice.
                        if (!PendingQueue.applyLoanSettlement(context,pending.id,deliveryAmount)) {
                            val reason = "تعذر حفظ خصم السلفة بشكل آمن؛ تمت إحالة الحوالة للمراجعة"
                            PendingQueue.markForReview(context,pending.id,reason)
                            OperationLog.markQueueReview(context,pending.id,reason)
                            continue
                        }
                        repaymentApplied = true
                        suffix = "\nتم خصم مبلغ السلفة 100 ريال من حوالتك. شكراً لاستخدامك شبكة الكامل."
                        if (!LoanManager.markPaidForQueue(context,pending.phone,pending.id)) {
                            val reason = "تم حفظ خصم السلفة لكن تعذر تثبيت السداد في السجل؛ تمت إحالة العملية للمراجعة"
                            PendingQueue.markForReview(context,pending.id,reason)
                            OperationLog.markQueueReview(context,pending.id,reason)
                            continue
                        }
                    }
                }
            }

            if (deliveryAmount > 0) {
                card = CardStore.takeFirstCard(context,deliveryAmount,pending.sim)
                if (card == null) {
                    if (pending.originalAmount < 500 && UnavailableCardManager.isEnabled(context)) {
                        UnavailableCardManager.sendOnce(context, pending.phone, deliveryAmount, pending.sim, pending.subscriptionId, pending.originalAmount)
                    }
                    val reason = if (repaymentApplied)
                        "تم خصم السلفة 100 ريال وتسجيل سدادها، لكن لا يوجد كرت متوفر لفئة $deliveryAmount ريال في مخزون الشريحة ${pending.sim}"
                    else "لا يوجد كرت متوفر في مخزون فئة $deliveryAmount ريال"
                    PendingQueue.markForReview(context,pending.id,reason)
                    OperationLog.markQueueReview(context,pending.id,reason)
                    continue
                }
            }
            val operationId=OperationLog.start(context,deliveryAmount,pending.phone,card.orEmpty(),pending.id,pending.sim)
            val result = if (deliveryAmount == 0 && repaymentApplied) {
                CardSmsSender.sendNotice(context,pending.phone,"تم خصم السلفة التي عليك 100 ريال. شكراً لاستخدامك شبكة الكامل.",pending.subscriptionId,pending.id)
            } else {
                CardSmsSender.send(context,pending.phone,card.orEmpty(),deliveryAmount,pending.subscriptionId,pending.id,suffix)
            }
            if(result.success){
                // SmsManager returning normally only means the request was accepted.
                // Keep the transaction PROCESSING until Android's sent callback arrives.
                // If callback/process state is lost, this row blocks automatic replay.
                android.util.Log.i("AlKamelCardSender", "SMS submitted; awaiting send callback for queue ${pending.id}; continuing with next queue item")
                continue
            }else{
                // Treat submission exceptions as ambiguous: do not return/reissue a card
                // automatically because Android/telephony may have accepted the request.
                val reason="تعذر حسم نتيجة طلب SMS: ${result.error}"
                PendingQueue.markForReview(context,pending.id,reason)
                OperationLog.markQueueReview(context,pending.id,reason)
                continue
            }
        }
    }
}
