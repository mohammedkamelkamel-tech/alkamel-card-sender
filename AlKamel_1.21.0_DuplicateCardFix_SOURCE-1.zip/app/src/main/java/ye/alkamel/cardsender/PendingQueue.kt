package ye.alkamel.cardsender

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

data class PendingSale(val id:String,val time:String,val fingerprint:String,val amount:Int,val phone:String,val sim:Int,val subscriptionId:Int,val error:String="",val allowed:Boolean=false,val state:String="QUEUED",val loanSettled:Boolean=false,val originalAmount:Int=amount)

object PendingQueue {
    private const val FILE_NAME="pending_sales.queue"
    private val lock=ReentrantLock()
    private fun file(context:Context)=File(context.filesDir,FILE_NAME)
    fun enqueue(context:Context,fingerprint:String,amount:Int,phone:String,sim:Int,subscriptionId:Int):Boolean=lock.withLock{
        val rows=read(context); if(rows.any{it.fingerprint==fingerprint}) return false
        val id=System.currentTimeMillis().toString()+"-"+System.nanoTime().toString().takeLast(6)
        val time=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
        append(context,PendingSale(id,time,fingerprint,amount,phone.filterNot{it=='|'},sim,subscriptionId)); true
    }
    fun peek(context:Context):PendingSale?=lock.withLock{read(context).firstOrNull()}
    fun remove(context:Context,id:String)=lock.withLock{write(context,read(context).filterNot{it.id==id})}
    fun allow(context:Context,id:String)=lock.withLock{write(context,read(context).map{if(it.id==id)it.copy(allowed=true)else it})}
    private const val IN_FLIGHT_TIMEOUT_MS = 120_000L

    fun nextForProcessing(context:Context,servicesEnabled:Boolean):PendingSale?=lock.withLock{
        var rows=read(context)
        // A recent PROCESSING row may still be awaiting Android's SMS callback, so wait.
        // An old one is moved to REVIEW (never auto-retried) so it cannot freeze the whole queue.
        val now=System.currentTimeMillis()
        val expiredIds = mutableListOf<String>()
        rows=rows.map { row ->
            // time is reset when processing starts, so queue waiting time cannot expire an SMS.
            if(row.state=="PROCESSING" && now-parseTime(row.time)>IN_FLIGHT_TIMEOUT_MS) {
                expiredIds.add(row.id)
                row.copy(state="REVIEW",error=if(row.error.isBlank()) "انتهت مهلة تأكيد الإرسال؛ تحقق من الرسائل قبل إعادة المحاولة" else row.error)
            } else row
        }
        if(expiredIds.isNotEmpty()) {
            write(context,rows)
            expiredIds.forEach { OperationLog.markQueueReview(context,it,"انتهت مهلة تأكيد الإرسال؛ تحقق من سجل الرسائل قبل إعادة المحاولة") }
        }
        // PROCESSING rows are isolated transactions, not a global queue lock.
        // Select the next independent queued item even while another SMS awaits callback.
        if(servicesEnabled) rows.firstOrNull{it.state=="QUEUED"||it.state=="RETRYABLE"}
        else rows.firstOrNull{it.allowed&&(it.state=="QUEUED"||it.state=="RETRYABLE")}
    }

    private fun parseTime(value:String):Long = try {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).parse(value)?.time ?: 0L
    } catch (_:Exception) { 0L }

    fun markForReview(context:Context,id:String,error:String):Boolean=lock.withLock{
        val rows=read(context)
        if(rows.none{it.id==id}) return false
        val clean=error.replace("|"," ").replace("\n"," ").replace("\r"," ")
        write(context,rows.map{if(it.id==id)it.copy(state="REVIEW",error=clean)else it})
        true
    }
    fun markProcessing(context:Context,id:String):Boolean=lock.withLock{
        val rows=read(context)
        val target=rows.firstOrNull{it.id==id}?:return false
        if(target.state=="PROCESSING") return false
        val startedAt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date())
        write(context,rows.map{if(it.id==id)it.copy(time=startedAt,state="PROCESSING",error="")else it})
        true
    }
    fun markRetryable(context:Context,id:String,error:String=""):Boolean=lock.withLock{
        val rows=read(context)
        if(rows.none{it.id==id}) return false
        val clean=error.replace("|"," ").replace("\\n"," ").replace("\\r"," ")
        write(context,rows.map{if(it.id==id)it.copy(state="RETRYABLE",error=clean)else it})
        true
    }
    fun retryAfterReview(context:Context,id:String):Boolean=lock.withLock{
        val rows=read(context)
        val target=rows.firstOrNull{it.id==id}?:return false
        if(target.state!="PROCESSING" && target.state!="REVIEW") return false
        write(context,rows.map{if(it.id==id)it.copy(state="RETRYABLE",error="أعيدت للمحاولة يدويًا بعد مراجعة المشغّل.",allowed=true)else it})
        true
    }
    fun updateAmount(context:Context,id:String,amount:Int):Boolean=lock.withLock{
        if(amount<0) return false
        val rows=read(context)
        if(rows.none{it.id==id}) return false
        write(context,rows.map{if(it.id==id)it.copy(amount=amount)else it})
        true
    }
    /** Persist the net amount and repayment marker together before any SMS retry. */
    fun applyLoanSettlement(context:Context,id:String,netAmount:Int):Boolean=lock.withLock{
        if(netAmount<0) return false
        val rows=read(context)
        val target=rows.firstOrNull{it.id==id}?:return false
        if(target.loanSettled) return target.amount==netAmount
        write(context,rows.map{if(it.id==id)it.copy(amount=netAmount,loanSettled=true)else it})
        true
    }
    /** Mark a legacy queue row whose net amount was already saved by the previous app version. */
    fun markLegacyLoanSettlementApplied(context:Context,id:String):Boolean=lock.withLock{
        val rows=read(context)
        val target=rows.firstOrNull{it.id==id}?:return false
        if(target.loanSettled) return true
        write(context,rows.map{if(it.id==id)it.copy(loanSettled=true)else it})
        true
    }
    fun setError(context:Context,id:String,error:String)=lock.withLock{
        val clean=error.replace("|"," ").replace("\n"," ").replace("\r"," ")
        write(context,read(context).map{if(it.id==id)it.copy(error=clean)else it})
    }
    fun pending(context:Context): List<PendingSale> =lock.withLock{read(context)}
    private fun append(context:Context,row:PendingSale){val f=file(context);f.parentFile?.mkdirs();f.appendText(serialize(row)+"\n")}
    private fun read(context:Context):List<PendingSale>{
        val f=file(context);if(!f.exists())return emptyList()
        return f.readLines().mapNotNull{line->
            val p=line.split("|",limit=12);if(p.size<8)null else PendingSale(p[0],p[1],p[2],p[3].toIntOrNull()?:return@mapNotNull null,p[4],p[5].toIntOrNull()?:1,p[6].toIntOrNull()?:return@mapNotNull null,p[7],p.getOrNull(8)?.toBoolean()?:false,p.getOrNull(9)?: "QUEUED",p.getOrNull(10)?.toBoolean()?:false,p.getOrNull(11)?.toIntOrNull()?: (p[3].toIntOrNull() ?: 0))
        }
    }
    private fun write(context:Context,rows:List<PendingSale>){
        val f=file(context)
        f.parentFile?.mkdirs()
        if(rows.isEmpty()){
            if(f.exists()) f.writeText("")
            return
        }
        // كتابة ذرية: نكتب ملفًا مؤقتًا ثم نستبدل الملف القديم، حتى لا تتلف قائمة
        // الحوالات إذا توقف التطبيق أو انقطع الهاتف أثناء الحفظ.
        val temp=File(f.parentFile, f.name+".tmp")
        temp.writeText(rows.joinToString("\n"){serialize(it)}+"\n")
        if(!temp.renameTo(f)){
            f.writeText(rows.joinToString("\n"){serialize(it)}+"\n")
            temp.delete()
        }
    }
    private fun serialize(row:PendingSale)=listOf(row.id,row.time,row.fingerprint,row.amount,row.phone,row.sim,row.subscriptionId,row.error,row.allowed,row.state,row.loanSettled,row.originalAmount).joinToString("|")
}
