# Duplicate card allocation fix (v1.21.0 source patch)

## Changes in CardStore.kt
- Added a durable SharedPreferences allocation ledger (`card_allocations_ledger`).
- `takeFirstCard` skips numbers previously allocated or sold across both SIMs and reserves the selected card in the ledger before returning it to the SMS sender.
- `returnCard` refuses to automatically return a card already allocated or sold (fail-closed behavior for uncertain SMS outcomes).
- `recordSale` checks sale history across both SIMs and refuses to append an already-sold card.
- Stock import checks both SIM inventories and sales history plus the allocation ledger, and uses the selected SIM's category list.

## Safety behavior
Allocated cards are intentionally not automatically released. If SMS send status is ambiguous, the card may be lost from stock pending manual reconciliation, but it will not be automatically delivered again to another customer. This favors preventing duplicate delivery over restoring uncertain cards.

## Build status
The Gradle build was attempted, but the environment could not resolve `services.gradle.org` (network/DNS unavailable), so APK compilation is **not verified**.
