# AlKamel 1.21.0 – Collect & Win and Salfni fixes

Changes in this source package:
- SaleCounter persists confirmed sale counts and migrates existing sales history once.
- Salfni eligibility and customer counts use the persistent counter rather than rescanning sales on each screen open.
- Confirmed sale callback updates the counter; SMS multipart callback handling remains idempotent.
- OperationLog filters and rewrites entries older than 48 hours when read.
- Collect & Win gift SMS template: `🎁 هدية من شبكة الكامل\nبعد شراء( N ) كروت\nرقم الكرت😘CARD`.
- Added selection by phone (including Select All) and confirmation to delete closed Salfni history (PAID/FAILED only) and gift-history records. Active, settling, and pending loans are protected; persistent purchase counters and pending gifts are not deleted.

Build verification: Release build could not be completed in this environment because the Gradle distribution host was unreachable (`UnknownHostException services.gradle.org`). Run `./gradlew clean assembleRelease` in Termux with network access to verify/build.
