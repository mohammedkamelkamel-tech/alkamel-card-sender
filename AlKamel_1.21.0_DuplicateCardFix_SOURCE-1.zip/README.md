# إدارة كروت الكامل

تطبيق Android حقيقي لمراقبة رسائل Jawali و Jaib وإرسال كروت الشحن تلقائياً.

## الرسائل المدعومة

Jawali:
استلمت مبلغ 100 YER من 776530652 رصيدك هو 1719

Jaib:
اضيف 100ر.ي تحويل مشترك رص:43617.38ر.ي من سامي الدومري 774776373

## المبالغ

99
100
200
245
250
500

## طريقة العمل

1. تصل الرسالة.
2. التطبيق يتأكد أنها رسالة Jawali أو Jaib بالشكل المتوقع.
3. يستخرج المبلغ.
4. يستخرج رقم الجوال اليمني 7xxxxxxxx.
5. يفتح ملف المبلغ مثل 100.txt.
6. يأخذ أول كرت.
7. يرسل الكرت إلى الرقم.
8. بعد بدء الإرسال يحذف الكرت من الملف.
9. إذا فشل إرسال SMS يعيد الكرت إلى بداية الملف.

## ملفات الكروت

مجلد التطبيق:
Android/data/ye.alkamel.cardsender/files/cards/

## ملاحظة مهمة

لا تضع أرقام بطاقات حقيقية داخل مستودع GitHub. ملفات الكروت تُجهز على الهاتف بعد تثبيت التطبيق.

التطبيق يحتاج:
RECEIVE_SMS
READ_SMS
SEND_SMS
وعلى Android 13+ إذن الإشعارات اختياري.

للاستخدام خارج Google Play، يمكن تثبيت APK الناتج مباشرة على الهاتف مع منح صلاحيات SMS.


## التفعيل بدون إنترنت

الإصدار 1.6.0 يستخدم أكواد تفعيل محلية بالكامل ولا يحتاج إلى إنترنت أثناء التفعيل. يوجد نوعان: كود يوم واحد يعمل 24 ساعة من أول تفعيل، وكود مدى الحياة.

ملاحظة أمنية: التفعيل دون خادم لا يمكنه معرفة أن الكود استُخدم على هاتف آخر؛ لذلك يتم ربط الكود محليًا بمعرف جهاز Android عند أول تفعيل.

> مثال الرقم البديل في التعليمات داخل التطبيق: 469331


## v1.14.1
- إصدار جديد مبني على v1.13.1 مع واجهة إدارة الخدمات والمخزون المحسنة.

## v1.13.1
- تحديث رقم الإصدار إلى v1.13.1 مع الحفاظ على إضافات وإصلاحات v1.12.1.

## v1.12.1
- إصلاح استقبال SMS ليتم وضع الحوالة في الطابور قبل الإرسال بدل الإرسال المباشر.
- منع تداخل عمليات الإرسال ومعالجة الحوالات بالتسلسل.
- استئناف معالجة الحوالات تلقائيًا بعد إضافة مخزون جديد.
- تحسين أمان حفظ ملف طابور الحوالات ضد التلف عند توقف التطبيق أثناء الكتابة.

## v1.12.0
- وضع صيانة لإيقاف الإرسال مع حفظ الحوالات في طابور انتظار دائم.
- تنفيذ الحوالات المعلقة بالتسلسل، عملية واحدة في كل مرة.
- إدارة المخزون: حذف كرت محدد أو تقليل عدد الكروت لكل فئة وSIM.


## تحديث 1.17.0 — حماية طابور الإرسال

- حفظ حالة الحوالة كـ `PROCESSING` قبل سحب كرت من المخزون.
- منع إعادة معالجة الحوالة التي توقفت في منتصف الإرسال بشكل تلقائي؛ يجب مراجعتها يدويًا لتجنب إرسال كرت ثانٍ.
- إضافة حالة `RETRYABLE` للأخطاء التي يمكن إعادة المحاولة فيها بعد إرجاع الكرت للمخزون.
- إظهار تنبيه واضح في شاشة طابور الإرسال للحوالات غير المحسومة، مع تأكيد إضافي قبل إعادة المحاولة.
- رفع رقم الإصدار إلى 1.17.0 وتشغيل مسارات البناء وتصدير المصدر على الفروع أيضًا.

**تنبيه:** إعادة المحاولة اليدوية للحوالة غير المحسومة يجب أن تتم فقط بعد التحقق من سجل الرسائل؛ تأكيد إرسال SMS من النظام لا يضمن دائمًا وصولها إلى هاتف المستلم.


## Version 1.20.0

Version bumped to 1.20.0 (versionCode 52) for the enhanced-design build. All existing application behavior is intended to remain unchanged.


## Version 1.21.0 — Independent SMS Archive

This edition uses a separate Android application ID and a separate SMS archive database.
The new archive is read-only and reads SMS rows only (no MMS or RCS). It provides conversation
listing, global/per-conversation search, and copy-on-long-press. Its dedicated workers sync
every six hours, importing only newly arrived SMS after the initial archive, and create an independent daily archive backup; a manual backup is also
available. It does not use the card sending queue or inventory database.

The v1.21.0 archive backup restore workflow and full release validation remain release gates.


## الإصدار المستقل 1.21.0

- معرّف تطبيق مستقل: `ye.alkamel.cardsender.v121`، ويمكن تثبيته بجانب 1.20.0.
- أرشيف SMS للقراءة فقط في قاعدة منفصلة `alkamel_sms_archive_v121.db`.
- يقرأ رسائل SMS الواردة والصادرة فقط من مزود SMS في Android؛ لا يستعلم عن MMS أو RCS.
- عرض المحادثات والبحث العام والبحث داخل المحادثة ونسخ نص الرسالة بالضغط المطوّل.
- المزامنة المجدولة كل 6 ساعات، والنسخ الاحتياطي التلقائي كل 24 ساعة، ولكل منهما مهمة مستقلة.
- النسخ اليدوي والاستعادة من ملف ZIP خاص بأرشيف SMS فقط، مع فحص SQLite قبل الاستعادة.
- لا توجد وظيفة إرسال أو تعديل أو حذف رسائل داخل شاشة الأرشيف.

**ملاحظة الإصدار:** لا يُعد الإصدار جاهزاً للتسليم النهائي إلا بعد نجاح ترجمة Android، وبناء APK، واختبارات التثبيت والعزل على جهاز فعلي.

## SMS archive isolation (v1.21.0)
- SMS archive uses its own SQLite database: `alkamel_sms_archive_v121.db`.
- The archive reads only `Telephony.Sms.CONTENT_URI` and filters to inbox, sent, and outbox SMS records. It does not query MMS/RCS providers and does not send, edit, or delete messages.
- The provider cursor is stored in a separate preference namespace (`sms_archive_sync_v121`) so restoring an archive from another device does not cause this device's SMS history to be skipped.
- Imported messages are committed in batches of 100. Periodic synchronization is scheduled every six hours; daily backup is a separate 24-hour worker. Both jobs use unique persistent WorkManager names and `KEEP` scheduling.
- Manual backup and archive-only restore are available in the SMS archive screen. Backup verification checks the ZIP entry and SQLite `quick_check` before publishing the dated archive.

## خدمة سلفني (إضافة v1.21.0)
- يسجل النظام عدد الكروت التي أُرسلت بنجاح لكل رقم اعتماداً على سجل المبيعات.
- طلب السلفة يصل برسالة SMS نصها `سلفني` من رقم العميل نفسه.
- يشترط وجود 10 عمليات شراء ناجحة على الأقل منذ آخر سداد، ولا يسمح بسلفة قائمة أو طلب قيد المعالجة.
- قيمة السلفة كرت واحد من فئة 100 ريال، ولا يصبح الدين فعالاً إلا بعد تأكيد Android إرسال رسالة الكرت.
- عند أول حوالة لاحقة للعميل، يحجز النظام تسوية السلفة قبل الإرسال. يخصم 100 ريال من مبلغ الحوالة ويرسل صافي فئة الكرت فقط، أو يرسل إشعار الخصم دون كرت إذا كان مبلغ الحوالة 100 ريال.
- لا يتم إغلاق السلفة إلا بعد تأكيد إرسال رسالة التسوية. الطلبات/التسويات ذات نتيجة إرسال غير مؤكدة لا يعاد صرفها تلقائياً وتبقى للمراجعة لمنع التكرار.
- بيانات السلف تحفظ في `loans_v121.csv` ضمن بيانات التطبيق، وتشملها النسخ الاحتياطية الكاملة.
- قسم «سلفني والمتسلفون» موجود ضمن «المزيد» ويعرض العملاء وعدد مشترياتهم والمتسلفين والسجل.
